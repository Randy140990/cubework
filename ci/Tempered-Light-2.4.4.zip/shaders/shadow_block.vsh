#version 330 compatibility
#extension GL_ARB_shader_image_load_store : enable
// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define VSH
#define PROGRAM_SHADOW
#define SHADOW_STAGE_OTHER
#include "/program/shadow.glsl"
