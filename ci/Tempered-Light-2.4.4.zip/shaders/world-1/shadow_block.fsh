#version 330 compatibility
// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define FSH
#define PROGRAM_SHADOW
#define SHADOW_STAGE_OTHER
#define DIM_NETHER
#include "/program/shadow.glsl"
