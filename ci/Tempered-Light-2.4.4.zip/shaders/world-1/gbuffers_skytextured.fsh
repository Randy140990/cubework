#version 330 compatibility
// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define FSH
#define PROGRAM_SKYTEXTURED
#define DIM_NETHER
#include "/program/gbuffers_sky.glsl"
