#version 330 compatibility
// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define FSH
#define PROGRAM_DH_TERRAIN
#define DIM_NETHER
#include "/program/dh_terrain.glsl"
