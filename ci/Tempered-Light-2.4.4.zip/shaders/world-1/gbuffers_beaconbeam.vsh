#version 330 compatibility
// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define VSH
#define PROGRAM_BEACON
#define DIM_NETHER
#include "/program/gbuffers_opaque.glsl"
