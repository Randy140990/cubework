/*
    Tempered Light - realistic smoke (Smoke Style: Realistic). Above every lit
    campfire and fire near you, a plume of soft, see-through smoke that rises far
    higher than Minecraft's puffs, widening and thinning as it climbs, breaking
    into wisps, carried off by the wind once it clears a chimney, and lit by the
    sun, the sky and the fire below it.

    Two compute passes (smoke_comp.glsl) find the sources in the light grid: one
    per column notes the topmost lit fire with air above it (how high a chimney
    walls it in, how much room there is under a roof), keeping one per 4x4-block
    cell; the second lists the 16 nearest. Composite marches each plume only where
    the view ray crosses its bounding box.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_SMOKEPLUME
#define LF_SMOKEPLUME

#if SMOKE_REAL == 1
#define HAS_SMOKE_PLUMES
#define SMOKE_MAX 16
#define SMOKE_NC (FF_SIZE_XZ / 4)        // cells of 4x4 columns; row SMOKE_NC holds the list

// Which light-grid categories smoke: 3 campfire, 2 soul campfire, 1 fire, 0 soul
// fire (also the priority when two share a cell), -1 none.
int smokeKind(int c) {
    if (c == CAT_CAMPFIRE) return 3;
    if (c == CAT_SOUL_CAMPFIRE) return 2;
    if (c == CAT_FIRE) return 1;
    if (c == CAT_SOUL_FIRE) return 0;
    return -1;
}
// Source word: kind (bits 30-31), grid cell y (23-29), x (16-22), z (9-15), air
// blocks above it up to a roof (4-8, 31 = open), chimney height (0-3). Never 0.
uint smokePack(int kind, ivec3 v, int air, int chimney) {
    return (uint(kind) << 30u) | (uint(v.y & 127) << 23u) | (uint(v.x & 127) << 16u) | (uint(v.z & 127) << 9u) |
           (uint(clamp(air, 1, 31)) << 4u) | uint(clamp(chimney, 0, 15));
}
ivec3 smokeCell(uint w) { return ivec3((w >> 16u) & 127u, (w >> 23u) & 127u, (w >> 9u) & 127u); }

#ifndef FF_COMPUTE
#ifndef LF_SMOKE_SAMPLER
#define LF_SMOKE_SAMPLER
uniform usampler2D lfSmokeSampler;
#endif

uint smokeEntry(int i) { return texelFetch(lfSmokeSampler, ivec2(i, SMOKE_NC), 0).r; }

// Is a plume drawn for the fire in this light-grid cell? (Minecraft's own puffs
// from it are then hidden.)
bool smokePlumeAt(ivec3 v) {
    ivec2 cc = v.xz / 4;
    for (int i = 0; i < SMOKE_MAX; i++) {
        uint w = smokeEntry(i);
        if (w == 0u) break;
        if (smokeCell(w).xz / 4 == cc) return true;
    }
    return false;
}

#if USE_FLOODFILL == 1
// For a particle at worldPos: does it rise from a fire that has a plume?
bool smokeParticleCovered(vec3 worldPos) {
    ivec3 v0 = ffVoxelFromWorld(worldPos);
    for (int dz = -1; dz <= 1; dz++) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = 0; dy <= 28; dy++) {
                ivec3 v = v0 + ivec3(dx, -dy, dz);
                if (!ffInside(v)) break;
                uint w = texelFetch(lfVoxelSampler, v, 0).r;
                if (w == 0u) continue;
                if (ffLevel(w) > 0 && smokeKind(ffCat(w)) >= 0) {
                    if (smokePlumeAt(v)) return true;
                    break;
                }
                if (ffSolid(w)) break;
            }
        }
    }
    return false;
}
#endif

#ifdef SMOKE_RENDER
struct SmokeSrc {
    vec3 base;      // player space: where the smoke leaves the flames
    float top;      // height it reaches
    float chimney;  // walled in this far up (no wind inside)
    float strength;
    vec3 albedo;
    vec3 glow;      // the fire's light on the smoke just above it
    float seed;
};

SmokeSrc smokeSource(uint w) {
    SmokeSrc s;
    int kind = int(w >> 30u);
    ivec3 v = smokeCell(w);
    vec3 world = vec3(v - FF_SIZE / 2) + floor(cameraPosition);
    s.base = world - cameraPosition + vec3(0.5, 0.6, 0.5);
    bool camp = kind >= 2, soul = kind == 0 || kind == 2;
    float air = float((w >> 4u) & 31u);
    s.top = (camp ? 26.0 : 13.0) * SMOKE_HEIGHT;
    if (air < 31.0) s.top = min(s.top, air - 0.2);           // stops under a roof
    s.chimney = float(w & 15u);
    s.strength = (camp ? 1.0 : 0.8) * SMOKE_THICKNESS;
    // Wood smoke is pale grey; smoke off burning blocks is darker and browner.
    s.albedo = camp ? vec3(0.66, 0.65, 0.64) : vec3(0.34, 0.32, 0.30);
    if (soul) s.albedo *= vec3(0.92, 0.96, 1.04);
    s.glow = (soul ? vec3(0.25, 0.78, 1.0) * LIGHT_SOUL : vec3(1.0, 0.45, 0.13) * LIGHT_FIRE) * 0.15;
    s.seed = hash12(world.xz * 0.37 + world.y);
    return s;
}

float smokeRadius(float h) { return 0.28 + 0.085 * h + 0.004 * h * h; }

// Where the plume's middle is at height h above its base (xz, player space):
// straight up inside a chimney, then bent downwind, leaning and meandering a little
// even in still air.
vec2 smokeCentre(SmokeSrc s, float h, float t) {
    float hh = max(h - s.chimney - 0.3, 0.0);
    vec2 d = windDirection();
    float carry = min(0.26 * hh + 0.010 * hh * hh, 20.0) * windStrength();
    vec2 side = vec2(-d.y, d.x);
    float a = s.seed * 6.2832;
    vec2 lean = vec2(cos(a), sin(a)) * 0.05 * hh;
    float m1 = sin(t * 0.31 + h * 0.17 + a) * 0.09 * hh;
    float m2 = sin(t * 0.67 + h * 0.39 + a * 2.7) * 0.04 * hh;
    return s.base.xz + d * (carry + m2) + side * m1 + lean;
}

// Smoke density (0..~1) at p (player space). cheap: one layer of billows only (for
// the shading sample towards the sun).
float smokeDensity(SmokeSrc s, vec3 p, float t, bool cheap) {
    float h = p.y - s.base.y;
    if (h < 0.0 || h > s.top) return 0.0;
    vec2 o = p.xz - smokeCentre(s, h, t);
    float r = smokeRadius(h);
    // Billows rising with the smoke (the small ones faster, so it churns), curling
    // round each other, roughening its edge and breaking it into wisps.
    vec3 q = vec3(o.x, h, o.y) + s.seed * 31.0;
    vec3 q1 = q * 0.42 - vec3(0.0, t * 0.48, 0.0);
    float n;
    if (cheap) {
        n = vnoise3(q1) * 0.8 + 0.1;
    } else {
        vec3 warp = vec3(vnoise3(q1 * 0.7 + 1.7), 0.5, vnoise3(q1 * 0.7 + 4.4)) - 0.5;
        q1 += warp * 1.8;
        vec3 q2 = q * 1.1 - vec3(0.0, t * 1.5, 0.0) + warp * 1.2;
        vec3 q3 = q * 2.7 - vec3(0.0, t * 2.6, 0.0) + warp * 0.8;
        n = vnoise3(q1) * 0.5 + vnoise3(q2) * 0.3 + vnoise3(q3) * 0.2;
    }
    float rq = max(length(o) / r + (n - 0.5) * 1.1, 0.0);
    float core = exp(-rq * rq * 1.8);
    // Dense and milky low down, breaking into billows and wisps higher up.
    float puffs = mix(1.0, smoothstep(0.36, 0.66, n), smoothstep(0.6, 5.0, h));
    float fade = smoothstep(0.0, 0.5, h) * (1.0 - smoothstep(0.45 * s.top, s.top, h));
    return core * puffs * fade / (1.0 + 0.05 * h);
}

// Ray from the camera (player space origin) against an axis-aligned box.
vec2 smokeBox(vec3 rd, vec3 bmin, vec3 bmax) {
    vec3 r = mix(rd, vec3(1e-6), lessThan(abs(rd), vec3(1e-6)));
    vec3 inv = 1.0 / r;
    vec3 a = bmin * inv, b = bmax * inv;
    vec3 lo = min(a, b), hi = max(a, b);
    return vec2(max(max(lo.x, lo.y), max(lo.z, 0.0)), min(min(hi.x, hi.y), hi.z));
}

// Draws every plume in front of the scene. amb: ambient light on the smoke; lightE
// and lightDir: the sun (or the End's black hole), 0 where there is none.
vec3 applySmokePlumes(vec3 col, vec3 rd, float dist, vec3 amb, vec3 lightE, vec3 lightDir, float dither) {
    float t = frameTimeCounter;
    float mu = dot(rd, lightDir);
    float ph = phaseHG(mu, 0.45) * 0.75 + 0.25 / (4.0 * PI);
    for (int i = 0; i < SMOKE_MAX; i++) {
        uint w = smokeEntry(i);
        if (w == 0u) break;
        SmokeSrc s = smokeSource(w);
        if (s.top < 0.5) continue;
        // Two boxes round the plume (the narrow lower part and the wide, drifting top),
        // so the thin column near the fire gets its share of the steps.
        vec2 trs[2];
        for (int g = 0; g < 2; g++) {
            float h0 = g == 0 ? 0.0 : s.top * 0.3, h1 = g == 0 ? s.top * 0.3 : s.top;
            vec2 c0 = smokeCentre(s, h0, t), c1 = smokeCentre(s, h1, t), cm = smokeCentre(s, 0.5 * (h0 + h1), t);
            float rr = smokeRadius(h1) * 1.25 + 0.07 * h1 + 0.4;
            vec2 lo = min(min(c0, c1), cm) - rr, hi = max(max(c0, c1), cm) + rr;
            vec2 tr = smokeBox(rd, vec3(lo.x, s.base.y + h0, lo.y), vec3(hi.x, s.base.y + h1, hi.y));
            tr.y = min(tr.y, dist);
            trs[g] = tr;
        }
        if (trs[0].y <= trs[0].x && trs[1].y <= trs[1].x) continue;
        int first = (trs[1].y > trs[1].x && (trs[0].y <= trs[0].x || trs[1].x < trs[0].x)) ? 1 : 0;
        vec3 scat = vec3(0.0);
        float T = 1.0;
        for (int gg = 0; gg < 2; gg++) {
            vec2 tr = trs[gg == 0 ? first : 1 - first];
            if (tr.y <= tr.x) continue;
            const int N = 14;
            float dt = (tr.y - tr.x) / float(N);
            for (int k = 0; k < N; k++) {
                vec3 p = rd * (tr.x + dt * (float(k) + dither));
                float d = smokeDensity(s, p, t, false);
                if (d < 0.004) continue;
                float sigma = d * 2.6 * s.strength;
                float h = p.y - s.base.y;
                // Smoke shades itself: billows are bright where the sun reaches them and
                // dark in their folds and in the thick middle.
                float rh = smokeRadius(h);
                float self = exp(-sigma * rh * 0.5);
                float sunT = 1.0;
                if (dot(lightE, lightE) > 1e-6) {
                    float dl = smokeDensity(s, p + lightDir * (0.6 * rh + 0.3), t, true);
                    // (Light scattered on through the smoke keeps the shade from going black.)
                    sunT = max(exp(-(dl * 2.6 * s.strength) * (0.6 * rh + 0.3) * 1.6) * (0.4 + 0.6 * self), 0.3);
                }
                float vis = 1.0;
                #if USE_SHADOWS == 1 && (defined DIM_OVERWORLD || defined END_HOLE_SHADOWS)
                    float wd;
                    vis = shadowTap(p, wd);
                #endif
                vec3 L = amb * (0.7 + 0.3 * self) + lightE * ph * vis * sunT + s.glow * exp(-h / 1.4);
                #if USE_FLOODFILL == 1 && defined LF_FLOODFILL
                    L += spreadLightAt(p) * 0.5;
                #endif
                float a = 1.0 - exp(-sigma * dt);
                scat += T * s.albedo * L * a;
                T *= 1.0 - a;
            }
            if (T < 0.02) break;
        }
        col = col * T + scat;
    }
    return col;
}
#endif
#endif
#endif

#endif
