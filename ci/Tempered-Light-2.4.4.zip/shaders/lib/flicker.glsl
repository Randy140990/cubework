/*
    Tempered Light - firelight. Flames don't burn steady: fire, campfires, torches,
    candles and lanterns flicker, each at its own pace, lava and magma pulse slowly,
    and the light of a flame sways about inside its block, so the shadows it casts
    dance. Every surface lit by the same flame sees the same flicker.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_FLICKER
#define LF_FLICKER

// How much a kind of light flickers (x, 0 = steady) and how quickly (y, 1 = a flame).
vec2 flickerKind(int c) {
    if (c == CAT_FIRE || c == CAT_SOUL_FIRE) return vec2(1.0, 1.0);
    if (c == CAT_CAMPFIRE || c == CAT_SOUL_CAMPFIRE) return vec2(0.95, 1.0);
    if (c == CAT_CANDLE || c == CAT_JACK_O_LANTERN) return vec2(0.8, 1.15);
    if (c == CAT_TORCH || c == CAT_COPPER_TORCH || c == CAT_SOUL) return vec2(0.7, 1.0);
    if (c == CAT_FURNACE) return vec2(0.5, 0.7);
    if (c == CAT_LANTERN || c == CAT_LANTERN_HANGING || c == CAT_SOUL_LANTERN_HANGING || c == CAT_COPPER_LANTERN_HANGING) return vec2(0.4, 0.9);
    if (c == CAT_LAVA) return vec2(0.35, 0.25);
    if (c == CAT_MAGMA) return vec2(0.25, 0.2);
    return vec2(0.0);
}

// Smooth 1-D value noise (0..1) along t; seed picks the track, and nearby seeds
// give similar tracks (so neighbouring lava blocks rise and fall together).
float noise1(float t, float seed) {
    float i = floor(t), f = fract(t);
    float s0 = floor(seed), sf = fract(seed);
    float a = mix(hash12(vec2(i, s0)), hash12(vec2(i, s0 + 1.0)), sf);
    float b = mix(hash12(vec2(i + 1.0, s0)), hash12(vec2(i + 1.0, s0 + 1.0)), sf);
    return mix(a, b, f * f * (3.0 - 2.0 * f));
}
// A smooth, never-repeating wobble in about -1..1: a quick flutter over a slower sway.
float flameNoise(float t, float seed) {
    float a = noise1(t * 2.3, seed);
    float b = noise1(t * 6.1, seed + 17.0);
    float c = noise1(t * 0.7, seed + 41.0);
    return (a * 0.5 + b * 0.3 + c * 0.2) * 2.0 - 1.0;
}

// Brightness of a flame now (1 = steady), for a light of kind k.
float flameBrightness(float seed, vec2 k) {
    if (k.x <= 0.0 || FIRE_FLICKER <= 0.0) return 1.0;
    float t = frameTimeCounter * k.y;
    float f = flameNoise(t, seed) * 0.26;
    // Now and then the flame gutters and dips for a moment.
    f -= smoothstep(0.72, 0.95, noise1(t * 1.6, seed + 7.0)) * 0.22;
    return max(1.0 + f * k.x * FIRE_FLICKER, 0.2);
}

// Where the light of a flame is now, relative to the middle of its block.
vec3 flameSway(float seed, vec2 k) {
    if (k.x <= 0.0 || k.y < 0.5 || SHADOW_DANCE <= 0.0) return vec3(0.0);   // lava and magma don't sway
    float t = frameTimeCounter * k.y * 1.2;
    vec3 o = vec3(flameNoise(t, seed + 3.0), 0.5 * flameNoise(t * 0.9, seed + 5.0), flameNoise(t * 1.1, seed + 9.0));
    return o * 0.17 * k.x * SHADOW_DANCE;
}

// Each torch, candle or lantern has its own pace. Fire, lava and magma spread over
// many blocks, so they flicker in slow waves across the area instead of block by block.
float flameSeed(vec3 blockPos, vec2 k) {
    vec3 b = floor(blockPos);
    if (k.x == 1.0 || k.y < 0.5) return dot(b, vec3(0.13, 0.07, 0.11)) + 300.0;
    return hash13(b + 0.5) * 613.0;
}

#endif
