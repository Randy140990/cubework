/*
    Tempered Light - screen/view/world reconstruction for vanilla, Voxy and DH depth.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_SPACE
#define LF_SPACE

#define SRC_SKY 0
#define SRC_VANILLA 1
#define SRC_VOXY 2
#define SRC_DH 3

vec3 projectInv(mat4 projInv, vec3 ndc) {
    vec4 p = projInv * vec4(ndc, 1.0);
    return p.xyz / p.w;
}
vec3 screenToView(vec2 uv, float depth, mat4 projInv) {
    return projectInv(projInv, vec3(uv, depth) * 2.0 - 1.0);
}
vec3 viewToScreen(vec3 viewPos, mat4 proj) {
    vec4 c = proj * vec4(viewPos, 1.0);
    return (c.xyz / c.w) * 0.5 + 0.5;
}
vec3 viewToPlayer(vec3 viewPos) {
    return mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
}
vec3 playerToView(vec3 playerPos) {
    return mat3(gbufferModelView) * (playerPos - gbufferModelViewInverse[3].xyz);
}
float linearizeDepth(float depth, float n, float f) {
    return (2.0 * n * f) / (f + n - (depth * 2.0 - 1.0) * (f - n));
}

// Far edge of whatever is rendering the distance, in blocks.
float farDistance() {
    float d = far;
    #ifdef VOXY
        d = max(d, float(vxRenderDistance) * 16.0);
    #endif
    #ifdef DISTANT_HORIZONS
        d = max(d, float(dhRenderDistance));
    #endif
    return d;
}

#endif
