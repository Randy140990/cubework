/*
    Tempered Light - surface shading: sun/moon, sky, block light, emission,
    wet surfaces and puddles.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_LIGHTING
#define LF_LIGHTING

#include "/lib/flicker.glsl"

struct Material {
    vec3 albedo;      // linear
    float smoothness;
    float f0;         // labPBR green channel (0..1); >= 0.9 means metal
    float emission;
    float ao;
    int cat;
};

// Lamp light at a surface from the coloured light grid: the spread light, and up to
// two sources (position, colour and strength, and how much of each reaches here).
struct LampLight {
    vec4 spread;   // rgb colour, a level
    vec4 src1;     // xyz world position of the strongest source, w its level (0 = none)
    vec3 col1;     // its colour and strength
    vec3 vis1;     // how much of its light gets here (per colour: stained glass tints it)
    vec4 src2;
    vec3 col2;
    vec3 vis2;
    vec4 far;      // rgb colour of the lamps around (distant light colour grid), a how sure
    vec2 flick;    // how bright each source's flame is right now (1 = steady)
    vec4 hand;     // the light in your hand: xyz where it is (world), w how much reaches here (< 0: not traced)
};
LampLight noLamps() {
    LampLight l;
    l.spread = vec4(0.0); l.src1 = vec4(0.0); l.src2 = vec4(0.0); l.far = vec4(0.0);
    l.col1 = vec3(0.0); l.col2 = vec3(0.0); l.vis1 = vec3(1.0); l.vis2 = vec3(1.0);
    l.flick = vec2(1.0);
    l.hand = vec4(0.0, 0.0, 0.0, -1.0);
    return l;
}

struct SceneLights {
    vec3 lightDir;    // sun by day, moon by night (world space)
    vec3 lightE;      // direct irradiance of that light at the surface
    vec3 skyAmbient;  // average sky radiance (already includes clouds)
    vec3 sunDir;
};

// ---------------------------------------------------------- BRDF bits -----
float D_GGX(float NdotH, float a) {
    float a2 = a * a;
    float d = NdotH * NdotH * (a2 - 1.0) + 1.0;
    return a2 / (PI * d * d + 1e-6);
}
float V_SmithJoint(float NdotV, float NdotL, float a) {
    float a2 = a * a;
    float gv = NdotL * sqrt(NdotV * NdotV * (1.0 - a2) + a2);
    float gl = NdotV * sqrt(NdotL * NdotL * (1.0 - a2) + a2);
    return 0.5 / (gv + gl + 1e-5);
}
vec3 fresnelSchlick(float cosT, vec3 f0) {
    return f0 + (1.0 - f0) * pow5(1.0 - saturate(cosT));
}
vec3 materialF0(Material m) {
    return m.f0 >= 0.9 ? m.albedo : vec3(max(m.f0, 0.02));
}
vec3 specularGGX(vec3 N, vec3 V, vec3 L, float smoothness, vec3 f0) {
    float rough = max(sqr(1.0 - smoothness), 0.02);
    vec3 H = normalize(V + L);
    float NdotL = saturate(dot(N, L)), NdotV = saturate(dot(N, V)) + 1e-4, NdotH = saturate(dot(N, H));
    return fresnelSchlick(saturate(dot(V, H)), f0) * D_GGX(NdotH, rough) * V_SmithJoint(NdotV, NdotL, rough) * NdotL;
}

// ------------------------------------------------------------ weather -----
vec2 rainRipplesLayer(vec2 p, float t) {
    vec2 g = vec2(0.0);
    vec2 base = floor(p - 0.5);
    for (int j = 0; j < 2; j++) for (int i = 0; i < 2; i++) {
        vec2 c = base + vec2(i, j);
        vec2 h = hash22(c);
        vec2 centre = c + 0.2 + 0.6 * h;
        float period = 0.7 + 0.6 * h.x;
        float age = fract(t / period + h.y);
        float r = age * 0.85;
        vec2 dv = p - centre;
        float d = length(dv);
        float ring = sin((d - r) * 30.0) * smoothstep(0.14, 0.0, abs(d - r)) * sqr(1.0 - age);
        g += dv / max(d, 1e-3) * ring;
    }
    return g * 0.22;
}

// Two offset layers of drops so rings overlap like real rain on water.
vec2 rainRipples(vec2 p, float t) {
    return rainRipplesLayer(p, t) + rainRipplesLayer(p * 1.63 + 17.3, t * 1.21 + 3.7) * 0.8;
}

// One noise field shapes both puddles and the damp patches they leave behind.
float puddleField(vec2 xz) {
    return fbm2(xz * 0.075, 3) * 0.7 + vnoise(xz * 0.45) * 0.3;
}
// Puddles (Patches) cover the ground where puddleField is above this. p: the puddle
// amount. In steady rain they cover about 40% of open ground after a minute, 80%
// after two and all of it by about three (the soak builds up slowly, then quickly).
float puddleThreshold(float p) {
    return 1.0 - p * (0.54 + 0.85 * sqr(sqr(lfSoak)));
}

// Rain falling here right now (vanilla rain, only in biomes that get rain).
float rainHere() {
    return rainStrength * lfRainHere;
}

// Returns wetness 0..1; writes the puddle amount. Wetness and puddles follow the
// biome (no wet deserts), build up while it rains and dry out slowly afterwards:
// puddles shrink over about a minute and leave damp patches for a while longer.
float surfaceWetness(vec3 worldPos, vec3 N, float skyLight, int cat, out float puddle) {
    puddle = 0.0;
    #if WET_SURFACES == 1
        float exposure = smoothstep(0.86, 0.97, skyLight);
        #if WET_MODE == 2
            float wet = exposure;          // Always wet (for screenshots and builds)
            float pudAmt = 1.0;
        #else
            float wet = lfWet * exposure;
            float pudAmt = lfPuddle;
        #endif
        if (wet <= 0.002) return 0.0;
        float field = puddleField(worldPos.xz);
        // Hollows (where puddles form) stay damp longest.
        float w = wet * mix(0.55, 1.0, smoothstep(0.3, 0.7, field));
        #if PUDDLES == 1
            if (N.y > 0.9 && allowsPuddles(cat)) {
                float p = saturate(pudAmt * PUDDLE_AMOUNT) * exposure;
                #if PUDDLE_COVERAGE == 2
                    puddle = smoothstep(0.0, 0.3, p) * smoothstep(0.86, 0.98, N.y);   // the whole surface
                #else
                    // Puddles form in the hollows first, and in a long downpour keep spreading
                    // until all open ground is under a sheet of water.
                    float thr = puddleThreshold(p);
                    puddle = smoothstep(thr, thr + 0.035, field) * smoothstep(0.86, 0.98, N.y) * step(0.01, p);
                #endif
            }
        #endif
        return w;
    #else
        return 0.0;
    #endif
}

vec3 puddleNormal(vec3 worldPos) {
    vec3 pn = vec3(0.0, 1.0, 0.0);
    #if RAIN_RIPPLES == 1
        vec2 g = rainRipples(worldPos.xz * 2.0, frameTimeCounter) * rainHere();
        // A faint wind ripple keeps puddles alive between drops.
        g += (vec2(vnoise(worldPos.xz * 3.0 + frameTimeCounter * 0.7), vnoise(worldPos.zx * 3.0 - frameTimeCounter * 0.6)) - 0.5) * 0.03;
        pn = normalize(vec3(-g.x, 1.0, -g.y));
    #endif
    return pn;
}

// Raindrops landing on wet ground (not just puddles): small rings.
vec3 wetRippleNormal(vec3 N, vec3 worldPos, float w) {
    #if RAIN_RIPPLES == 1
        float r = rainHere() * w * smoothstep(0.7, 0.95, N.y);
        if (r > 0.01) {
            vec2 g = rainRipples(worldPos.xz * 2.0, frameTimeCounter) * r * 0.7;
            N = normalize(N + vec3(-g.x, 0.0, -g.y));
        }
    #endif
    return N;
}

// Puddles above a wall or cliff spill over its edge: 0..1 for how much water is
// running down from the ground on top of this wall here.
float puddleSpill(vec3 wp, vec3 N) {
    #if PUDDLES == 1
        float field = puddleField(wp.xz - N.xz * 0.5);
        float p = saturate(lfPuddle * PUDDLE_AMOUNT);
        float thr = puddleThreshold(p);
        return smoothstep(thr - 0.08, thr + 0.02, field) * saturate(p * 2.0) * lfRainHere;
    #else
        return 0.0;
    #endif
}

// Water running down walls in the rain: thin streaks, each with a drop at its
// leading end, sliding down at their own pace. 0..1 (how much of a streak is here).
// spill (0..1): water pouring from puddles above makes more columns run.
float wallStreaks(vec3 wp, vec3 N, float t, float spill) {
    vec3 side = normalize(cross(N, vec3(0.0, 1.0, 0.0)));
    float a = dot(wp, side) * 7.0;
    float col = floor(a);
    float face = floor(dot(wp, N) * 2.0 + 0.5);
    float h = hash12(vec2(col, face + 3.1));
    if (fract(h * 13.1) < 0.45 - 0.35 * spill) return 0.0;  // not every column runs
    float x = fract(a) - 0.5 + (h - 0.5) * 0.4;
    float width = mix(0.08, 0.22, fract(h * 5.7));
    float line = smoothstep(width, 0.0, abs(x));
    float y = wp.y * mix(0.35, 0.8, fract(h * 7.3)) + t * mix(0.22, 0.6, h) + h * 10.0;
    float f = fract(y);
    float trail = smoothstep(0.0, 0.06, f) * smoothstep(1.0, 0.2, f);
    return line * trail;
}

// Snow settling on the tops of blocks in cold biomes: a patchy dusting most of the
// time, full cover while (and for a while after) it snows. Only under open sky.
void applySnowCover(inout Material m, inout vec3 N, vec3 worldPos, float skyLight) {
    float amount = snowCoverHere() * SNOW_COVER;
    if (amount < 0.01 || isEmitterCat(m.cat) || m.cat == CAT_WATER || m.cat == CAT_LAVA || m.cat == CAT_SNOW ||
        m.cat == CAT_ICE || m.cat == CAT_GLASS || m.cat == CAT_STAINED_GLASS || m.emission > 0.05) return;
    float up = smoothstep(0.45, 0.85, N.y);
    if (isFoliage(m.cat)) up = smoothstep(0.1, 0.7, N.y) * 0.8;   // leaves and plants catch less
    float open = smoothstep(0.95, 0.99, skyLight);      // full sky light only
    #if defined LF_FLOODFILL && USE_FLOODFILL == 1
        // Solid blocks, glass, ice and leaves overhead keep it off (glass lets sky light
        // through, so sky light alone can't tell); plants, mobs and you don't.
        if (open > 0.0) {
            for (int i = 0; i < 10; i++) {
                ivec3 v = ffVoxelFromWorld(worldPos + N * 0.1 + vec3(0.0, float(i) + 0.5, 0.0));
                if (!ffInside(v)) break;
                uint w = texelFetch(lfVoxelSampler, v, 0).r;
                int c = ffCat(w);
                if (w != 0u && !ffEntity(w) && (ffSolid(w) || c == CAT_LEAVES || c == CAT_GLASS || c == CAT_STAINED_GLASS || c == CAT_ICE)) { open = 0.0; break; }
            }
        }
    #endif
    float n = vnoise(worldPos.xz * 0.55) * 0.6 + vnoise(worldPos.xz * 2.3 + 7.1) * 0.4;
    float snow = saturate((up * open * amount * 1.6 - (1.0 - n) * 0.75) * 4.0);
    if (snow <= 0.0) return;
    m.albedo = mix(m.albedo, vec3(0.80, 0.84, 0.90), snow);
    m.smoothness = mix(m.smoothness, 0.32, snow);
    m.f0 = mix(m.f0, 0.02, snow);
    N = normalize(mix(N, vec3(0.0, 1.0, 0.0), snow * 0.6));
}

void applyWetness(inout Material m, inout vec3 N, vec3 worldPos, float skyLight, out float puddle) {
    float w = surfaceWetness(worldPos, N, skyLight, m.cat, puddle);
    if (w <= 0.0) return;
    float por = porosity(m.cat);
    m.albedo *= 1.0 - 0.5 * por * w;
    m.smoothness = mix(m.smoothness, 0.88, w * (1.0 - 0.55 * por));
    N = wetRippleNormal(N, worldPos, w);
    #if WALL_DRIPS == 1
        if (abs(N.y) < 0.35) {
            // Drips run while it rains, and keep running from puddles above after it stops.
            float spill = puddleSpill(worldPos, N);
            float run = max(0.25 + 0.75 * rainHere(), spill);
            float s = wallStreaks(worldPos, N, frameTimeCounter, spill) * w * run;
            m.albedo *= 1.0 - 0.3 * s * (0.5 + 0.5 * por);
            m.smoothness = mix(m.smoothness, 0.95, s);
            vec3 side = normalize(cross(N, vec3(0.0, 1.0, 0.0)));
            N = normalize(N + side * (wallStreaks(worldPos + side * 0.02, N, frameTimeCounter, spill) * w * run - s) * 0.4);
        }
    #endif
    if (puddle > 0.0) {
        // Standing water: darker ground under a mirror-like surface.
        m.albedo *= 1.0 - 0.6 * puddle;
        m.smoothness = mix(m.smoothness, 0.985, puddle);
        m.f0 = mix(m.f0, 0.02, puddle);
        N = normalize(mix(N, puddleNormal(worldPos), puddle));
    }
}

// --------------------------------------------------------- block light -----
// Colour of the light in your hands (from item.properties), else the default warm.
vec3 handLightColor() {
    int id = heldBlockLightValue >= heldBlockLightValue2 ? heldItemId : heldItemId2;
    int c = catFromId(float(id));
    if (c == CAT_DEFAULT || !isEmitterCat(c)) return defaultBlockLightColor();
    vec3 e = emitterLight(c).rgb;
    return e / max(maxOf(e), 1e-3) * min(lightTypeStrength(c), 1.5);
}
// A torch or lantern in your hand flickers like a placed one.
float handFlicker() {
    int id = heldBlockLightValue >= heldBlockLightValue2 ? heldItemId : heldItemId2;
    return flameBrightness(91.7, flickerKind(catFromId(float(id))));
}
float handLight(vec3 playerPos) {
    #if HANDHELD_LIGHT == 1
        float held = float(max(heldBlockLightValue, heldBlockLightValue2));
        if (held <= 0.0) return 0.0;
        float d = length(playerPos);
        return saturate((held - d) / 15.0);
    #else
        return 0.0;
    #endif
}

// --------------------------------------------------------------- shade -----
// V points from the surface to the camera. lm.x block light, lm.y sky light.
// lamps: coloured light from the grid and the one or two sources it comes from.
vec3 shadeSurface(Material m, vec3 N, vec3 V, vec3 playerPos, vec3 worldPos, vec2 lm,
                  ShadowSample sh, float cloudSh, LampLight lamps, SceneLights L) {
    vec4 spread = lamps.spread;
    vec3 albedo = m.albedo;
    bool foliage = isFoliage(m.cat);
    float NdotL = dot(N, L.lightDir);

    // Direct light
    float diff = foliage ? (0.3 + 0.7 * saturate(NdotL * 0.5 + 0.5)) : saturate(NdotL);
    vec3 shadow = sh.light * cloudSh;
    if (sh.waterFrac > 0.0) {
        vec3 absorb = exp(-waterAbsorption() * sh.waterDepth * 1.2);
        // Caustics, taken where this light entered the water so they line up with the
        // sun; they soften with depth but never quite vanish.
        vec3 entry = worldPos + L.lightDir * sh.waterDepth;
        float cst = mix(1.0, caustics(entry), 0.4 + 0.6 * exp(-sh.waterDepth / 14.0));
        shadow *= mix(vec3(1.0), absorb * cst, sh.waterFrac);
    }
    float metal = m.f0 >= 0.9 ? 1.0 : 0.0;
    vec3 direct = L.lightE * shadow * diff * albedo * RCP_PI * (1.0 - 0.9 * metal);
    #if FOLIAGE_GLOW == 1
        if (foliage) {
            float back = pow(saturate(dot(-V, L.lightDir)), 5.0);
            direct += L.lightE * shadow * albedo * back * 0.55 * RCP_PI * sqrt(albedo);
        }
    #endif
    if (m.smoothness > 0.05 || metal > 0.5) {
        direct += L.lightE * shadow * specularGGX(N, V, L.lightDir, m.smoothness, materialF0(m)) * SPECULAR_STRENGTH;
    }
    // Storybook look lifts shadowed areas a little.
    direct += L.lightE * albedo * RCP_PI * LOOK_SHADOW_LIFT * (1.0 - luminance(shadow)) * smoothstep(0.6, 0.95, lm.y);

    // Sky light
    float skyVis = lm.y * lm.y * (3.0 - 2.0 * lm.y);
    float dirTerm = 0.62 + 0.38 * N.y;
    vec3 ambient = L.skyAmbient * skyVis * dirTerm * m.ao * SKY_LIGHT_BRIGHTNESS * mix(1.0, cloudSh, 0.3);
    ambient += L.skyAmbient * 0.12 * skyVis * saturate(-N.y) ;
    vec3 sky = ambient * albedo;

    // Block light: brightness from vanilla levels and the light grid, colour from the grid.
    float baseL = max(lm.x, spread.a);
    vec3 bcol = defaultBlockLightColor();
    // Further out than the light grid reaches, the lamps around still give their colour.
    bcol = mix(bcol, lamps.far.rgb, lamps.far.a);
    bcol = mix(bcol, spread.rgb, smoothstep(0.02, 0.2, spread.a) * step(lm.x * 0.6, spread.a + 0.15));
    vec3 blockRGB = bcol * blockLightCurve(baseL);
    vec3 blockSpec = vec3(0.0);
    if (lamps.src1.w > 0.0) {
        // Each of the (up to) two strongest lamps lights this surface on its own, in its
        // own colour, with its own shadow, so two lamps throw two shadows at their own
        // angles. Light that got here round corners keeps hidden spots from going black.
        vec3 lit = vec3(0.0);
        for (int k = 0; k < 2; k++) {
            vec4 S = k == 0 ? lamps.src1 : lamps.src2;
            if (S.w <= 0.0) continue;
            vec3 c = k == 0 ? lamps.col1 : lamps.col2;
            if (c.r < 0.0) c = bcol;                     // source gone this frame: use the grid colour
            vec3 vis = k == 0 ? lamps.vis1 : lamps.vis2;
            vec3 toL = S.xyz - worldPos;
            float dl = length(toL);
            vec3 Ld = toL / max(dl, 1e-3);
            // Round pools of light instead of vanilla's diamonds, kept inside the spread
            // light's reach so they fade out smoothly instead of ending in a hard edge.
            float poolL = min(S.w - max(dl - 0.6, 0.0) / 15.0, spread.a + 2.0 / 15.0);
            if (k == 0) poolL = max(baseL, poolL);
            if (poolL <= 0.0) continue;
            // The light block's own faces face away from its centre but are fully lit; every
            // other surface (the floor right under a lantern too) follows the angle smoothly,
            // so there is no hard ring around a light standing on the ground.
            vec3 local = worldPos - (floor(S.xyz) + 0.5);   // (the flame sways inside its block)
            bool ownBlock = maxOf(abs(local)) < 0.52 && dot(N, local) > 0.0;
            float facing = ownBlock ? 1.0 : saturate(dot(N, Ld));
            float strength = blockLightCurve(poolL) * mix(1.0, 0.3 + 0.7 * facing, 0.8);
            #if LIGHT_SHADOWS == 0
                vis = vec3(1.0);
                if (k == 0) c = bcol;                    // the grid's colour already has glass tint in it
            #endif
            lit += c * strength * vis * (k == 0 ? lamps.flick.x : lamps.flick.y);
            // Light sources glint and sheen off nearby surfaces, even rough stone.
            if (m.smoothness > 0.04 && !ownBlock) {
                vec3 sp = c * (k == 0 ? lamps.flick.x : lamps.flick.y) * blockLightCurve(poolL) * vis * specularGGX(N, V, Ld, max(m.smoothness, 0.25), materialF0(m)) * 1.4 * SPECULAR_STRENGTH
                        * smoothstep(0.35, 0.8, dl);
                // No single-pixel sparkles: a glint is never brighter than a little over the
                // light falling there.
                blockSpec += min(sp, c * blockLightCurve(poolL) * 2.0);
            }
        }
        // Hidden from the lamps: keep only part of the light that got here around corners
        // or from other lights, so shadows are dark but not black.
        blockRGB = max(lit, bcol * blockLightCurve(baseL) * 0.2 * lamps.flick.x);
    }
    float aoB = mix(1.0, m.ao, 0.6);
    vec3 block = blockRGB * aoB * albedo;
    float hand = handLight(playerPos);
    float handVis = 1.0;
    if (lamps.hand.w >= 0.0) {
        // Traced from your hand: it falls off from there, lights what faces it, and
        // blocks, mobs and you yourself cast shadows from it.
        vec3 toH = lamps.hand.xyz - worldPos;
        float dh = length(toH);
        hand = saturate((float(max(heldBlockLightValue, heldBlockLightValue2)) - dh) / 15.0);
        float facing = saturate(dot(N, toH / max(dh, 1e-3)));
        handVis = mix(0.12, 1.0, lamps.hand.w) * mix(1.0, 0.3 + 0.7 * facing, 0.8);
    }
    if (hand > 0.0) block = max(block, handLightColor() * blockLightCurve(hand) * handFlicker() * aoB * albedo * handVis);
    block += blockSpec;

    // Emissive surfaces
    vec3 emit = vec3(0.0);
    if (m.emission > 0.0) {
        vec4 el = emitterLight(m.cat);
        // Lava: deep orange in the cooler crust, yellow-white only in the hottest spots.
        vec3 ea = m.cat == CAT_LAVA ? pow(albedo, vec3(1.7)) * 1.8 : albedo;
        // Ores glow in their own colour, and so does the rock right around each speck.
        if (isOre(m.cat)) ea = mix(albedo, el.rgb / maxOf(el.rgb) * max(luminance(albedo), 0.22), 0.7);
        emit = ea * m.emission * EMISSIVE_STRENGTH * 3.2 * min(el.a, 1.5) * min(lightTypeStrength(m.cat), 1.5);
    }

    // Floor so caves are never pure black.
    vec3 floorLight = albedo * (0.0035 * CAVE_BRIGHTNESS + nightVision * 0.25);

    return direct + sky + block + emit + floorLight;
}

#endif
