/*
    Tempered Light - exposure, film curve and the Look colour grades.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_TONEMAP
#define LF_TONEMAP

vec3 filmCurve(vec3 x) {
    // Rational fit of a filmic S-curve (Narkowicz 2015 coefficients).
    return saturate((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14));
}

vec3 grade(vec3 c) {
    float sat = SATURATION, con = CONTRAST, vib = 0.0;
    vec3 tint = vec3(1.0);
    float lift = 0.0;
    #if GRADE_MODE == 2
        sat *= 1.06; con *= 0.93; tint = vec3(1.04, 1.0, 0.95); lift = 0.012; vib = 0.10;
    #elif GRADE_MODE == 3
        sat *= 1.16; con *= 1.05; vib = 0.22; tint = vec3(1.0, 1.01, 1.02);
    #elif GRADE_MODE == 4
        sat *= 1.12; con *= 1.12; vib = 0.08;
    #elif GRADE_MODE == 5
        // Balanced (the Tempered Look): lively but true colours, a hint cool.
        sat *= 1.04; con *= 1.03; vib = 0.12; tint = vec3(0.985, 1.0, 1.02);
    #endif
    c *= tint;
    vib += VIBRANCE;
    float l = luminance(c);
    // Vibrance: push the dull colours more than the strong ones.
    float s = maxOf(c) - minOf(c);
    c = mix(vec3(l), c, sat + vib * (1.0 - saturate(s * 2.0)));
    // The eye sees less colour in the dark.
    c = mix(vec3(l), c, mix(1.0, smoothstep(0.0, 0.03, l), DARK_DESATURATION));
    // White point: how easily bright colours reach white.
    c *= mix(1.0, WHITE_POINT, smoothstep(0.15, 1.5, l));
    c = max(c, 0.0);
    c = pow(c / 0.18, vec3(con)) * 0.18;
    return c;
}

#endif
