/*
    Tempered Light - falling leaves. Minecraft only drops a few leaf particles,
    and only from some trees; these drift down from the underside of any leaves
    near you (trees, hedges, hanging leaves), tumbling and swaying as they fall,
    in the colour of the leaves above them.

    The shadow pass notes the colour of every column's leaves and a compute pass
    finds the underside of the lowest leaves and the ground below; here a ray
    walks the columns it crosses and meets the leaves falling in each.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_LEAVES
#define LF_LEAVES

#if USE_FLOODFILL == 1 && (FALLING_LEAVES == 1 || CANOPY_DRIPS_ON == 1)
uniform sampler2D lfCanopySampler;
#endif

#if USE_FLOODFILL == 1 && FALLING_LEAVES == 1
#define HAS_FALLING_LEAVES
uniform sampler2D lfLeafColSampler;

// One column's leaves: nearest hit along the ray (player space). Returns colour
// (linear, unlit) in rgb and coverage in a; writes the leaf's normal and distance.
// slant: how far the wind carries a leaf sideways for each block it falls.
vec4 leavesInColumn(ivec2 cell, vec2 colW, float topY, float groundY, vec3 ro, vec3 rd,
                    float tMax, vec2 slant, inout float best, out vec3 nBest) {
    vec4 res = vec4(0.0);
    nBest = vec3(0.0, 1.0, 0.0);
    float fallH = topY - groundY;
    if (fallH < 0.6) return res;
    // Rain and above all storms shake far more leaves down, and they let go sooner.
    float storm = saturate(0.5 * lfRain + lfThunder);
    float density = min(0.26 * FALLING_LEAVES_AMOUNT * (1.0 + 2.2 * storm), 0.95);
    for (int k = 0; k < 4; k++) {
        vec3 h = hash33(vec3(colW, float(k) * 13.71 + 0.5));
        // Each leaf falls, then the column waits a while before the next one lets go.
        float speed = 0.55 + 0.35 * h.x;                 // blocks per second
        float fallT = fallH / speed;
        float period = fallT + (3.0 + 9.0 * h.y) * (1.0 - 0.6 * storm);
        float tt = frameTimeCounter + h.z * 173.0;
        float cyc = floor(tt / period);
        if (hash12(vec2(cyc + h.x * 57.0, float(k) + colW.x * 0.37 + colW.y * 0.11)) > density) continue;
        float tf = fract(tt / period) * period;
        if (tf > fallT) continue;
        float y = topY - 0.1 - tf * speed;
        // Sway from side to side as it falls, kept inside its own column.
        float w = 1.3 + 0.9 * h.x;
        vec2 off = (h.xy - 0.5) * 0.25 + vec2(sin(tt * w + h.y * 6.283), cos(tt * w * 0.8 + h.z * 6.283)) * 0.17;
        vec3 pos = vec3(float(cell.x) + 0.5 + off.x, y, float(cell.y) + 0.5 + off.y);
        // In wind (above all in storms) leaves are blown off sideways as they fall,
        // gusting, like the smoke (at most 4 blocks).
        vec2 blown = slant * (topY - 0.1 - y) * (0.8 + 0.4 * sin(tt * 0.9 + h.x * 6.283));
        float bl = length(blown);
        if (bl > 4.0) blown *= 4.0 / bl;
        pos.xz += blown;
        // Tumbling: the leaf's face turns over as it flutters.
        float a1 = tt * (1.4 + h.y) + h.x * 6.283, a2 = tt * (0.9 + h.z) + h.y * 6.283;
        vec3 n = normalize(vec3(sin(a1) * 0.9, 0.6 + 0.5 * cos(a2), cos(a1) * 0.9 * sin(a2 + 1.3)));
        float dn = dot(rd, n);
        if (abs(dn) < 1e-3) continue;
        float tp = dot(pos - ro, n) / dn;
        if (tp < 0.1 || tp > tMax || tp >= best) continue;
        vec3 hp = ro + rd * tp - pos;
        vec3 ax = cross(n, vec3(sin(a2), 0.3, cos(a2)));
        if (dot(ax, ax) < 1e-4) continue;
        ax = normalize(ax);
        vec3 ay = cross(n, ax);
        float size = 0.085 + 0.04 * h.z;
        vec2 lp = vec2(dot(hp, ax), dot(hp, ay)) / size;
        // A leaf: an ellipse pointed at both ends.
        float e = lp.x * lp.x + lp.y * lp.y / max(0.22 * (1.0 - 0.6 * lp.x * lp.x), 1e-3);
        if (abs(lp.x) > 1.0 || e > 1.0) continue;
        best = tp;
        nBest = dn > 0.0 ? -n : n;
        // A few turn yellow or brown.
        float age = step(0.72, h.y) * (0.4 + 0.6 * h.x);
        res = vec4(vec3(1.0, 1.0 - 0.25 * age, 1.0 - 0.75 * age), smoothstep(1.0, 0.75, e));
    }
    return res;
}

// rgb = leaf colour (linear albedo), a = coverage; tHit = distance; nHit = normal.
vec4 fallingLeaves(vec3 rd, float maxDist, out float tHit, out vec3 nHit) {
    tHit = 1e9;
    nHit = vec3(0.0, 1.0, 0.0);
    float range = min(maxDist, 24.0);
    vec3 camCell = floor(cameraPosition);
    vec3 ro = cameraPosition - camCell;           // the camera inside its own block
    ivec3 hg = FF_SIZE / 2;
    vec4 hit = vec4(0.0);
    vec2 d = rd.xz;
    vec2 cell = floor(ro.xz);
    vec2 stp = vec2(d.x >= 0.0 ? 1.0 : -1.0, d.y >= 0.0 ? 1.0 : -1.0);
    vec2 tDelta = 1.0 / max(abs(d), vec2(1e-5));
    vec2 tNext = (stp * (cell - ro.xz) + max(stp, 0.0)) * tDelta;
    float tEnter = 0.0;
    // Wind: leaves from columns upwind may be blown across this one.
    float storm = saturate(0.5 * lfRain + lfThunder);
    vec2 wdir = windDirection();
    vec2 slant = wdir * windStrength() * mix(0.12, 1.2, storm);
    int upwind = length(slant) < 0.08 ? 0 : 4;
    for (int i = 0; i < 40; i++) {
        float tExit = min(min(tNext.x, tNext.y), range);
        ivec2 gi = ivec2(cell) + hg.xz;
        if (any(lessThan(gi, ivec2(0))) || any(greaterThanEqual(gi, FF_SIZE.xz))) break;
        float y0 = ro.y + rd.y * tEnter, y1 = ro.y + rd.y * tExit;
        for (int k = 0; k <= 4; k++) {
            if (k > upwind) break;
            ivec2 off = ivec2(round(-wdir * float(k)));
            if (k > 0 && off == ivec2(0)) continue;
            ivec2 si = gi + off;
            if (any(lessThan(si, ivec2(0))) || any(greaterThanEqual(si, FF_SIZE.xz))) continue;
            vec4 cp = texelFetch(lfCanopySampler, si, 0);
            if (cp.x < 0.0) continue;
            float topY = cp.x - float(hg.y), groundY = cp.y - float(hg.y);
            if (max(y0, y1) > groundY - 0.2 && min(y0, y1) < topY + 0.2) {
                vec3 n;
                float bestBefore = tHit;
                vec2 sc = cell + vec2(off);
                vec4 l = leavesInColumn(ivec2(sc), sc + camCell.xz, topY, groundY, ro, rd, tExit + 0.5, slant, tHit, n);
                if (tHit < bestBefore) {
                    vec4 lc = texelFetch(lfLeafColSampler, si, 0);
                    vec3 base = lc.a > 0.5 ? srgbToLinear(lc.rgb) : vec3(0.08, 0.18, 0.04);
                    hit = vec4(base * l.rgb, l.a);
                    nHit = n;
                }
            }
        }
        // Columns come in order along the ray: the first hit is the nearest.
        if (tHit < 1e8 || tExit >= range) break;
        tEnter = tExit;
        if (tNext.x < tNext.y) { cell.x += stp.x; tNext.x += tDelta.x; }
        else { cell.y += stp.y; tNext.y += tDelta.y; }
    }
    return hit;
}
#endif


#if USE_FLOODFILL == 1 && CANOPY_DRIPS_ON == 1
#define HAS_CANOPY_DRIPS
// Drips: while it rains and for about a minute after, drops gather on the edges of
// tree canopies and overhanging roofs and fall from there to the ground (not from
// the middle of a canopy, where you stay dry). Thin, quick streaks of light.

// How much this column's drops cover the ray: returns brightness weight (0..1).
float dripsInColumn(vec2 colW, vec2 cellP, float topY, float groundY, float side, vec3 rd, float tMax, float rate, float chance) {
    float fall = topY - groundY;
    if (fall < 1.5) return 0.0;
    const float g = 22.0;                                   // blocks per second squared
    float tf = sqrt(2.0 * fall / g);
    // The open side of the edge: drops form along it.
    vec2 sd = side < 0.5 ? vec2(1.0, 0.0) : side < 1.5 ? vec2(-1.0, 0.0) : side < 2.5 ? vec2(0.0, 1.0) : vec2(0.0, -1.0);
    vec2 along = vec2(-sd.y, sd.x);
    float res = 0.0;
    float dxz = dot(rd.xz, rd.xz);
    if (dxz < 1e-5) return 0.0;
    for (int k = 0; k < 3; k++) {
        vec3 h = hash33(vec3(colW, float(k) * 7.31 + 1.7));
        float period = max(rate * (0.6 + 0.8 * h.x), tf + 0.15);
        float tt = frameTimeCounter + h.y * 97.0;
        float cyc = floor(tt / period);
        if (hash12(vec2(cyc, h.z * 53.0 + colW.x * 0.13 + colW.y * 0.07)) > chance) continue;
        float tau = fract(tt / period) * period;
        if (tau > tf) continue;
        float v = g * tau;
        vec2 pxz = cellP + 0.5 + sd * 0.42 + along * (h.z - 0.5) * 0.8;
        float yb = topY - 0.5 * g * tau * tau;                 // the drop
        float len = clamp(v * 0.035, 0.05, 0.7);               // streaked by its speed
        // Nearest approach of the ray to the falling drop's vertical line.
        float tc = dot(rd.xz, pxz) / dxz;
        if (tc < 0.1 || tc > tMax) continue;
        float d = length(rd.xz * tc - pxz);
        float r = max(0.018, tc * 0.0012);                     // at least about a pixel wide
        if (d > r) continue;
        float y = rd.y * tc;
        if (y < yb || y > yb + len) continue;
        res += (1.0 - d / r) * (0.018 / r) * smoothstep(0.0, 0.05, tau);
    }
    return res;
}

// rgb: light the drops add along the ray, out to maxDist (the scene behind).
vec3 canopyDrips(vec3 rd, float maxDist, vec3 skyAmb, vec3 lightE) {
    // After the rain, lfDrip halves every 20 s, so this falls in a straight line:
    // the drops thin out evenly over a minute (all of them, then 5 in 6 after 10 s,
    // 4 in 6 after 20 s, and so on) and the last one falls a minute after the rain.
    float ease = saturate(1.0 + log2(max(lfDrip, 1e-4)) / 3.0);
    if (ease < 0.01) return vec3(0.0);
    float level = float(CANOPY_DRIPS);
    // Each edge drips a little slower as it drains, and fewer edges drip: together
    // the number of drops follows ease.
    float rate = 0.55 * mix(1.4, 1.0, ease) / (0.5 + 0.5 * level);
    float chance = ease * mix(1.4, 1.0, ease) * (0.45 + 0.25 * level);
    float range = min(maxDist, 28.0);
    vec3 camCell = floor(cameraPosition);
    vec3 ro = cameraPosition - camCell;
    ivec3 hg = FF_SIZE / 2;
    vec2 d = rd.xz;
    vec2 cell = floor(ro.xz);
    vec2 stp = vec2(d.x >= 0.0 ? 1.0 : -1.0, d.y >= 0.0 ? 1.0 : -1.0);
    vec2 tDelta = 1.0 / max(abs(d), vec2(1e-5));
    vec2 tNext = (stp * (cell - ro.xz) + max(stp, 0.0)) * tDelta;
    float tEnter = 0.0, acc = 0.0;
    vec3 lampAcc = vec3(0.0);
    for (int i = 0; i < 48; i++) {
        float tExit = min(min(tNext.x, tNext.y), range);
        ivec2 gi = ivec2(cell) + hg.xz;
        if (any(lessThan(gi, ivec2(0))) || any(greaterThanEqual(gi, FF_SIZE.xz))) break;
        vec4 cp = texelFetch(lfCanopySampler, gi, 0);
        if (cp.z >= 0.0) {
            float topCell = floor(cp.z);
            float side = (cp.z - topCell) * 4.0;
            // In the camera's own block frame (like the leaves).
            float topY = topCell - float(hg.y) - ro.y, groundY = cp.w - float(hg.y) - ro.y;
            vec2 cellP = cell - ro.xz;
            float a = dripsInColumn(cell + camCell.xz, cellP, topY, groundY, side, rd, min(tExit + 0.5, maxDist), rate, chance);
            if (a > 0.0) {
                acc += a;
                lampAcc += spreadLightAt(rd * tEnter) * a;
            }
        }
        if (tExit >= range) break;
        tEnter = tExit;
        if (tNext.x < tNext.y) { cell.x += stp.x; tNext.x += tDelta.x; }
        else { cell.y += stp.y; tNext.y += tDelta.y; }
    }
    // Water drops: bright with the sky they reflect, a glint of sun, any lamp nearby.
    return (skyAmb * 1.6 + lightE * 0.04) * min(acc, 1.5) * 0.55 + lampAcc * 0.5;
}
#endif

#endif
