/*
    Tempered Light - visible breath. Every so often you breathe out a little cloud
    of vapour from your mouth (below your eyes in first person, from your face in
    third person): faint in mild weather, plain to see in the cold, at night and in
    rain, gone in hot places and under water. You breathe about every 10 seconds;
    sprinting brings it down to every 3-4, easing back over 10-15 seconds once you
    slow down. Each breath leaves your mouth, slows, spreads and fades, drifting
    with the wind; it goes with you as you move, trailing back round you as it fades.

    The breathing clock lives in the composite1 vertex shader, which keeps it from
    frame to frame in a small custom image (with the Voxy/DH memory); the cloud is
    marched in the composite1 fragment shader.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_BREATH
#define LF_BREATH

#if defined IRIS_FEATURE_CUSTOM_IMAGES && !defined DIM_NETHER
#define HAS_BREATH

// Breaths per second: one every 10 s at rest, every 3.5 s when breathing hard.
float breathRate(float exert) { return 1.0 / mix(10.0, 3.5, exert); }

// How plainly the next breath shows (0 = not at all).
float breathVisibility() {
    if (BREATH <= 0.0 || isEyeInWater != 0 || isSpectator) return 0.0;
    float night = 1.0;
    #ifdef DIM_OVERWORLD
        vec3 sd = normalize(mat3(gbufferModelViewInverse) * sunPosition);
        night = 1.0 - smoothstep(-0.12, 0.15, sd.y);
    #endif
    float cold = saturate(max(lfCold, lfSnowHere));
    // Faint in mild weather; plain to see in the cold; a little more at night and in rain.
    float v = 0.12 + 0.58 * cold + 0.14 * night * (1.0 - cold) + 0.06 * lfRain;
    v *= 1.0 - saturate(lfWarm);
    // Breathing hard after a sprint: bigger, denser breaths.
    v *= 1.0 + 0.35 * saturate(lfExert);
    return saturate(v) * BREATH;
}

// One frame of the breathing clock. st: x clock (0..1, a breath each time it wraps),
// y start of the last breath, z how visible, w seed; og: xyz mouth (relative to the camera), w how
// hard; dr: xyz direction. dt: frame time; exert: how hard you are breathing.
void breathClock(inout vec4 st, inout vec4 og, inout vec4 dr, float dt, float exert) {
    if (!(st.x >= 0.0 && st.x < 4.0) || any(isnan(og)) || any(isnan(dr))) {
        st = vec4(0.6, -100.0, 0.0, 0.0); og = vec4(0.0); dr = vec4(0.0, 0.0, 1.0, 0.0);
    }
    float ph = st.x + dt * breathRate(exert);
    if (ph >= 1.0) {
        ph = fract(ph);
        // From your mouth: below your eyes, a little in front, the way you face
        // (your face in third person, whichever way the camera looks).
        vec3 look = playerLookVector;
        if (dot(look, look) < 0.01) look = mat3(gbufferModelViewInverse) * vec3(0.0, 0.0, -1.0);
        look = dot(look, look) > 1e-4 ? normalize(look) : vec3(0.0, 0.0, 1.0);
        vec3 fwd = normalize(vec3(look.x, 0.0, look.z) + vec3(1e-4, 0.0, 0.0));
        st.y = frameTimeCounter;
        st.z = breathVisibility();
        st.w = fract(st.w + 0.6180339);
        og = vec4(-relativeEyePosition + vec3(0.0, -0.17, 0.0) + fwd * 0.12, exert);
        dr = vec4(normalize(look * 0.6 + fwd * 0.4 + vec3(0.0, -0.25, 0.0)), 0.0);
    }
    st.x = ph;
}

// The breath's cloud: a short outflow (5 puffs a fraction of a second apart) that
// leaves the mouth, slows, spreads, rises a little and fades over about 2 seconds.
// a: time since the puff left; returns the puff's centre (world) and radius.
vec3 breathPuff(vec3 org, vec3 dir, float a, float k, float hard, out float r, out float fade) {
    float v0 = mix(1.3, 2.4, hard);
    float travel = v0 * 0.45 * (1.0 - exp(-a / 0.45));
    vec3 c = org + dir * travel;
    c.y += 0.10 * a * sqrt(a);                                 // warm, so it rises a little
    c.xz += windDirection() * windStrength() * 0.35 * a;      // and drifts with the wind
    // It goes with you (you see it in front of you even running): it keeps its own
    // push at first, then, slowing, falls back past you as you move and fades.
    float aa = min(a, 1.6);
    c.xz -= vec2(lfVelX, lfVelZ) * 0.25 * aa * aa;
    r = 0.045 + 0.26 * sqrt(a) * (1.0 + 0.12 * k);
    fade = smoothstep(0.0, 0.07, a) * exp(-a * 1.5) * (1.0 - 0.12 * k);
    return c;
}

// b: x start time of the last breath, y how visible, z seed, w how hard (0..1).
vec3 applyBreath(vec3 col, vec3 rd, float dist, vec4 b, vec3 org, vec3 dir,
                 vec3 amb, vec3 lightE, vec3 lightDir, float dither) {
    if (b.y <= 0.002) return col;
    float age = frameTimeCounter - b.x;
    if (age < 0.0) age += 3600.0;               // Iris's hourly clock reset
    if (age > 3.2) return col;
    // A sphere round the whole cloud, to march only where it is.
    // (org is where your mouth is, relative to the camera: the breath goes with you.)
    float la = min(age, 1.6);
    vec3 mid = org + dir * 0.55 + vec3(0.0, 0.15, 0.0) - vec3(lfVelX, 0.0, lfVelZ) * 0.125 * la * la;
    float R = 1.15 + 0.6 * windStrength() + length(vec2(lfVelX, lfVelZ)) * 0.125 * la * la + 0.1;
    float bq = dot(mid, rd);
    float cq = dot(mid, mid) - R * R;
    float disc = bq * bq - cq;
    if (disc <= 0.0) return col;
    float sq = sqrt(disc);
    float t0 = max(bq - sq, 0.06), t1 = min(bq + sq, dist);
    if (t1 <= t0) return col;
    const int N = 12;
    float dt = (t1 - t0) / float(N);
    float mu = dot(rd, lightDir);
    float ph = phaseHG(mu, 0.55) * 0.7 + 0.3 / (4.0 * PI);
    vec3 scat = vec3(0.0);
    float T = 1.0;
    float t = frameTimeCounter;
    for (int i = 0; i < N; i++) {
        vec3 p = rd * (t0 + dt * (float(i) + dither));        // player space
        vec3 pw = p - org;                                      // in the breath's own frame
        float dens = 0.0;
        for (int k = 0; k < 5; k++) {
            float a = age - 0.13 * float(k) * (1.0 + 0.4 * b.w);
            if (a <= 0.0) continue;
            float r, fade;
            vec3 c = breathPuff(org, dir, a, float(k), b.w, r, fade);
            vec3 d = p - c;
            dens += fade * exp(-dot(d, d) / (r * r) * 1.6);
        }
        if (dens < 0.004) continue;
        // Wisps: the cloud breaks up as it spreads.
        float n = vnoise3(pw * 6.0 + vec3(b.z * 37.0, -t * 0.9, 0.0)) * 0.6 + vnoise3(pw * 13.0 - vec3(0.0, t * 1.4, b.z * 11.0)) * 0.4;
        dens *= saturate(n * 1.7 - 0.25);
        float sigma = dens * 7.0 * b.y;
        // Fine droplets: they catch the sky's light from all round and moonlight or
        // lamplight strongly, so a breath shows up even at night.
        vec3 L = amb * 1.5 + lightE * ph * 1.4;
        #if USE_FLOODFILL == 1 && defined LF_FLOODFILL
            L += spreadLightAt(p) * 1.2;
        #endif
        float al = 1.0 - exp(-sigma * dt);
        scat += T * vec3(0.92, 0.94, 0.97) * L * al;
        T *= 1.0 - al;
    }
    return col * T + scat;
}
#endif

#endif
