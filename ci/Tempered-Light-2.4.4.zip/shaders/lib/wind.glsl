/*
    Tempered Light - one wind for plants, water and clouds.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_WIND
#define LF_WIND

// Wind direction drifts slowly around the chosen heading.
vec2 windDirection() {
    float a = radians(float(WIND_DIRECTION)) + 0.35 * sin(frameTimeCounter * 0.0021) + 0.15 * sin(frameTimeCounter * 0.0137);
    return vec2(cos(a), sin(a));
}

// 0..~2.5, stronger in rain and storms.
float windStrength() {
    return WIND_STRENGTH * (0.55 + 0.6 * lfRain + 0.6 * lfThunder);
}

// Gusts roll across the world in the wind direction.
float windGust(vec2 worldXZ, float t) {
    vec2 d = windDirection();
    float along = dot(worldXZ, d);
    float g = vnoise(vec2(along * 0.035 - t * 0.9, dot(worldXZ, vec2(-d.y, d.x)) * 0.02));
    return smoothstep(0.25, 0.85, g);
}

#endif
