/*
    Tempered Light - smoke that drifts with the wind. Minecraft sends smoke and
    embers straight up; here a particle looks down through the light grid for the
    fire, campfire, torch, candle, furnace or lava it rose from, and the higher it
    has climbed above it, the further the wind carries it downwind, swaying a
    little from side to side. Indoors (no sky above) it still rises straight.
    Needs the light grid (Coloured Light).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_SMOKE
#define LF_SMOKE

#if SMOKE_DRIFT == 1 && USE_FLOODFILL == 1
#define HAS_SMOKE_DRIFT

bool isSmokeSource(int c) {
    return c == CAT_FIRE || c == CAT_SOUL_FIRE || c == CAT_CAMPFIRE || c == CAT_SOUL || c == CAT_TORCH ||
           c == CAT_COPPER_TORCH || c == CAT_CANDLE || c == CAT_FURNACE || c == CAT_LAVA || c == CAT_SOUL_CAMPFIRE;
}

// How far above the nearest smoke source below it (in its own column or the ones
// round it, up to 24 blocks down) this point is, or -1 if there is none.
float heightAboveSmokeSource(vec3 worldPos) {
    ivec3 v0 = ffVoxelFromWorld(worldPos);
    int best = 99;
    for (int dz = -1; dz <= 1; dz++) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = 0; dy <= 24; dy++) {
                if (dy >= best) break;
                ivec3 v = v0 + ivec3(dx, -dy, dz);
                if (!ffInside(v)) break;
                uint w = texelFetch(lfVoxelSampler, v, 0).r;
                if (w == 0u) continue;
                if (ffLevel(w) > 0 && isSmokeSource(ffCat(w))) { best = dy; break; }
                if (ffSolid(w)) break;        // a solid block in between: not this column's smoke
            }
        }
    }
    if (best > 24) return -1.0;
    // Measured from the top of the source block's flames (about half a block up).
    return worldPos.y - (floor(worldPos.y) - float(best) + 0.5);
}

// Offset (player space) for a particle vertex at worldPos.
vec3 smokeDrift(vec3 worldPos, float skyLight) {
    float h = heightAboveSmokeSource(worldPos);
    if (h <= 0.0) return vec3(0.0);
    h = max(h - 0.5, 0.0);                       // flames stay on the fire
    float outdoor = smoothstep(0.35, 0.85, skyLight);
    if (outdoor <= 0.0) return vec3(0.0);
    vec2 d = windDirection();
    float s = windStrength();
    // Carried further the higher it climbs, curving away from the fire.
    float carry = min(0.22 * h + 0.018 * h * h, 7.0);
    float sway = sin(frameTimeCounter * 0.7 + h * 0.9 + dot(worldPos.xz, vec2(0.37, 0.29))) * min(h, 6.0) * 0.06;
    vec2 xz = (d * carry + vec2(-d.y, d.x) * sway) * s * outdoor;
    return vec3(xz.x, 0.0, xz.y);
}
#endif

#endif
