/*
    Tempered Light - Nether portals (Portal Style: Vortex or Rift). Instead of a
    flat animated sheet, each portal is a swirling vortex seen a little way into
    it: bright strands of energy turning and spiralling in towards a white-hot
    core, dark smoky tendrils reaching across it, smoke curling off the frame and
    a glowing mist that spills out of it and pools at its foot.

    A compute pass (portal_comp.glsl) finds each portal in the light grid (its
    bottom corner, how wide and how tall it is) and lists them in a spare row of
    the smoke image, so every block of a portal knows where the portal's middle is
    and the vortex is centred on the whole portal, whatever its size. Portals
    beyond the light grid (or with Light Spread off) get the same energy flowing
    across them, without the core.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_PORTAL
#define LF_PORTAL

#if PORTAL_LIST == 1
#define PORTAL_ROW (FF_SIZE_XZ / 4 + 1)   // the row of lfSmoke after the smoke list
#define PORTAL_MAX 15

// Portal word: bottom corner in the light grid (x bits 0-6, y 7-13, z 14-20), 21 the
// way it runs (0 along x, 1 along z), width-1 (22-26), height-1 (27-31).
uint portalPack(ivec3 a, int axis, int w, int h) {
    return uint(a.x & 127) | (uint(a.y & 127) << 7u) | (uint(a.z & 127) << 14u) | (uint(axis & 1) << 21u) |
           (uint(clamp(w - 1, 0, 31)) << 22u) | (uint(clamp(h - 1, 0, 31)) << 27u);
}
void portalUnpack(uint u, out ivec3 a, out int axis, out int w, out int h) {
    a = ivec3(u & 127u, (u >> 7u) & 127u, (u >> 14u) & 127u);
    axis = int((u >> 21u) & 1u);
    w = int((u >> 22u) & 31u) + 1;
    h = int((u >> 27u) & 31u) + 1;
}

#ifndef FF_COMPUTE
#ifndef LF_SMOKE_SAMPLER
#define LF_SMOKE_SAMPLER
uniform usampler2D lfSmokeSampler;
#endif

int portalCount() { return min(int(texelFetch(lfSmokeSampler, ivec2(0, PORTAL_ROW), 0).r), PORTAL_MAX); }

// The portal i of the list: its middle (player space), half its width and height
// (blocks), the way it runs, and how close it is to the edge of the light grid (the
// vortex gives way to the plain energy there, before the portal leaves the grid).
void portalGet(int i, out vec3 centre, out vec2 halfSize, out int axis, out float fade, out ivec3 a) {
    uint u = texelFetch(lfSmokeSampler, ivec2(1 + i, PORTAL_ROW), 0).r;
    int w, h;
    portalUnpack(u, a, axis, w, h);
    vec3 da = axis == 0 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 0.0, 1.0);
    vec3 lo = vec3(a - FF_SIZE / 2) + (floor(cameraPosition) - cameraPosition);
    centre = lo + da * (float(w) * 0.5) + vec3(0.0, float(h) * 0.5, 0.0) + (vec3(1.0, 0.0, 1.0) - da) * 0.5;
    halfSize = vec2(w, h) * 0.5;
    vec3 half3 = vec3(FF_SIZE / 2);
    vec3 m = max(abs(vec3(a) - half3), abs(vec3(a) + da * float(w) + vec3(0.0, float(h), 0.0) - half3));
    vec3 rel = m / half3;
    fade = smoothstep(0.72, 0.94, max(rel.x, max(rel.y, rel.z)));
}

// Which listed portal the block at blockCentre (player space) belongs to: -1 none.
int portalFind(vec3 blockCentre, out vec3 centre, out vec2 halfSize, out int axis, out float fade) {
    ivec3 v = ffVoxelFromWorld(blockCentre + cameraPosition);
    int n = portalCount();
    centre = vec3(0.0); halfSize = vec2(1.0); axis = 0; fade = 1.0;
    for (int i = 0; i < n; i++) {
        ivec3 a;
        portalGet(i, centre, halfSize, axis, fade, a);
        ivec3 d = v - a;
        int al = axis == 0 ? d.x : d.z, ac = axis == 0 ? d.z : d.x;
        if (ac == 0 && d.y >= 0 && float(d.y) < halfSize.y * 2.0 && al >= 0 && float(al) < halfSize.x * 2.0) return i;
    }
    centre = vec3(0.0); halfSize = vec2(1.0); axis = 0; fade = 1.0;
    return -1;
}

// A light source at srcPos (world) that is part of a listed portal lights as one big
// glowing panel: nearest is its nearest point to p (world), pick the point at u (0..1)
// across it (for soft shadows). false if srcPos is in no listed portal.
bool portalPanel(vec3 srcPos, vec3 p, vec2 u, out vec3 nearest, out vec3 pick) {
    vec3 c; vec2 h; int ax; float fade;
    nearest = srcPos; pick = srcPos;
    if (portalFind(srcPos - cameraPosition, c, h, ax, fade) < 0) return false;
    vec3 cw = c + cameraPosition;
    vec3 da = ax == 0 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 0.0, 1.0);
    vec3 rel = p - cw;
    vec2 q = clamp(vec2(dot(rel, da), rel.y), -h + 0.5, h - 0.5);
    nearest = cw + da * q.x + vec3(0.0, q.y, 0.0);
    vec2 r = (u * 2.0 - 1.0) * (h - 0.1);
    pick = cw + da * r.x + vec3(0.0, r.y, 0.0);
    return true;
}
#endif
#endif

// ------------------------------------------------------------- shading ----
#if PORTAL_STYLE != 0 && !defined FF_COMPUTE

// Dark to white-hot as the light gets stronger (x: about 0 to 5, the core above).
vec3 portalHue(float x) {
    #if PORTAL_STYLE == 2
        // Rift: blood red, fiery orange strands, a white-hot heart.
        vec3 c0 = vec3(0.30, 0.008, 0.006), c1 = vec3(1.00, 0.035, 0.018), c2 = vec3(1.00, 0.17, 0.06), c3 = vec3(1.00, 0.78, 0.62);
    #else
        // Vortex: deep violet, purple strands, lilac, a white-hot heart.
        vec3 c0 = vec3(0.16, 0.025, 0.42), c1 = vec3(0.46, 0.09, 1.00), c2 = vec3(0.86, 0.42, 1.00), c3 = vec3(1.00, 0.90, 1.00);
    #endif
    vec3 c = mix(c0, c1, smoothstep(0.0, 0.9, x));
    c = mix(c, c2, smoothstep(1.2, 3.0, x));
    return mix(c, c3, smoothstep(3.0, 5.5, x));
}
vec3 portalLight(float x) { return portalHue(x) * x; }
// The colour of the smoke and tendrils (all but black, a little of the glow in them).
vec3 portalSmokeCol() {
    #if PORTAL_STYLE == 2
        return vec3(0.030, 0.004, 0.003);
    #else
        return vec3(0.012, 0.004, 0.030);
    #endif
}

const mat3 PORTAL_OCT = mat3(0.00, 0.80, 0.60, -0.80, 0.36, -0.48, -0.60, -0.48, 0.64);
float portalFbm(vec3 p, int oct) {
    float s = 0.0, a = 0.5, n = 0.0;
    for (int i = 0; i < oct; i++) {
        s += a * vnoise3(p);
        n += a;
        p = PORTAL_OCT * p * 2.03 + vec3(3.1, 7.7, 1.3);
        a *= 0.5;
    }
    return s / n;
}
// Strands of energy spiralling in: noise sampled on a log-spiral grid, so it streams
// along the arms and in towards the middle, getting finer as it goes (no winding up
// over time). q: position / vortex radius.
float portalStrands(vec2 q, float t, float seed, int oct) {
    float r = length(q);
    float th = atan(q.y, q.x);
    float lr = log(r + 0.035);
    vec3 cw = vec3(cos(th), sin(th), 0.0);
    float w = vnoise3(cw * 1.4 + vec3(seed, 0.0, lr * 0.9 + t * 0.23)) - 0.5;
    float ph = th + 1.85 * lr - t * 0.55 + w * 1.5;
    vec3 c = vec3(cos(ph), sin(ph), 0.0) * 2.3 + vec3(seed * 3.7, seed * 1.3, lr * 0.8 + t * 0.30 + w * 0.6);
    float n = portalFbm(c, oct);
    float f = 1.0 - abs(2.0 * n - 1.0);
    return f * f * (3.0 - 2.0 * f);
}

// The vortex. p: position in the portal (blocks from its middle: x across, y up),
// h: half its width and height, vin: the view direction in the portal's frame (z
// into it), t: time (swirl speed already in it). Returns light (rgb) and cover (a).
vec4 portalVortex(vec2 p, vec2 h, vec3 vin, float t, float dist) {
    float s = clamp(min(h.x, h.y), 0.75, 12.0);
    int oct = dist < 14.0 ? 4 : (dist < 40.0 ? 3 : 2);
    vec2 par = vin.xy / max(vin.z, 0.5);           // sideways shift per block of depth
    float pulse = 1.0 + 0.09 * sin(t * 1.7) + 0.05 * sin(t * 4.3 + 1.3);
    float e = min(h.x - abs(p.x), h.y - abs(p.y)); // blocks to the frame
    vec3 acc = vec3(0.0);
    float T = 1.0;

    // Front: smoke curling off the frame, dark tendrils, wisps of glowing mist.
    {
        vec2 q = p / s;
        float r = length(q);
        // Smoke: thick against the obsidian, breaking into curls that drift up.
        float sn = portalFbm(vec3(p * 1.6 + vec2(0.0, -t * 0.3), t * 0.2), 3);
        float sn2 = vnoise3(vec3(p * 4.0 + vec2(0.0, -t * 0.5), t * 0.4));
        float reachS = 0.55 + 0.25 * s / (s + 2.0);
        float smoke = 1.0 - smoothstep(-0.1, reachS, e + (sn - 0.5) * 1.3 + (sn2 - 0.5) * 0.3);
        smoke = smoke * smoke * (3.0 - 2.0 * smoke);
        float tend = 0.0, rim = 0.0;
        if (PORTAL_TENDRILS > 0.0) {
            // Veins reaching in from the edge and branching, drifting slowly round:
            // where two noises cross the middle of their range (their contour lines).
            float th = atan(q.y, q.x) + t * 0.03;
            float lr = log(r + 0.05);
            float wv = portalFbm(vec3(q * 2.0, t * 0.06), 2) - 0.5;
            vec3 c = vec3(cos(th + wv * 0.8), sin(th + wv * 0.8), 0.0) * 2.6 + vec3(9.1, 2.3, lr * 0.7 - t * 0.05);
            float l1 = 1.0 - abs(2.0 * vnoise3(c) - 1.0);
            float l2 = 1.0 - abs(2.0 * vnoise3(c * 2.3 + vec3(4.4, 1.7, 0.6)) - 1.0);
            float reach = smoothstep(0.2, 1.0, r + 0.35 * (sn - 0.5));
            float w1 = (0.03 + 0.15 * reach) * (0.7 + 0.3 * PORTAL_TENDRILS);
            float w2 = (0.02 + 0.06 * reach) * (0.7 + 0.3 * PORTAL_TENDRILS);
            float v1 = smoothstep(1.0 - w1, 1.0 - w1 * 0.35, l1);
            float v2 = smoothstep(1.0 - w2, 1.0 - w2 * 0.35, l2) * smoothstep(0.55, 0.9, l1);
            tend = saturate(v1 + v2) * smoothstep(0.0, 0.35, reach) * min(PORTAL_TENDRILS, 1.0);
            // A glowing edge round each vein.
            rim = saturate(smoothstep(1.0 - w1 * 2.6, 1.0 - w1, l1) + smoothstep(1.0 - w2 * 2.6, 1.0 - w2, l2) * smoothstep(0.55, 0.9, l1));
            rim *= smoothstep(0.0, 0.35, reach) * (1.0 - tend) * min(PORTAL_TENDRILS, 1.0);
        }
        // Glowing mist drifting across the front, turning with the vortex.
        float mn = portalFbm(vec3(rot2(t * 0.12) * q * 1.6, t * 0.11 + 4.0), 3);
        float mist = smoothstep(0.55, 0.9, mn) * 0.22 * smoothstep(0.15, 0.6, r);
        float aDark = saturate(max(smoke * 0.95, tend * 0.92));
        float aMist = mist * (1.0 - aDark);
        vec3 l = portalSmokeCol() * aDark * (1.0 + 2.0 * (1.0 - smoke) * tend) + portalLight(0.25 + 0.25 * mn) * aMist
               + portalLight(1.3) * rim * 0.35 * (1.0 - aDark);
        acc += l;
        T *= 1.0 - saturate(aDark + aMist);
    }

    // Middle: the main strands of energy, a little way in.
    {
        vec2 pp = p + par * (0.35 * s);
        vec2 q = pp / s;
        float r = length(q);
        float f = portalStrands(q, t, 0.0, oct);
        float prof = smoothstep(1.9, 0.1, r);              // brighter towards the middle
        float f4 = f * f; f4 *= f4;
        float I = (0.03 + 0.4 * f * f + 0.65 * f4) * (0.3 + 1.0 * prof * prof);
        float a = smoothstep(0.15, 0.85, f) * (0.6 + 0.35 * prof);
        acc += T * portalLight(I) * a;
        T *= 1.0 - a;
    }

    // Back: deeper, slower strands and the white-hot core, far in.
    {
        vec2 pp = p + par * (0.95 * s);
        vec2 q = pp / (s * 0.85);
        float r = length(q);
        float f = portalStrands(q * 1.15, t * 0.6, 4.2, max(oct - 1, 2));
        float I = (0.06 + 0.5 * f * f) * (0.35 + 0.9 * smoothstep(1.5, 0.0, r));
        float core = (exp(-r * r * 30.0) * 5.5 + exp(-r * 6.0) * 0.9) * pulse * PORTAL_CORE;
        acc += T * portalLight(I + core);
        T = 0.0;
    }
    return vec4(acc, 1.0 - T);
}

// Without a known middle: the same energy flowing up across the portal, no core.
// u: position in the portal's plane (blocks; any origin).
vec4 portalFlow(vec2 u, float t, float dist) {
    int oct = dist < 14.0 ? 4 : (dist < 40.0 ? 3 : 2);
    vec2 w = vec2(portalFbm(vec3(u * 0.6, t * 0.12), 2), portalFbm(vec3(u * 0.6 + 5.2, t * 0.12), 2)) - 0.5;
    vec3 c = vec3(u * vec2(1.1, 0.7) + w * 1.8 + vec2(0.0, -t * 0.3), t * 0.2);
    float n = portalFbm(c, oct);
    float f = 1.0 - abs(2.0 * n - 1.0);
    f = f * f * (3.0 - 2.0 * f);
    float f4 = f * f; f4 *= f4;
    // Dark smoky patches drifting through it.
    float dk = smoothstep(0.55, 0.8, portalFbm(vec3(u * 0.8 + vec2(0.0, -t * 0.15), t * 0.1 + 7.0), 2));
    float I = (0.1 + 0.45 * f * f + 0.7 * f4) * (1.0 - 0.8 * dk);
    return vec4(portalLight(I), 1.0);
}

// The glowing mist round a portal: a thin billowing layer over its face and mist
// spilling out of its foot, pooling on the ground in front and behind, lit by the
// portal. In the portal's own frame (x across, y up, z through it; the middle of the
// portal at 0): ro, rd the view ray, tMax how far it goes, h half the portal's size.
// Returns the light scattered towards you (rgb) and what still gets through (a).
vec4 portalMist(vec3 ro, vec3 rd, float tMax, vec2 h, float t, float dither) {
    float s = clamp(min(h.x, h.y), 0.75, 12.0);
    vec3 lo = vec3(-h.x - 2.0, -h.y - 1.0, -3.2 - 0.45 * s), hi = vec3(h.x + 2.0, h.y + 0.6, 3.2 + 0.45 * s);
    vec3 inv = 1.0 / (rd + vec3(1e-6));
    vec3 a = (lo - ro) * inv, b = (hi - ro) * inv;
    vec3 tn = min(a, b), tf = max(a, b);
    float t0 = max(max(tn.x, max(tn.y, tn.z)), 0.0), t1 = min(min(tf.x, min(tf.y, tf.z)), tMax);
    if (t1 <= t0) return vec4(0.0, 0.0, 0.0, 1.0);
    const int N = 14;
    float dt = (t1 - t0) / float(N);
    vec3 scat = vec3(0.0);
    float T = 1.0;
    float ground = -h.y - 1.0;                 // the top of the frame's bottom row
    for (int i = 0; i < N; i++) {
        vec3 p = ro + rd * (t0 + dt * (float(i) + dither));
        float az = abs(p.z);
        // Outside the portal's outline, how far (blocks).
        vec2 o = max(abs(p.xy) - h, 0.0);
        float out2 = dot(o, o);
        // Drifting out of the portal and sinking: noise carried away from its face.
        vec3 q = vec3(p.x * 0.9, p.y * 0.9 + t * 0.10, az * 0.8 - t * 0.35);
        float n = portalFbm(q + vec3(0.0, 0.0, 3.0), 3);
        // A layer billowing over the face, curling a little way over the frame.
        float face = exp(-az / (0.15 + 0.4 * n)) * exp(-out2 * 10.0);
        // Spilling from the foot and pooling on the ground in front and behind.
        float hy = p.y - ground;
        float spill = exp(-max(abs(p.x) - h.x + 0.3, 0.0) / 0.9) * smoothstep(hi.x, hi.x - 0.8, abs(p.x)) * smoothstep(hi.z, hi.z - 1.2, az);
        float pool = exp(-max(hy, 0.0) / (0.3 + 0.4 * n)) * exp(-max(az - 0.3, 0.0) / (1.2 + 0.35 * s)) * spill * smoothstep(-0.25, 0.1, hy);
        // Falling from the bottom of the portal down over the frame's bottom row.
        float fall = exp(-max(az - 0.25, 0.0) / 0.35) * smoothstep(0.4, -0.2, p.y + h.y) * spill;
        float d = (face * 0.7 + pool * 1.8 + fall * 0.6) * smoothstep(0.3, 0.72, n);
        if (d < 0.003) continue;
        float sigma = d * 1.6 * PORTAL_MIST;
        // Lit by the portal: brighter the closer to its face.
        float near = exp(-az / (0.8 + 0.3 * s)) * exp(-out2 * 0.5);
        vec3 L = portalLight(0.3 + 1.1 * near) * (0.4 + 0.6 * near);
        float al = 1.0 - exp(-sigma * dt);
        scat += T * L * al;
        T *= 1.0 - al;
    }
    return vec4(scat, T);
}
#endif

#if PORTAL_LIST == 1 && !defined FF_COMPUTE
#define HAS_PORTAL_MIST
// The mist round every listed portal along a view ray (player space, from you).
vec3 applyPortalMists(vec3 col, vec3 rd, float dist, float dither) {
    if (PORTAL_MIST <= 0.0) return col;
    int n = portalCount();
    float t = frameTimeCounter * PORTAL_SWIRL;
    for (int i = 0; i < n; i++) {
        vec3 c; vec2 h; int axis; float fade; ivec3 a;
        portalGet(i, c, h, axis, fade, a);
        if (fade >= 1.0) continue;
        vec3 da = axis == 0 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 0.0, 1.0);
        vec3 dn = axis == 0 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
        vec3 ro = vec3(dot(-c, da), -c.y, dot(-c, dn));
        vec3 rl = vec3(dot(rd, da), rd.y, dot(rd, dn));
        vec4 m = portalMist(ro, rl, min(dist, 512.0), h, t + float(i) * 7.3, dither);
        m = mix(m, vec4(0.0, 0.0, 0.0, 1.0), fade);
        col = col * m.a + m.rgb * EMISSIVE_STRENGTH;
    }
    return col;
}
#endif

#endif
