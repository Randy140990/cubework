/*
    Tempered Light - End portals (End Portal Style: Void). The portal is a window
    into the End: looking down into it you look out into the End's heavens, the
    black hole with its blazing disc straight below, the gas winding in towards it
    and the stars, infinitely far away, with drifting star dust in the dark just
    under the surface. And the void breathes out: violet and teal vapour rises off
    the pool as a low mist that spills over the frame, like the mist round the End's
    islands, carrying fine sparks of light that drift up, twinkle and fade.

    End portals are block entities, so the light grid only learns of them from the
    corners of their faces (lib/floodfill.glsl, occlusion_comp.glsl); a compute pass
    (portal_comp.glsl) lists each pool's outline for the vapour and sparks.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_ENDPORTAL
#define LF_ENDPORTAL

#if END_PORTAL_LIST == 1
#define END_ROW (FF_SIZE_XZ / 4 + 2)     // the row of lfSmoke after the Nether portals
#define END_POOL_MAX 15
#define END_POOL_REACH 6                // pools up to 13 blocks across

// Pool word: first corner of its outline in the light grid (x bits 0-6, y 7-13,
// z 14-20), width-1 (21-25) and depth-1 (26-30).
uint endPoolPack(ivec3 lo, ivec2 size) {
    return uint(lo.x & 127) | (uint(lo.y & 127) << 7u) | (uint(lo.z & 127) << 14u) |
           (uint(clamp(size.x - 1, 0, 31)) << 21u) | (uint(clamp(size.y - 1, 0, 31)) << 26u);
}
void endPoolUnpack(uint u, out ivec3 lo, out ivec2 size) {
    lo = ivec3(u & 127u, (u >> 7u) & 127u, (u >> 14u) & 127u);
    size = ivec2((u >> 21u) & 31u, (u >> 26u) & 31u) + 1;
}

#ifndef FF_COMPUTE
#ifndef LF_SMOKE_SAMPLER
#define LF_SMOKE_SAMPLER
uniform usampler2D lfSmokeSampler;
#endif

int endPoolCount() { return min(int(texelFetch(lfSmokeSampler, ivec2(0, END_ROW), 0).r), END_POOL_MAX); }

// Pool i: the corner of its outline at the portal's surface (player space; the
// surface is 3/4 of the way up the block) and its width and depth (blocks).
void endPoolGet(int i, out vec3 lo, out vec2 size) {
    ivec3 a; ivec2 s;
    endPoolUnpack(texelFetch(lfSmokeSampler, ivec2(1 + i, END_ROW), 0).r, a, s);
    lo = vec3(a - FF_SIZE / 2) + (floor(cameraPosition) - cameraPosition) + vec3(0.0, 0.75, 0.0);
    size = vec2(s);
}

// Which listed pool the End portal surface at worldPos (world) belongs to: its middle
// (world x, z) and half its smaller side. false if none.
bool endPoolAt(vec3 worldPos, out vec2 c, out float s) {
    vec3 p = worldPos - cameraPosition;
    int n = endPoolCount();
    c = vec2(0.0); s = 1.0;
    for (int i = 0; i < n; i++) {
        vec3 lo; vec2 size;
        endPoolGet(i, lo, size);
        if (all(greaterThan(p.xz, lo.xz - 0.05)) && all(lessThan(p.xz, lo.xz + size + 0.05)) && p.y > lo.y - 1.0 && p.y < lo.y + 0.5) {
            c = lo.xz + size * 0.5 + cameraPosition.xz;
            s = 0.5 * min(size.x, size.y);
            return true;
        }
    }
    return false;
}

// The mist and sparks round one pool, along a view ray from you (player space).
// lo, size: the pool (endPoolGet). Like the mist round the End's islands: it lies
// low and thick on the pool, spills over the frame and pools on the floor round it,
// slowly turning, with wisps rising off it and fine sparks drifting up through it.
// Returns light (rgb) and what gets through (a).
vec4 endPortalBreath(vec3 rd, float dist, vec3 lo, vec2 size, float t, float seed, float dither) {
    const float H = 3.0;                       // how high the wisps rise
    vec3 bmin = vec3(lo.x - 3.0, lo.y - 0.8, lo.z - 3.0), bmax = vec3(lo.x + size.x + 3.0, lo.y + H, lo.z + size.y + 3.0);
    vec3 inv = 1.0 / (rd + vec3(1e-6));
    vec3 ta = bmin * inv, tb = bmax * inv;     // (you are at the origin)
    vec3 tn = min(ta, tb), tf = max(ta, tb);
    float t0 = max(max(tn.x, max(tn.y, tn.z)), 0.0), t1 = min(min(tf.x, min(tf.y, tf.z)), dist);
    if (t1 <= t0) return vec4(0.0, 0.0, 0.0, 1.0);
    vec2 c = lo.xz + size * 0.5, hs = size * 0.5;
    vec3 scat = vec3(0.0);
    float T = 1.0;
    if (END_PORTAL_VAPOUR > 0.0) {
        const int N = 14;
        float dt = (t1 - t0) / float(N);
        float rot = t * 0.07;
        mat2 R = mat2(cos(rot), sin(rot), -sin(rot), cos(rot));
        for (int i = 0; i < N; i++) {
            vec3 p = rd * (t0 + dt * (float(i) + dither));
            vec2 rel = p.xz - c;
            // How far outside the pool (blocks): over the frame, then down on the floor.
            vec2 o = max(abs(rel) - hs, 0.0);
            float e = length(o);
            float base = lo.y + mix(0.0, 0.06, smoothstep(0.0, 0.2, e)) - 0.81 * smoothstep(0.9, 1.25, e);
            float h = p.y - base;
            if (h < -0.05) continue;
            vec2 q = R * rel;
            vec3 nq = vec3(q * 1.3, p.y * 1.1 - t * 0.16) + seed;
            float w = vnoise3(nq * 0.45 + vec3(0.0, 0.0, t * 0.05)) - 0.5;
            float n = vnoise3(nq + vec3(w * 1.8, w * 1.2, 0.0)) * 0.6 + vnoise3(nq * 2.2 + 5.3) * 0.28 + vnoise3(nq * 4.8 + 1.7) * 0.12;
            // The low layer, thickest on the pool, thinning out across the floor.
            float spread = exp(-max(e - 0.6, 0.0) / 0.8) * smoothstep(3.0, 2.0, e);
            // Thinner over the middle of the pool, so you can see down into it.
            vec2 ins = hs - abs(rel);
            float rim = mix(0.3, 1.0, smoothstep(0.9, 0.1, min(ins.x, ins.y)));
            float layer = exp(-max(h, 0.0) / (0.25 + 0.3 * n)) * smoothstep(-0.05, 0.08, h) * spread * rim;
            // Wisps rising off the pool itself.
            float over = smoothstep(0.35, -0.2, e - 0.25 * min(h, 2.0));
            float wisps = over * exp(-max(h, 0.0) / 0.8) * smoothstep(0.55, 0.85, n) * 0.35;
            float d = layer * smoothstep(0.3, 0.7, n) + wisps;
            if (d < 0.002) continue;
            float sigma = d * 1.0 * END_PORTAL_VAPOUR;
            // Lit by the portal: glowing over it, dimmer out on the floor.
            float lit = exp(-e / 1.1) * (0.35 + 0.65 * exp(-max(p.y - lo.y, 0.0) / 0.7));
            vec3 L = mix(vec3(0.16, 0.10, 0.34), vec3(0.58, 0.36, 1.0), lit);
            L = mix(L, vec3(0.32, 0.85, 0.80), smoothstep(0.62, 0.85, vnoise3(nq * 0.6 + 3.0)) * 0.35 * lit);
            L *= 0.05 + 0.55 * lit;
            float al = 1.0 - exp(-sigma * dt);
            scat += T * L * al;
            T *= 1.0 - al;
        }
    }
    // Sparks: fine points of light drifting up out of the pool, twinkling and fading.
    if (END_PORTAL_SPARKS > 0.0) {
        int n = int(min(3.0 * size.x * size.y, 30.0) * min(END_PORTAL_SPARKS, 2.0));
        float pix = 1.2 / viewHeight;            // about a pixel, in radians
        for (int k = 0; k < 60; k++) {
            if (k >= n) break;
            vec4 h0 = vec4(hash13(vec3(float(k), seed, 1.0)), hash13(vec3(float(k), seed, 2.0)),
                           hash13(vec3(float(k), seed, 3.0)), hash13(vec3(float(k), seed, 4.0)));
            float life = 3.5 + 3.0 * h0.x;
            float age = t / life + h0.y;
            float cyc = floor(age);
            float ph = age - cyc;
            vec3 r = hash33(vec3(float(k), cyc, seed));
            vec3 sp = vec3(lo.x + 0.1 + r.x * (size.x - 0.2), lo.y + pow(ph, 0.9) * (0.8 + 2.2 * r.z), lo.z + 0.1 + r.y * (size.y - 0.2));
            sp.xz += vec2(sin(ph * 4.0 + r.x * 20.0), cos(ph * 3.0 + r.y * 20.0)) * 0.25 * ph;
            float tc = dot(sp, rd);
            if (tc <= 0.0 || tc > dist) continue;
            float dd = length(sp - rd * tc);
            float rad = max(0.009, tc * pix);
            float tw = 0.6 + 0.4 * sin(t * (5.0 + 6.0 * h0.z) + h0.w * 40.0);
            float b = smoothstep(0.0, 0.1, ph) * (1.0 - smoothstep(0.5, 1.0, ph)) * tw * min(END_PORTAL_SPARKS, 1.5);
            vec3 sc = mix(vec3(0.45, 1.0, 0.88), vec3(0.82, 0.55, 1.0), step(0.5, h0.w));
            sc = mix(sc, vec3(1.0, 0.9, 1.0), step(0.85, h0.z));
            scat += T * sc * b * exp(-dd * dd / (rad * rad)) * 2.6 * sqr(0.009 / rad);
        }
    }
    return vec4(scat, T);
}

// Vapour and sparks over every listed pool, along a view ray (player space, from you).
vec3 applyEndPortalBreath(vec3 col, vec3 rd, float dist, float dither) {
    if (END_PORTAL_VAPOUR <= 0.0 && END_PORTAL_SPARKS <= 0.0) return col;
    int n = endPoolCount();
    float t = frameTimeCounter;
    for (int i = 0; i < n; i++) {
        vec3 lo; vec2 size;
        endPoolGet(i, lo, size);
        vec4 m = endPortalBreath(rd, min(dist, 512.0), lo, size, t, float(i) * 13.7 + 2.0, dither);
        col = col * m.a + m.rgb * EMISSIVE_STRENGTH;
    }
    return col;
}
#endif
#endif

// ------------------------------------------------------- the window -----
#if END_PORTAL_STYLE == 1 && defined LF_OTHERSKY && !defined FF_COMPUTE
// Looking into the portal is looking out into the End's sky: straight down is the
// black hole, and everything round it is drawn in closer (zoomed in 1.8 times).
vec3 endPortalSkyDir(vec3 rd) {
    float cd = clamp(-abs(rd.y), -1.0, 1.0);
    float th = acos(-cd) / 1.8;
    vec2 s = rd.xz;
    float sl = length(s);
    s = sl > 1e-5 ? s / sl : vec2(1.0, 0.0);
    vec3 l = vec3(s * sin(th), cos(th));        // round the hole: x, y, then towards it
    vec3 bh = normalize(END_HOLE_DIR);
    vec3 bx = normalize(cross(vec3(0.0, 1.0, 0.0), bh));
    vec3 by = cross(bh, bx);
    return normalize(bx * l.x + by * l.y + bh * l.z);
}

// Star dust drifting in the dark just under the surface, in layers going down.
vec3 endPortalDust(vec3 rd, vec3 worldPos, float t, int layers, float amount) {
    vec3 col = vec3(0.0);
    float down = max(abs(rd.y), 0.08);
    for (int i = 0; i < 3; i++) {
        if (i >= layers) break;
        float depth = 0.35 * pow(2.4, float(i));
        vec3 p = worldPos + rd * (depth / down);
        float sc = 2.6 / (1.0 + float(i) * 0.6);
        vec2 uv = p.xz * sc + vec2(t * 0.05, -t * 0.03) * (1.0 + float(i));
        vec2 cell = floor(uv);
        vec3 h = hash33(vec3(cell, float(i) * 17.0 + 3.0));
        vec2 f = fract(uv) - 0.5 - (h.xy - 0.5) * 0.7;
        float px = max(fwidth(uv.x), 1e-4);
        float rad = max(0.03, px * 1.1);
        float star = exp(-dot(f, f) / (rad * rad)) * sqr(0.03 / rad) * step(0.7, h.z);
        float tw = 0.55 + 0.45 * sin(t * (1.2 + 3.0 * h.z) + h.x * 31.0);
        vec3 c = mix(vec3(0.40, 1.0, 0.88), vec3(0.78, 0.48, 1.0), h.y);
        c = mix(c, vec3(1.0, 0.9, 1.0), step(0.93, h.z));
        col += c * star * tw * (1.4 / (1.0 + float(i) * 0.8)) * amount;
    }
    return col;
}

// Without a known pool: the End's heavens, infinitely far, with star dust under the surface.
vec3 endPortalSkyWindow(vec3 rd, vec3 worldPos) {
    float t = frameTimeCounter;
    return endSkyAt(endPortalSkyDir(rd), 0.0) * 0.26 + endPortalDust(rd, worldPos, t, 3, 1.0);
}

// The gas on the black hole's disc, streaming round it (two phases that take turns,
// so the inner rings can turn faster than the outer without winding up over time).
// rr: distance from the hole in its radii; ang: angle round it.
float endDiscGas(float rr, float ang, float t) {
    float w = 0.0, acc = 0.0;
    for (int k = 0; k < 2; k++) {
        float ph = fract(t / 24.0 + 0.5 * float(k));
        float wt = 1.0 - abs(2.0 * ph - 1.0);
        float a = ang - ph * 24.0 * 0.9 / pow(max(rr, 1.0), 1.5);
        vec3 p = vec3(cos(a) * 3.0, sin(a) * 3.0, rr * 1.6 + float(k) * 7.0);
        float n = vnoise3(p) * 0.55 + vnoise3(p * vec3(2.2, 2.2, 3.5) + 3.1) * 0.3 + vnoise3(p * vec3(4.5, 4.5, 9.0) + 7.7) * 0.15;
        acc += n * wt; w += wt;
    }
    return acc / max(w, 1e-3);
}

// The well under a pool: violet End mist swirling down, round and round, with star
// dust in it and a small black hole far below, glimpsed through the mist, its disc
// glowing faintly and lighting the mist a little from beneath.
// c: the pool's middle (world x, z), s: half its smaller side (blocks).
vec3 endPortalWell(vec3 rd, vec3 worldPos, vec2 c, float s) {
    float t = frameTimeCounter;
    float D = 0.75 * s + 0.5;                   // how deep the hole sits below the surface
    float down = max(abs(rd.y), 0.12);
    vec3 wp = vec3(worldPos.x - c.x, 0.0, worldPos.z - c.y);   // the surface point, from the pool's middle
    // The well leans towards you, so from wherever you stand at the pool you look
    // down its throat to the hole (straight down only from right above it).
    vec3 toMid = vec3(c.x, worldPos.y, c.y) - cameraPosition;
    vec3 v = normalize(vec3(toMid.x, -abs(toMid.y) - 0.2, toMid.z));
    vec3 ax = normalize(mix(vec3(0.0, -1.0, 0.0), v, 0.7));
    vec2 lean = ax.xz / max(-ax.y, 0.35);       // sideways shift per block of depth
    vec3 acc = vec3(0.0);
    float T = 1.0;
    // Mist, in layers going down: the funnel narrows towards the hole.
    const int K = 7;
    for (int k = 0; k < K; k++) {
        float f = (float(k) + 0.6) / float(K);
        float d = D * f;
        vec2 q = (wp.xz + rd.xz * (d / down) - lean * d) / s;
        float r = length(q);
        float th = atan(q.y, q.x);
        float lr = log(r + 0.05);
        float ps = th + 1.6 * lr - t * (0.16 + 0.22 * f) + d * 0.7;
        vec3 nc = vec3(cos(ps) * 1.9, sin(ps) * 1.9, lr * 0.9 + t * 0.10 + f * 2.3 + float(k) * 1.7);
        float n = vnoise3(nc) * 0.55 + vnoise3(nc * 2.1 + 4.3) * 0.3 + vnoise3(nc * 4.4 + 9.1) * 0.15;
        float R = mix(1.1, 0.42, f);
        float wall = smoothstep(R - 0.3, R + 0.35, r + 0.3 * (n - 0.5));
        float a = smoothstep(0.38, 0.72, n) * mix(0.45, 0.9, wall);  // the throat stays veiled, with gaps
        // Lit from below by the disc: brighter deep down and round the funnel's rim.
        float glow = (0.03 + 0.2 * f * f * exp(-max(r - R, 0.0) * 1.1) + 0.16 * f * exp(-abs(r - R) * 3.5)) * smoothstep(0.1, 0.45, r);
        vec3 mc = mix(vec3(0.10, 0.05, 0.24), vec3(0.50, 0.30, 1.0), smoothstep(0.4, 0.9, n));
        mc = mix(mc, vec3(0.85, 0.55, 1.0), smoothstep(0.72, 0.95, n) * f * 0.6);
        acc += T * mc * glow * a;
        T *= 1.0 - a;
        if (T < 0.02) return acc;
        // A little star dust caught in the top of the mist.
        if (k == 0) acc += T * endPortalDust(rd, worldPos, t, 3, 1.0);
    }
    // The bottom: the black hole, its disc and the light bent round it.
    float Rh = 0.11 * s;                        // small: glimpsed through the mist, not the centrepiece
    vec3 o = wp + vec3(-lean.x * D, D, -lean.y * D);   // surface point, from the hole
    vec3 rdd = vec3(rd.x, -abs(rd.y), rd.z);    // (seen from below, the well still goes away from you)
    float tca = -dot(o, rdd);
    float b = length(o + rdd * tca) / Rh;       // how close the line of sight passes, in hole radii
    vec3 bg = endSkyAt(endPortalSkyDir(rd), 0.0) * 0.2;
    vec3 bottom = bg;
    float tdisc = o.y / max(-rdd.y, 1e-3);
    vec3 pd = o + rdd * tdisc;
    float rr = length(pd.xz) / Rh;
    float ang = atan(pd.z, pd.x);
    float g = endDiscGas(rr, ang, t);
    float band = smoothstep(1.35, 1.9, rr) * exp(-max(rr - 1.9, 0.0) / 1.1);
    vec3 dcol = mix(vec3(0.90, 0.80, 1.0), vec3(0.62, 0.40, 1.0), smoothstep(1.9, 3.8, rr));
    dcol = mix(dcol, vec3(0.70, 0.32, 0.80), smoothstep(3.8, 6.0, rr));
    vec3 disc = dcol * band * (0.2 + 1.4 * smoothstep(0.35, 0.8, g)) * 0.25;
    // The far side of the disc, bent up round the hole into a glowing ring, and the
    // thin photon ring right at its edge.
    float halo = exp(-sqr((b - 1.6) / 0.35)) * (0.5 + 0.9 * smoothstep(0.3, 0.8, endDiscGas(1.9 + (b - 1.6), atan(o.z + rdd.z * tca, o.x + rdd.x * tca), t)));
    vec3 ring = vec3(0.85, 0.75, 1.0) * (halo * 0.15 + exp(-sqr((b - 1.06) / 0.05)) * 0.35);
    vec3 aura = vec3(0.6, 0.38, 1.0) * exp(-b / 3.0) * 0.12;
    if (b < 1.0) bottom = tdisc < tca ? disc : vec3(0.0);   // the hole, unless the disc crosses in front
    else bottom += aura + ring + disc;
    return acc + T * bottom;
}

// What you see through an End portal's surface at worldPos (rd: the view direction).
vec3 endPortalView(vec3 rd, vec3 worldPos) {
    #if END_PORTAL_LIST == 1
        vec2 c; float s;
        if (endPoolAt(worldPos, c, s)) return endPortalWell(rd, worldPos, c, s);
    #endif
    return endPortalSkyWindow(rd, worldPos);
}
#endif

#endif
