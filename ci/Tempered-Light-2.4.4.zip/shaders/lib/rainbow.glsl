/*
    Tempered Light - rainbows after rain.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_RAINBOW
#define LF_RAINBOW

// ---------------------------------------------------------------- rainbow --
vec3 bowSpectrum(float x) {   // 0 violet .. 1 red
    x = saturate(x);
    return vec3(smoothstep(0.45, 0.85, x) + 0.35 * smoothstep(0.25, 0.0, x),
                smoothstep(0.15, 0.5, x) * smoothstep(1.0, 0.65, x),
                smoothstep(0.62, 0.15, x));
}
float bowBand(float x) { return smoothstep(-0.12, 0.15, x) * smoothstep(1.12, 0.85, x); }

// A rainbow opposite the sun: the primary bow at 40.6-42.4 degrees (red outside)
// and a faint secondary at 50-54 degrees (colours reversed). It shows once the rain
// has stopped and any thunder has passed, for a while after while the ground is
// still wet, when the sun is low enough (the composite pass draws it in front of
// the clouds, only while the sun shines through on you). Never at the start of
// rain or during a storm: the ground gets wet faster than the rain value rises,
// so wetness alone would show one for the first half minute of any shower.
vec3 rainbow(vec3 rd, vec3 sunDir, vec3 sunT) {
    #if RAINBOW == 1
        float sunY = sunDir.y;
        float after = (1.0 - smoothstep(0.0, 0.1, rainStrength)) * (1.0 - smoothstep(0.15, 0.5, skyRain()))
                    * (1.0 - smoothstep(0.02, 0.2, lfThunder));
        float amount = saturate(lfWet * 1.6) * after * lfRainHere
                     * smoothstep(0.0, 0.08, sunY) * (1.0 - smoothstep(0.62, 0.72, sunY));
        if (amount <= 0.001) return vec3(0.0);
        float th = degrees(acos(clamp(dot(rd, -sunDir), -1.0, 1.0)));
        if (th < 30.0 || th > 56.0) return vec3(0.0);
        float x1 = (th - 40.4) / 2.2;
        vec3 c = bowSpectrum(x1) * bowBand(x1);
        float x2 = (53.8 - th) / 3.4;
        c += bowSpectrum(x2) * bowBand(x2) * 0.26;
        // The sky just inside the main bow is brighter than outside it.
        c += vec3(0.16) * smoothstep(30.0, 39.5, th) * (1.0 - smoothstep(39.5, 40.6, th));
        return c * amount * smoothstep(-0.02, 0.1, rd.y) * sunT * SUN_ILLUMINANCE * 0.1;
    #else
        return vec3(0.0);
    #endif
}

#endif
