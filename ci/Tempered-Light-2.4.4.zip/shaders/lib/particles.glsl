/*
    Tempered Light - particles in the air drawn by the shaders: snow driven by the
    wind in snowstorms, and ash and glowing embers drifting through the Nether.
    The view ray walks a grid of cells that moves along with the particles (so they
    drift), and each cell holds at most one particle. Each kind drifts at a steady
    speed along the wind setting's heading: the grid's offset is speed x time, so a
    speed that changed over time would make every particle race; stronger weather
    shows as more and longer particles instead.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_PARTICLES
#define LF_PARTICLES

struct AirParticles {
    float cell;      // grid cell size, blocks (a power of two)
    vec3 vel;        // how they drift, blocks per second
    float size;      // radius, blocks
    float stretch;   // streaks: length along the drift, in radii (0 = round)
    float chance;    // share of cells holding a particle
    float sway;      // how far each one wanders about, blocks
    float range;     // how far out they are drawn, blocks
    float seed;
    float twinkle;   // 1: each one glows brighter and dimmer over time (embers)
};

// x: how much of the pixel the particles cover; y: the same, weighted by each
// particle's brightness (for glowing ones).
vec2 airParticles(vec3 rd, float maxDist, AirParticles P) {
    float tEnd = min(maxDist, P.range);
    if (tEnd <= 0.4 || P.chance <= 0.0) return vec2(0.0);
    const float WRAP = 2048.0;
    float tt = frameTimeCounter;
    // Where you are in the frame the particles move with (wrapped to keep precision).
    vec3 q0 = mod(cameraPosition - P.vel * tt, WRAP);
    vec3 qc = q0 / P.cell;
    vec3 cell = floor(qc);
    vec3 stp = vec3(rd.x >= 0.0 ? 1.0 : -1.0, rd.y >= 0.0 ? 1.0 : -1.0, rd.z >= 0.0 ? 1.0 : -1.0);
    vec3 tDelta = P.cell / max(abs(rd), vec3(1e-5));
    vec3 tMax = (stp * (cell - qc) + max(stp, 0.0)) * tDelta;
    float pixAng = 2.0 / (gbufferProjection[1][1] * viewHeight);
    vec3 vd = dot(P.vel, P.vel) > 1e-6 ? normalize(P.vel) : vec3(0.0, 1.0, 0.0);
    float invS = 1.0 / (1.0 + P.stretch);
    // Streaks: measured in a space squashed along the drift, where they are round.
    vec3 rdS = rd - vd * dot(rd, vd) * (1.0 - invS);
    float rdS2 = max(dot(rdS, rdS), 1e-6);
    float A = 0.0, G = 0.0;
    for (int i = 0; i < 48; i++) {
        vec3 h = hash33(mod(cell, WRAP / P.cell) + P.seed);
        if (h.x < P.chance) {
            vec3 h2 = hash33(h * 91.7 + 3.1);
            vec3 sw = vec3(sin(tt * (0.6 + 0.6 * h2.x) + h.y * 6.283),
                           0.5 * sin(tt * (0.5 + 0.5 * h2.y) + h.z * 6.283),
                           cos(tt * (0.6 + 0.6 * h2.z) + h2.x * 6.283)) * P.sway;
            vec3 pp = (cell + 0.25 + 0.5 * h2) * P.cell + sw;
            vec3 rel = pp - q0;
            float tp = dot(rel, rd);
            if (tp > 0.3 && tp < tEnd + P.size * (1.0 + P.stretch)) {
                vec3 relS = rel - vd * dot(rel, vd) * (1.0 - invS);
                float k = dot(relS, rdS);
                float d2 = max(dot(relS, relS) - k * k / rdS2, 0.0);
                // Never smaller than about a pixel: further ones are fainter instead.
                float r = max(P.size, tp * pixAng * 0.7);
                float a = smoothstep(r * r, r * r * 0.12, d2);
                a *= min((P.size / r) * (P.size / r) * (1.0 + 0.5 * P.stretch), 1.0);
                // Fade out towards their range; hidden softly behind what is in front.
                a *= smoothstep(P.range, P.range * 0.6, tp) * smoothstep(0.3, 0.9, tp) * saturate((maxDist - tp) / 0.25);
                float b = 1.0;
                if (P.twinkle > 0.5) b = 0.15 + 1.6 * smoothstep(0.25, 0.9, vnoise(vec2(tt * (0.8 + h2.y) + h.z * 37.0, h.y * 53.0)));
                G += (1.0 - A) * a * b;
                A += (1.0 - A) * a;
            }
        }
        float tn = min(tMax.x, min(tMax.y, tMax.z));
        if (tn > tEnd || A > 0.98) break;
        if (tMax.x < tMax.y && tMax.x < tMax.z) { cell.x += stp.x; tMax.x += tDelta.x; }
        else if (tMax.y < tMax.z) { cell.y += stp.y; tMax.y += tDelta.y; }
        else { cell.z += stp.z; tMax.z += tDelta.z; }
    }
    return vec2(A, G);
}

// The wind setting's heading, without the slow wandering the plants follow.
vec2 windHeading() {
    float a = radians(float(WIND_DIRECTION));
    return vec2(cos(a), sin(a));
}

// How hard it is snowing where you are (0..about 2): light snowfall a little,
// snow in a thunderstorm (a snowstorm) fully.
float snowstormAmount() {
    return snowStormHere() * SNOWSTORMS;
}

#if !defined DIM_NETHER && !defined DIM_END
// Snow blown along by the wind, close round you, in streaks.
vec3 applyBlizzard(vec3 col, vec3 rd, float dist, vec3 skyAmb, vec3 lightE) {
    float s = snowstormAmount() * smoothstep(0.35, 0.8, eyeSkyLight()) * belowCloudDeck();
    if (s < 0.02) return col;
    vec2 w = windHeading();
    float speed = 9.0 * (0.6 + 0.4 * WIND_STRENGTH);
    AirParticles P;
    P.cell = 1.0; P.vel = vec3(w.x * speed, -2.5, w.y * speed); P.size = 0.02; P.stretch = 2.0 + 3.0 * saturate(s);
    P.chance = min(0.10 + 0.30 * s, 0.9); P.sway = 0.08; P.range = 18.0; P.seed = 11.0; P.twinkle = 0.0;
    vec2 c = airParticles(rd, dist, P);
    vec3 snowLit = skyAmb * 1.8 + lightE * 0.05;
    return mix(col, snowLit, c.x * 0.85);
}
#endif

#ifdef DIM_NETHER
// Ash drifting down and embers rising through the Nether air.
vec3 applyNetherParticles(vec3 col, vec3 rd, float dist) {
    vec2 w = windHeading() * WIND_STRENGTH;
    vec3 amb = srgbToLinear(fogColor) * 0.35 + netherGlow(cameraPosition.y) * 3.0;
    if (NETHER_ASH > 0.0) {
        AirParticles P;
        P.cell = 2.0; P.vel = vec3(w.x * 0.5, -0.35, w.y * 0.5); P.size = 0.026; P.stretch = 0.0;
        P.chance = min(0.22 * NETHER_ASH, 0.9); P.sway = 0.35; P.range = 28.0; P.seed = 23.0; P.twinkle = 0.0;
        vec2 c = airParticles(rd, dist, P);
        col = mix(col, amb * 0.9 + vec3(0.06, 0.055, 0.05), c.x * 0.9);   // pale grey flakes
    }
    if (NETHER_EMBERS > 0.0) {
        // More of them lower down, nearer the lava sea.
        float low = mix(0.35, 1.0, smoothstep(120.0, 45.0, cameraPosition.y));
        AirParticles P;
        P.cell = 4.0; P.vel = vec3(w.x * 0.3, 1.1, w.y * 0.3); P.size = 0.03; P.stretch = 1.5;
        P.chance = min(0.16 * NETHER_EMBERS * low, 0.9); P.sway = 0.6; P.range = 40.0; P.seed = 57.0; P.twinkle = 1.0;
        vec2 c = airParticles(rd, dist, P);
        col = col * (1.0 - c.x * 0.6) + vec3(2.6, 0.8, 0.18) * c.y * 2.5;
    }
    return col;
}
#endif

#endif
