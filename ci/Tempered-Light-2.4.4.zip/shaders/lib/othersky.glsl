/*
    Tempered Light - skies of the End and the Nether roof.

    End: a small black hole, about the size of the sun, swallowing a star. A thin,
    blinding disc rings it, light from behind it is bent into a ring, a star at the
    disc's edge is being pulled into it, and clouds of dust around it glow with its
    light. Around the horizon, pink and violet light pillars rise from the void.

    Nether roof: a burnt orange sky under rolling red cloud with a black sun.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_OTHERSKY
#define LF_OTHERSKY

// ------------------------------------------------------------------- End ---
#define END_HOLE_R (0.016 * END_HOLE_SIZE)     // event horizon, angular radius (the sun is 0.02)

// Coordinates round the hole in units of its radius; c = cos(angle from it).
vec2 endHoleCoords(vec3 rd, out float c) {
    vec3 bh = normalize(END_HOLE_DIR);
    vec3 bx = normalize(cross(vec3(0.0, 1.0, 0.0), bh));
    vec3 by = cross(bh, bx);
    c = dot(rd, bh);
    return vec2(dot(rd, bx), dot(rd, by)) / (END_HOLE_R * max(c, 0.05));
}

// Noise round the horizon that joins up all the way round (no seam behind you):
// freq is roughly features per radian, y runs along the second axis.
float ringNoise(float az, float freq, float y) {
    return vnoise3(vec3(cos(az) * freq, sin(az) * freq, y));
}

// Light pillars rising from the void round the horizon, and the glow under them.
// They are never still: the whole ring slowly drifts round, each pillar wavers like a
// flame (more towards its top), brightens and fades on its own slow beat and rises
// and sinks, and faint bands of light climb up through them.
vec3 endPillars(vec3 rd, float t) {
    float az = atan(rd.z, rd.x);
    float h = rd.y;
    float sway = sin(h * 7.0 - t * 0.55 + az * 4.0) * 0.012 + sin(h * 13.0 - t * 0.9 + az * 9.0) * 0.005;
    float azw = az + t * 0.0035 + sway * smoothstep(-0.05, 0.45, h);
    float b1 = pow(ringNoise(azw, 9.0, t * 0.03), 2.5);
    float b2 = pow(ringNoise(azw - t * 0.002, 26.0, 3.0 + t * 0.05), 4.0);
    float b3 = pow(ringNoise(azw + t * 0.003, 70.0, 7.0 + t * 0.07), 6.0);
    float pulse = 0.5 + 0.8 * smoothstep(0.2, 0.8, ringNoise(azw, 9.0, 11.0 + t * 0.1));
    float beams = (b1 * 0.7 + b2 * 0.6 + b3 * 0.45) * pulse;
    beams *= 0.85 + 0.3 * smoothstep(0.3, 1.0, 0.5 + 0.5 * sin(h * 26.0 - t * 1.1 + azw * 13.0));
    // Each pillar reaches its own height, slowly rising and sinking.
    float top = 0.25 + 0.55 * ringNoise(azw, 5.0, 1.3 + t * 0.04);
    float prof = smoothstep(-0.25, 0.02, h) * (1.0 - smoothstep(-0.05, top, h));
    // Pink at the foot, rising into violet; a few pillars rise into the brand blue
    // or mint green instead.
    float sel = ringNoise(azw, 6.0, 2.7);
    vec3 topCol = vec3(0.60, 0.30, 1.0);
    topCol = mix(topCol, vec3(0.28, 0.60, 1.0), smoothstep(0.64, 0.72, sel));
    topCol = mix(topCol, vec3(0.28, 1.0, 0.70), smoothstep(0.32, 0.24, sel));
    vec3 col = mix(vec3(1.0, 0.36, 0.80), topCol, smoothstep(0.0, 0.4, h));
    // A broad glow round the horizon, brightest beneath the black hole, gently breathing.
    vec3 bh = normalize(END_HOLE_DIR);
    float towards = saturate(dot(normalize(rd.xz + 1e-5), normalize(bh.xz)));
    float glow = exp(-abs(h + 0.04) * 4.5) * (0.35 + 0.65 * towards * towards) * (0.9 + 0.1 * sin(t * 0.3));
    return (col * beams * prof * 0.26 * END_PILLARS + vec3(0.95, 0.45, 0.95) * glow * 0.07) * END_GLOW;
}

vec3 endGas(vec3 d, float t) {
    vec3 p = d * 2.2 + vec3(0.0, 0.0, t * 0.002);
    float n1 = fbm3(p);
    float n2 = fbm3(p * 2.3 + 7.1);
    float gas = smoothstep(0.42, 0.85, n1);
    vec3 gc = mix(vec3(0.42, 0.20, 0.85), vec3(0.16, 0.38, 0.95), smoothstep(0.3, 0.7, n2));
    gc = mix(gc, vec3(0.95, 0.32, 0.70), smoothstep(0.62, 0.9, n2) * 0.7);
    float dust = smoothstep(0.55, 0.8, fbm3(p * 3.7 + 2.0));
    return gc * gas * (0.5 + 0.9 * n2) * (1.0 - 0.6 * dust) * 0.035;
}

// storm: how much the End Storm veils the sky (END_STORM; 0 for the clear sky).
vec3 endSkyAt(vec3 rd, float storm) {
    float t = frameTimeCounter;
    float c;
    vec2 q = endHoleCoords(rd, c);
    float r = length(q);
    float front = smoothstep(0.0, 0.2, c);

    // The hole bends the light passing close to it: the stars and gas behind are pushed outwards.
    vec3 rdl = rd;
    if (END_SKY == 1 && front > 0.0) {
        vec3 bh = normalize(END_HOLE_DIR);
        vec3 away = normalize(rd - bh * c + 1e-5);
        rdl = normalize(rd + away * END_HOLE_R * 2.0 / max(r, 1.0) * front);
    }

    // Deep violet space, darker towards the void below.
    vec3 col = mix(vec3(0.016, 0.009, 0.032), vec3(0.005, 0.002, 0.010), smoothstep(0.1, -0.7, rd.y));
    col += endGas(rdl, t);
    vec3 cs = toCelestial(rdl, normalize(vec3(0.3, -1.0, 0.2)));
    col += starField(cs, 1.4) * 0.07 * vec3(0.9, 0.85, 1.1);
    col += endPillars(rd, t);
    // Under the End Storm, what shows of the sky between the clouds is dimmed (not
    // round the black hole, whose light still breaks through).
    col *= 1.0 - 0.65 * saturate(storm) * smoothstep(0.985, 0.90, c);

    #if END_SKY == 1
        if (front > 0.0) {
            float ang = atan(q.y, q.x);
            // Its glow lights the sky a long way round it.
            vec3 aura = vec3(0.85, 0.55, 1.0) * (exp(-r / 60.0) * 0.03 + exp(-r / 14.0) * 0.07 + exp(-r / 4.0) * 0.2);

            // Clouds of dust round it, lit from the hole: bright violet and pink near it,
            // dark against the glow further out. They slowly swirl inwards.
            float lr = log(max(r, 1.0));
            float tw = ang + lr * 1.2 - t * 0.09;
            vec3 dp = vec3(cos(tw) * 1.6, sin(tw) * 1.6, lr * 1.8 - t * 0.03);
            float dust = smoothstep(0.38, 0.78, fbm3(dp * 1.3)) * smoothstep(3.0, 9.0, r) * exp(-r / 45.0);
            float lit = exp(-r / 16.0);
            vec3 dustCol = mix(vec3(0.95, 0.35, 0.70), vec3(0.55, 0.40, 1.0), smoothstep(0.4, 0.8, fbm3(dp * 2.7 + 4.0)));
            col = mix(col + aura * front, dustCol * (lit * 0.55 + 0.02), dust * 0.85 * front);

            #if END_VORTEX == 1
                // A great whirlpool of gas round the hole, its arms winding in from across
                // the sky towards it, turning slowly, as if the sky is being drawn in.
                float th = acos(clamp(c, -1.0, 1.0));             // angle from the hole
                float lrv = log(max(th / END_HOLE_R, 1.0));
                float sw = ang + lrv * 1.25 - t * 0.04;
                float vArms = pow(0.5 + 0.5 * cos(2.0 * sw), 2.4);
                float gasN = fbm3(vec3(cos(sw) * 1.4 + lrv * 0.35, sin(sw) * 1.4, lrv * 0.9 - t * 0.015));
                float vort = vArms * smoothstep(0.32, 0.72, gasN) * smoothstep(1.7, 0.25, th) * smoothstep(1.0, 3.0, lrv);
                vec3 vCol = mix(vec3(0.55, 0.30, 1.0), vec3(0.32, 0.45, 1.0), smoothstep(2.0, 4.5, lrv));
                vCol = mix(vCol, vec3(1.0, 0.45, 0.85), smoothstep(0.6, 0.85, gasN) * 0.6);
                col += vCol * vort * (0.08 + 0.42 * exp(-th / 0.45)) * END_GLOW;
                // Dark lanes between the arms.
                col *= 1.0 - 0.35 * (1.0 - vArms) * smoothstep(1.4, 0.3, th) * smoothstep(1.0, 3.0, lrv);
            #endif

            // The star: at the disc's outer edge, clipping it, blinding.
            vec2 star = vec2(7.2, 0.9);
            float ds = length(q - star);
            vec2 dsv = q - star;
            // Blinding, with a wide glow and a faint four-pointed starburst.
            float spikes = exp(-abs(dsv.y) * 7.0) * exp(-abs(dsv.x) * 0.6) + exp(-abs(dsv.x) * 7.0) * exp(-abs(dsv.y) * 0.6);
            vec3 starL = vec3(1.0, 0.95, 1.0) * (exp(-ds * 2.2) * 17.0 + exp(-ds * 0.4) * 0.7 + spikes * 1.0);
            // Its gas pulled off in a curving stream that joins the disc.
            float dmin = 1e3, sAt = 0.0;
            for (int i = 0; i <= 24; i++) {
                float s = float(i) / 24.0;
                float a0 = -s * 2.2;
                vec2 pnt = vec2(cos(a0) * mix(7.0, 3.0, s), sin(a0) * mix(7.0, 3.0, s) * 0.24) + vec2(0.0, 0.9 * (1.0 - s));
                float dd = length(q - pnt);
                if (dd < dmin) { dmin = dd; sAt = s; }
            }
            vec3 stream = mix(vec3(1.0, 0.9, 1.0), vec3(1.0, 0.55, 0.85), sAt) * exp(-dmin * dmin / sqr(0.18 + 0.2 * sAt)) * (2.5 - 1.5 * sAt);

            // The disc, nearly edge-on: thin, white-hot inside, violet and pink further out,
            // streaked as it turns, brighter on the side coming towards us.
            vec2 dq = vec2(q.x, q.y / 0.08);
            float dr = length(dq);
            float da = atan(dq.y, dq.x);
            // It turns: inner rings faster than outer ones (like orbits), with spiral arms
            // of brighter gas winding in, so the whole disc visibly swirls.
            float spin = t * 1.1 / pow(max(dr, 1.0), 1.5);
            float wa = da - spin;
            float clump = vnoise3(vec3(cos(wa) * 2.4, sin(wa) * 2.4, dr * 2.2));
            // Thin streams of gas along the orbits, like fine rings.
            float streaks = vnoise3(vec3(cos(wa) * 1.3, sin(wa) * 1.3, dr * 9.0)) * 0.6 + vnoise3(vec3(cos(wa) * 2.6, sin(wa) * 2.6, dr * 23.0)) * 0.4;
            float arms = 0.5 + 0.5 * sin(2.0 * wa + log(max(dr, 1.0)) * 5.5);
            float swirl = (0.4 + 0.75 * smoothstep(0.25, 0.85, clump)) * (0.65 + 0.5 * arms) * (0.55 + 0.9 * smoothstep(0.3, 0.8, streaks));
            float band = smoothstep(1.35, 1.7, dr) * exp(-max(dr - 1.7, 0.0) / 2.2);
            float beam = 1.0 + 0.8 * cos(da - 3.1416);
            vec3 dcol = mix(vec3(1.0, 0.95, 0.88), vec3(0.80, 0.50, 1.0), smoothstep(1.8, 4.5, dr));
            dcol = mix(dcol, vec3(1.0, 0.45, 0.80), smoothstep(4.5, 8.5, dr));
            vec3 disc = dcol * band * swirl * beam * 6.0;

            // The far side of the disc, bent over and under the hole into a ring,
            // and the thin bright photon ring at its edge.
            // Like Interstellar's: the disc's top face is bent up and over the hole into a
            // broad glowing arch, its underside into a thinner one beneath, both carrying
            // the disc's own streams of gas and joining it at the sides.
            float sa = q.y / max(r, 1e-3);
            float topA = smoothstep(1.2, 1.38, r) * exp(-max(r - 1.38, 0.0) / 0.6) * smoothstep(-0.05, 0.45, sa);
            float botA = smoothstep(1.06, 1.16, r) * exp(-max(r - 1.16, 0.0) / 0.16) * smoothstep(0.05, 0.5, -sa);
            float ha = ang - t * 0.35;
            float hg = vnoise3(vec3(cos(ha) * 1.4, sin(ha) * 1.4, r * 9.0)) * 0.6 + vnoise3(vec3(cos(ha) * 3.0, sin(ha) * 3.0, r * 22.0)) * 0.4;
            vec3 hcol = mix(vec3(1.0, 0.95, 0.90), vec3(0.85, 0.60, 1.0), smoothstep(1.3, 2.2, r));
            float ringN = 0.6 + 0.6 * vnoise(vec2((ang + t * 0.6) * 5.0, 1.7));
            vec3 ring = hcol * (topA * 4.0 + botA * 2.0) * (0.45 + 0.9 * smoothstep(0.3, 0.8, hg))
                      + vec3(1.0, 0.92, 1.0) * exp(-sqr((r - 1.04) / 0.035)) * 8.0 * ringN;

            bool nearSide = q.y < 0.0 && dr < 9.0;
            if (r < 1.0) col = vec3(0.0);
            else col += (ring + (nearSide ? vec3(0.0) : disc)) * front;
            if (nearSide) col += disc * front;           // the near half crosses in front of the hole
            col += (starL + stream) * front * (r < 1.0 ? 0.0 : 1.0);
        }
    #endif
    return col;
}

vec3 endSky(vec3 rd) { return endSkyAt(rd, END_STORM); }

// The colour distance fades to in the End.
vec3 endHaze() { return vec3(0.032, 0.016, 0.055); }
// Light the black hole and its disc cast on the End's islands.
vec3 endHoleLight() { return vec3(0.80, 0.55, 1.0) * 0.55 * END_GLOW; }

// ------------------------------------------------------------ Nether roof ---
// Black sun: a dark disc ringed by a white-hot corona that bleeds into red.
// R is its angular radius; the corona slowly boils, with no rays or spikes.
vec3 blackSunAt(vec3 rd, vec3 sd, float R, float seed, out float disc) {
    float a = acos(clamp(dot(rd, sd), -1.0, 1.0));
    disc = 1.0 - smoothstep(R * 0.97, R * 1.03, a);
    float x = max(a - R, 0.0) / R;
    vec3 corona = vec3(1.0, 0.95, 0.9) * exp(-x * 5.0) * 6.0 + vec3(1.0, 0.25, 0.08) * exp(-x * 1.2) * 0.9 + vec3(0.9, 0.18, 0.05) * exp(-x * 0.2) * 0.06;
    // A slow, soft swell and ebb round the rim (broad patches, never streaks).
    vec3 bx = normalize(cross(vec3(0.0, 1.0, 0.0), sd)), by = cross(sd, bx);
    vec2 rim = vec2(dot(rd, bx), dot(rd, by)) / (R * 2.5);
    float boil = vnoise3(vec3(rim * 1.6, frameTimeCounter * 0.05 + seed));
    corona *= 1.0 + 0.25 * (boil - 0.5) * exp(-x * 1.5);
    return corona;
}

// The black sun and its small companion, a little above it and to the left, like a
// binary star: the same dark disc and burning corona, about half the size.
vec3 netherBlackSun(vec3 rd, out float disc) {
    vec3 sd = normalize(NETHER_SUN_DIR);
    float R = 0.035 * NETHER_SUN_SIZE;
    vec3 left = normalize(cross(vec3(0.0, 1.0, 0.0), sd));   // to the left, seen from below
    vec3 up = cross(sd, left);
    vec3 sd2 = normalize(sd + (left * 3.0 + up * 2.6) * R);
    float R2 = R * 0.46;
    float d1, d2;
    vec3 c1 = blackSunAt(rd, sd, R, 0.0, d1);
    vec3 c2 = blackSunAt(rd, sd2, R2, 17.0, d2) * 0.8;
    disc = max(d1, d2);
    // The companion passes in front of the big sun's glow.
    return c1 * (1.0 - d1) * (1.0 - d2) + c2 * (1.0 - d2) * (1.0 - d1);
}

vec3 netherRoofSky(vec3 rd, float dither) {
    float t = frameTimeCounter;
    float h = rd.y;
    // Smoky orange haze thick at the horizon, deep red-brown overhead.
    vec3 hor = vec3(1.0, 0.34, 0.06) * 0.16;
    vec3 zen = vec3(0.10, 0.02, 0.01) * 0.12;
    vec3 col = mix(hor, zen, smoothstep(-0.02, 0.55, h));
    if (h < 0.0) return mix(hor, vec3(0.06, 0.016, 0.008) * 0.2, smoothstep(0.0, -0.25, h));
    float disc;
    vec3 corona = netherBlackSun(rd, disc);
    col = col * (1.0 - disc) + corona;

    // Red lightning now and then, flaring inside the clouds.
    float cell = floor(t * 0.6);
    float flash = step(0.72, hash12(vec2(cell, 3.1))) * pow(1.0 - fract(t * 0.6), 4.0) * (0.6 + 0.4 * sin(t * 47.0)) * float(NETHER_LIGHTNING);
    #if NETHER_ROOF_SKY == 1
        // The same volumetric clouds as the overworld, lit by the black sun's corona
        // from above and by the fires below.
        vec3 sd = normalize(NETHER_SUN_DIR);
        // Brooding, nearly black clouds with burning edges where the light gets through.
        vec3 lightE = vec3(1.0, 0.28, 0.08) * 0.13;
        // The lightning lights the clouds round where it strikes, not the whole sky
        // (a little of it reaches everywhere).
        vec3 ambTop = vec3(0.10, 0.025, 0.012) + vec3(1.0, 0.22, 0.1) * flash * 0.06;
        vec3 ambBottom = vec3(0.30, 0.07, 0.02) * 0.35 + vec3(1.0, 0.18, 0.08) * flash * 0.1;
        vec2 fo = (hash22(vec2(cell, 6.7)) - 0.5) * 900.0;
        gCloudFlash = vec4(cameraPosition.x + fo.x, REAL_Y0 + 60.0, cameraPosition.z + fo.y, flash * 1.6);
        gCloudFlashCol = vec3(1.0, 0.25, 0.10);
        // The same cloud style as the Overworld (Realistic decks and their layers,
        // Volumetric or Blocky); with Vanilla clouds (none up here) the volumetric ones.
        #if CLOUD_MODE == 1 || CLOUD_MODE == 2 || CLOUD_MODE == 5
            vec4 cl = renderClouds(cameraPosition, rd, 1e6, sd, lightE, ambTop, ambBottom, CLOUD_QUALITY, dither);
        #else
            vec4 cl = realisticClouds(cameraPosition, rd, 1e6, sd, lightE, ambTop, ambBottom, 20, dither);
        #endif
        gCloudFlash = vec4(0.0);
        col = col * cl.a + cl.rgb;
        // Haze in front of the distant clouds near the horizon.
        col = mix(col, hor * 1.1, exp(-max(h, 0.0) * 7.0) * 0.7);
    #endif
    return col;
}
vec3 netherRoofHaze() { return vec3(0.18, 0.06, 0.015); }

#endif
