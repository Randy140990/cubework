/*
    Tempered Light - screen-space reflections (view space ray march).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_SSR
#define LF_SSR

float viewZFromDepth(float depth) {
    float z = depth * 2.0 - 1.0;
    return (gbufferProjectionInverse[2][2] * z + gbufferProjectionInverse[3][2]) /
           (gbufferProjectionInverse[2][3] * z + gbufferProjectionInverse[3][3]);
}

// rgb = reflected colour, a = confidence (0 = fall back to the sky).
// matTex is the G-buffer material target: hits on the first-person hand are rejected.
vec4 traceSSR(vec3 viewPos, vec3 dir, sampler2D depthTex, sampler2D colorTex, sampler2D matTex, int steps, float dither) {
    if (dir.z > 0.0 && -viewPos.z < 1.0) return vec4(0.0);
    float stepLen = 0.35 + 0.03 * length(viewPos);
    vec3 p = viewPos + dir * stepLen * (0.2 + dither);
    vec3 prev = viewPos;
    for (int i = 0; i < 48; i++) {
        if (i >= steps) break;
        vec3 sp = viewToScreen(p, gbufferProjection);
        if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z > 1.0) break;
        float d = texture(depthTex, sp.xy).r;
        float sceneZ = viewZFromDepth(d);
        float diff = sceneZ - p.z; // >0: ray is behind the surface
        if (d < 1.0 && diff > 0.0 && diff < stepLen * 2.2 + 0.3) {
            vec3 a = prev, b = p;
            for (int k = 0; k < 5; k++) {
                vec3 m = (a + b) * 0.5;
                vec3 ms = viewToScreen(m, gbufferProjection);
                float md = viewZFromDepth(texture(depthTex, ms.xy).r);
                if (md - m.z > 0.0) b = m; else a = m;
            }
            vec3 hs = viewToScreen(b, gbufferProjection);
            if (int(texelFetch(matTex, ivec2(hs.xy * vec2(viewWidth, viewHeight)), 0).r * 255.0 + 0.5) == CAT_HAND) return vec4(0.0);
            vec2 e = min(hs.xy, 1.0 - hs.xy);
            float fade = saturate(min(e.x, e.y) * 9.0) * saturate(float(steps - i) / 4.0);
            return vec4(texture(colorTex, hs.xy).rgb, fade);
        }
        prev = p;
        p += dir * stepLen;
        stepLen *= 1.22;
    }
    return vec4(0.0);
}

#endif
