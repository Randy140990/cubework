/*
    Tempered Light - lightning bolts. Minecraft's bolt is a stack of blocky boxes;
    here it is drawn instead as a thin, jagged channel of light from the cloud base to
    where it strikes, forking into a few dimmer branches, with a glow round it. Every
    bolt has its own shape, flickers as it strikes, and hides behind anything in front.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_LIGHTNING
#define LF_LIGHTNING

// Closest distance between the view ray (from the eye along rd) and the segment a-b
// (player space); tRay is how far along the ray that is.
float raySegmentDistance(vec3 rd, vec3 a, vec3 b, out float tRay) {
    vec3 ab = b - a;
    float bb = max(dot(ab, ab), 1e-6);
    float abrd = dot(ab, rd);
    float denom = bb - abrd * abrd;
    float s = denom > 1e-6 ? clamp((abrd * dot(rd, a) - dot(ab, a)) / denom, 0.0, 1.0) : 0.0;
    float t = max(dot(rd, a + ab * s), 0.0);
    s = clamp(dot(rd * t - a, ab) / bb, 0.0, 1.0);
    tRay = t;
    return length(rd * t - (a + ab * s));
}

#if LIGHTNING_REAL == 1 && !defined DIM_NETHER && !defined DIM_END
#define HAS_REAL_LIGHTNING
// Light from a bolt striking now, added to the picture. sceneDist: how far away what
// this pixel shows is (the bolt hides behind it).
vec3 lightningBolt(vec3 rd, float sceneDist) {
    if (lightningBoltPosition.w < 0.5) return vec3(0.0);
    vec3 base = lightningBoltPosition.xyz;                 // where it strikes (player space)
    vec3 baseW = base + cameraPosition;
    #if CLOUD_MODE == 1
        float topY = float(BLOCKY_CLOUD_ALTITUDE);
    #else
        float topY = float(REALISTIC_CLOUD_ALTITUDE) - 20.0;
    #endif
    topY = max(topY, baseW.y + 50.0);
    float H = topY - baseW.y;
    float seed = hash12(floor(baseW.xz) + 0.5) * 97.0;
    // Flickers as it strikes, like the real thing.
    float fl = 0.45 + 0.55 * step(0.3, hash12(vec2(floor(frameTimeCounter * 20.0), seed)));
    const int N = 28;
    float stepY = H / float(N);
    float lat = stepY * 0.9;
    // The main channel: a random walk down from the cloud, pulled in to end where it strikes.
    vec2 walk[N + 1];
    walk[0] = vec2(0.0);
    for (int i = 1; i <= N; i++) walk[i] = walk[i - 1] + (hash22(vec2(seed, float(i))) - 0.5) * 2.0 * lat;
    vec2 start = (hash22(vec2(seed, 91.0)) - 0.5) * H * 0.25;
    float best = 1e9, bestT = 0.0, bestW = 1.0;
    vec3 prev = vec3(0.0);
    for (int i = 0; i <= N; i++) {
        float f = float(i) / float(N);
        vec2 o = walk[i] - walk[N] * f + start * (1.0 - f);
        vec3 p = base + vec3(o.x, H * (1.0 - f), o.y);
        if (i > 0) {
            float tr;
            float dd = raySegmentDistance(rd, prev, p, tr);
            if (dd < best) { best = dd; bestT = tr; bestW = 1.0; }
        }
        prev = p;
    }
    // A few forks off the main channel, thinner and dimmer, dying out as they go.
    for (int k = 0; k < 4; k++) {
        vec3 h = hash33(vec3(seed, float(k), 5.3));
        int i0 = 3 + int(h.x * 15.0);
        float f0 = float(i0) / float(N);
        vec2 o0 = walk[i0] - walk[N] * f0 + start * (1.0 - f0);
        vec3 q = base + vec3(o0.x, H * (1.0 - f0), o0.y);
        vec2 dir = normalize(h.yz - 0.5 + 1e-3);
        int len = 5 + int(h.z * 6.0);
        for (int j = 0; j < 11; j++) {
            if (j >= len) break;
            vec2 jit = (hash22(vec2(seed + float(k) * 13.0, float(j))) - 0.5) * 1.6 * lat;
            vec3 qn = q + vec3(dir.x * lat * 0.9 + jit.x, -stepY * 0.85, dir.y * lat * 0.9 + jit.y);
            float tr;
            float dd = raySegmentDistance(rd, q, qn, tr);
            float wgt = 0.35 * (1.0 - float(j) / float(len));
            // Compare as if the fork were as bright as the channel: keep the brightest look.
            if (dd / max(wgt, 0.05) < best / max(bestW, 0.05)) { best = dd; bestT = tr; bestW = wgt; }
            q = qn;
        }
    }
    if (bestT <= 0.0 || bestT > sceneDist + 0.5) return vec3(0.0);
    // A thin white-hot core (never thinner than about a pixel: further away it is
    // fainter instead) inside a soft blue glow.
    float pixAng = 2.0 / (gbufferProjection[1][1] * viewHeight);
    float w = max(0.10, bestT * pixAng * 0.75);
    float core = exp(-(best * best) / (w * w)) * min(0.10 / w, 1.0);
    float glow = exp(-best / (2.0 + bestT * 0.015));
    float through = exp(-bestT * (0.002 + 0.004 * skyRain()));   // rain and haze in between
    return vec3(0.78, 0.84, 1.0) * (core * 40.0 + glow * 0.6) * bestW * fl * through * LIGHTNING_FLASH_VIS;
}
#endif

#endif
