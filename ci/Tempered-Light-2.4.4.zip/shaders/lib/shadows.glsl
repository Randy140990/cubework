/*
    Tempered Light - sun/moon shadow map: distortion, soft filtering,
    coloured glass shadows and light passing through water.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_SHADOWS
#define LF_SHADOWS

#define SHADOW_DISTORT 0.86

// In the End the shadow map is drawn from the black hole, so its light casts shadows
// (the pillars, the dragon, you). Minecraft's own shadow camera there looks straight
// down from a fixed noon sun, so the shaders build their own, turned to face the hole.
#if defined DIM_END && END_SHADOWS == 1 && END_SKY == 1
    #define END_HOLE_SHADOWS
#endif
mat4 lfShadowModelView() {
    #ifdef END_HOLE_SHADOWS
        vec3 L = normalize(END_HOLE_DIR);                         // towards the light
        vec3 s = normalize(cross(vec3(0.0, 1.0, 0.0), L));
        vec3 u = cross(L, s);
        // Rows s, u, L: the map looks along -L, from the hole.
        mat3 R = mat3(vec3(s.x, u.x, L.x), vec3(s.y, u.y, L.y), vec3(s.z, u.z, L.z));
        // Keep the map's texels fixed in the world as you move (no crawling edges):
        // the camera's position across the map is snapped to a 2-block grid.
        vec3 cam = R * cameraPosition;
        vec3 off = cam - floor(cam / 2.0) * 2.0;
        // Centre the map's depth range on you, read from the projection Iris actually
        // uses (its near/far planes differ between versions and are set to +-256 in the
        // End): the black hole sits low, so shadows run a long way across the island on
        // the side away from it as well as towards it. (A fixed 100-block shift here
        // left only ~45 blocks of ground on the far side, so a pillar's shadow vanished
        // once you stood between it and the hole.)
        float zMid = -shadowProjection[3][2] / shadowProjection[2][2];
        return mat4(vec4(R[0], 0.0), vec4(R[1], 0.0), vec4(R[2], 0.0), vec4(off.xy, off.z + zMid, 1.0));
    #else
        return shadowModelView;
    #endif
}

vec2 distortShadowXY(vec2 p) {
    return p / (length(p) * SHADOW_DISTORT + (1.0 - SHADOW_DISTORT));
}
float shadowDistortFactor(vec2 p) {
    return length(p) * SHADOW_DISTORT + (1.0 - SHADOW_DISTORT);
}

#ifndef SHADOW_PASS
#if USE_SHADOWS == 1
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
#endif

struct ShadowSample {
    vec3 light;        // 0..1 per channel
    float waterDepth;  // blocks of water between the surface and the light
    float waterFrac;   // share of taps that saw water
};

// Fallback when outside the shadow map: open sky = probably sunlit.
float skyLightShadow(float skyLight) {
    return smoothstep(0.82, 0.97, skyLight);
}

ShadowSample sampleShadow(vec3 playerPos, vec3 normal, float NdotL, float skyLight, float dither) {
    ShadowSample r;
    r.light = vec3(skyLightShadow(skyLight));
    r.waterDepth = 0.0;
    r.waterFrac = 0.0;
    #if USE_SHADOWS == 1
        float dist = length(playerPos);
        float fadeOut = smoothstep(shadowDistance * 0.82, shadowDistance * 0.98, max(length(playerPos.xz), abs(playerPos.y) * 1.5));
        if (fadeOut >= 1.0) return r;

        vec3 sv = (lfShadowModelView() * vec4(playerPos, 1.0)).xyz;
        vec3 sc = (shadowProjection * vec4(sv, 1.0)).xyz;
        float df = shadowDistortFactor(sc.xy);
        float texelWorld = 2.0 * shadowDistance / float(shadowMapResolution) * df;
        // Normal offset grows with the texel size and grazing light.
        vec3 offsetPos = playerPos + normal * texelWorld * (1.2 + 1.5 * (1.0 - saturate(NdotL)));
        sc = (shadowProjection * vec4((lfShadowModelView() * vec4(offsetPos, 1.0)).xyz, 1.0)).xyz;
        // Outside the shadow map's box (seen from high up, the ground can sit below its
        // far plane): no shadow data there, so use the sky-light guess instead of
        // reading it as "blocked", which drew dark bands with straight edges.
        if (abs(sc.x) >= 1.0 || abs(sc.y) >= 1.0 || abs(sc.z) >= 0.995) return r;
        fadeOut = max(fadeOut, smoothstep(0.9, 0.995, abs(sc.z)));
        df = shadowDistortFactor(sc.xy);
        sc.xy = distortShadowXY(sc.xy);
        sc = sc * 0.5 + 0.5;
        // About a hundredth of a block, whatever depth range the map covers.
        float bias = 0.0102 * df * abs(shadowProjection[2][2]) * 0.5;
        float zRef = sc.z - bias;
        float texel = 1.0 / float(shadowMapResolution);
        float depthScale = abs(2.0 / shadowProjection[2][2]);

        #if SHADOW_SOFTNESS == 0
            const int taps = 4;
            float radius = 0.75 * texel;
        #elif SHADOW_SOFTNESS == 1
            const int taps = 10;
            float radius = 1.6 * texel;
        #else
            const int taps = 14;
            // Blocker search widens the penumbra the further the caster is.
            float blocker = 0.0, nb = 0.0;
            for (int i = 0; i < 6; i++) {
                vec2 o = vogel(i, 6, dither * TAU) * 7.0 * texel;
                float d = texture(shadowtex1, sc.xy + o).r;
                if (d < zRef) { blocker += d; nb += 1.0; }
            }
            float radius = 1.2 * texel;
            if (nb > 0.0) {
                float gap = (zRef - blocker / nb) * depthScale;
                radius = clamp(gap * 0.06 / (df * 2.0 * shadowDistance) * float(shadowMapResolution), 1.0, 9.0) * texel;
            }
        #endif

        // Is there water between this point and the light? Probe a little way around, so
        // points in the shadow of something above the water still know they are under it.
        float wProbe = 0.0;
        for (int i = 0; i < 4; i++) {
            vec2 uv = sc.xy + vec2(i == 0 ? 1.0 : i == 1 ? -1.0 : 0.0, i == 2 ? 1.0 : i == 3 ? -1.0 : 0.0) * 10.0 * texel;
            float d0 = texture(shadowtex0, uv).r, d1 = texture(shadowtex1, uv).r;
            if (d0 < zRef && d1 > d0 + 1e-5 && texture(shadowcolor0, uv).a < 0.05) wProbe = max(wProbe, (min(zRef, d1) - d0) * depthScale);
        }
        // Light scattered in deep water softens shadows: widen the penumbra with depth.
        radius *= 1.0 + min(wProbe * 0.35, 6.0);
        // Far away (seen from high up) one pixel covers more ground than a shadow texel:
        // soften shadows over at least that much, so detail finer than a pixel (the step
        // of a sand layer, a fence) doesn't flicker on and off as the view moves.
        float pixWorld = dist * 2.0 / (gbufferProjection[1][1] * viewHeight) / max(abs(dot(normal, normalize(-playerPos))), 0.35);
        radius = max(radius, 0.6 * pixWorld / max(texelWorld, 1e-4) * texel);

        vec3 acc = vec3(0.0);
        float waterAcc = 0.0, waterDepthAcc = 0.0, openAcc = 0.0;
        for (int i = 0; i < taps; i++) {
            vec2 uv = sc.xy + vogel(i, taps, dither * TAU) * radius;
            float d1 = texture(shadowtex1, uv).r;
            if (d1 < zRef) continue;              // solid blocker
            openAcc += 1.0;
            float d0 = texture(shadowtex0, uv).r;
            if (d0 >= zRef) { acc += 1.0; continue; } // nothing at all
            vec4 sc0 = texture(shadowcolor0, uv);
            if (sc0.a < 0.05) {
                // Water between the surface and the light.
                waterAcc += 1.0;
                waterDepthAcc += (zRef - d0) * depthScale;
                acc += 1.0;
            } else {
                #if COLORED_SHADOWS == 1
                    acc += mix(vec3(1.0), sc0.rgb, sc0.a);
                #else
                    acc += vec3(1.0 - sc0.a);
                #endif
            }
        }
        vec3 lit = acc / float(taps);
        // Share of the light that reached here through water (not of all taps: otherwise the
        // edge of a shadow under water came out brighter than open water around it).
        r.waterFrac = openAcc > 0.0 ? waterAcc / openAcc : 0.0;
        r.waterDepth = waterAcc > 0.0 ? waterDepthAcc / waterAcc : 0.0;
        if (wProbe > 0.0) {
            r.waterFrac = max(r.waterFrac, 1.0);
            r.waterDepth = max(r.waterDepth, wProbe);
            // Deep down, light scattered in the water fills shadows in.
            lit = 1.0 - (1.0 - lit) * exp(-r.waterDepth / 10.0);
        }
        r.light = mix(lit, r.light, fadeOut);
    #endif
    return r;
}

// Cheap single-tap test used along view rays (volumetric light).
float shadowTap(vec3 playerPos, out float waterDepth) {
    waterDepth = 0.0;
    #if USE_SHADOWS == 1
        vec3 sc = (shadowProjection * vec4((lfShadowModelView() * vec4(playerPos, 1.0)).xyz, 1.0)).xyz;
        if (abs(sc.x) > 1.0 || abs(sc.y) > 1.0 || abs(sc.z) > 0.995) return 1.0;
        sc.xy = distortShadowXY(sc.xy);
        sc = sc * 0.5 + 0.5;
        float b = 0.05 * abs(shadowProjection[2][2]) * 0.5;   // 0.05 blocks
        float d1 = texture(shadowtex1, sc.xy).r;
        if (d1 < sc.z - b) return 0.0;
        float d0 = texture(shadowtex0, sc.xy).r;
        if (d0 < sc.z - b) waterDepth = (sc.z - d0) * abs(2.0 / shadowProjection[2][2]);
        return 1.0;
    #else
        return 1.0;
    #endif
}
#endif

#endif
