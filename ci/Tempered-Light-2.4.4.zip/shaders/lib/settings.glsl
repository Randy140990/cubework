/*
    Tempered Light
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.

    Options. Every user-facing setting lives here so Iris finds one definition
    for each. Derived values (what a Look resolves to) always carry a value and
    no option comment, so Iris never mistakes them for menu options.
*/
#ifndef LF_SETTINGS
#define LF_SETTINGS

#define INFO 0 // [0]

// ---------------------------------------------------------------- Look -----
// 0 Custom, 1 Tempered, 2 Realistic, 3 Blocky, 4 Storybook, 5 Vivid
#define LOOK 1 // [1 2 3 4 5 0]

// ------------------------------------------------------- Sun and Moon -----
#define SUN_STYLE 0 // [0 1 2 3 4]
#define SUN_SIZE 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
#define SUN_BRIGHTNESS 0.25 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0]
#define MOON_STYLE 0 // [0 1 2 3 4]
#define MOON_SIZE 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
#define MOON_BRIGHTNESS 0.5 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define MOON_PHASES 1 // [0 1]
#define SUN_GLOW 0.25 // [0.0 0.1 0.25 0.4 0.5 0.6 0.8 1.0 1.5 2.0]
#define MOON_GLOW 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
const float sunPathRotation = -20.0; // [-40.0 -30.0 -20.0 -10.0 0.0 10.0 20.0 30.0 40.0]

// ------------------------------------------------------- Sky and Stars ----
#define SKY_QUALITY 1 // [0 1 2]
#define SKY_SATURATION 1.0 // [0.6 0.8 1.0 1.2 1.4]
#define SKY_BRIGHTNESS 1.0 // [0.6 0.8 1.0 1.2 1.4]
#define SUNSET_STRENGTH 1.25 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define STARS 1 // [0 1]
#define STAR_BRIGHTNESS 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define STAR_AMOUNT 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define MILKY_WAY 1 // [0 1]
#define MILKY_WAY_BRIGHTNESS 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define SKY_ROTATION 1 // [0 1 2 4 8]
#define DAY_MILKY_WAY 1 // [0 1]
#define RAINBOW 1 // [0 1]

// ------------------------------------------------------------- Clouds -----
// 0 follow Look, 1 Blocky volumetric, 2 Realistic volumetric, 3 Vanilla, 4 Off
#define CLOUD_STYLE 0 // [0 1 2 5 3 4]
#define CLOUD_QUALITY 1 // [0 1 2 3]
#define CLOUD_COVERAGE 0.25 // [0.0 0.1 0.25 0.4 0.5 0.75 1.0 1.25 1.5 2.0]
#define CLOUD_SPEED 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0 5.0]
#define BLOCKY_CLOUD_ALTITUDE 192 // [128 160 192 224 256 288 320]
#define BLOCKY_CLOUD_THICKNESS 6 // [4 6 8 10 12 16]
#define BLOCKY_CLOUD_SIZE 12 // [8 12 16 24]
#define CLOUD_LAYERS 2 // [1 2 3]
#define CLOUD_HEIGHT_VARIATION 32 // [0 8 16 24 32 48 64]
#define BLOCKY_CLOUD_TOWERS 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define REALISTIC_CLOUD_ALTITUDE 320 // [256 288 320 384 448 512]
#define CLOUD_SHADOWS 1 // [0 1]
#define CLOUD_EVOLVE 1 // [0 1]
#define CLOUD_SHADOW_STRENGTH 0.75 // [0.25 0.5 0.6 0.75 0.9 1.0]

// -------------------------------------------------------------- Water -----
// 0 follow Look, 1 Natural, 2 Crystal clear, 3 Tropical
#define WATER_STYLE 0 // [0 1 2 3]
#define WATER_WAVES 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define WAVE_HEIGHT 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define WATER_SPEED 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define UNDERWATER_VIEW 1.0 // [0.5 1.0 1.5 2.0 3.0]
#define SHORE_WAVES 1 // [0 1]
#define WATER_FLOW 1 // [0 1]
#define RAIN_ON_WATER 1 // [0 1]
#define PLAYER_WAKE 1 // [0 1]
#define SCREEN_DROPLETS 1 // [0 1]
#define WATER_WAVE_DETAIL 1 // [0 1 2]
#define WATER_REFLECTIONS 2 // [0 1 2 3]
#define WATER_TEXTURE 0.15 // [0.0 0.1 0.15 0.25 0.4]
#define CAUSTICS 1 // [0 1]
#define UNDERWATER_RAYS 1 // [0 1]
#define WATER_FOAM 1 // [0 1]

// ----------------------------------------------------------- Lighting -----
#define LIGHT_SPREAD 1 // [0 1 2]
#define LIGHT_SHADOWS 1 // [0 1]
#define DISTANT_LIGHT_COLOUR 1 // [0 1]
// Per-type light strength (Light Sources page)
#define LIGHT_TORCH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_LANTERN 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_CANDLE 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_FIRE 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_FURNACE 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_SOUL 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_SEA_LANTERN 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_GLOWSTONE 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_SHROOMLIGHT 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_REDSTONE_LAMP 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_FROGLIGHT 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_END_ROD 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_REDSTONE 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_COPPER 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_LAVA 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_MAGMA 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_AMETHYST 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_CRYING 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_NATURE 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_ORES 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define LIGHT_OTHER 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define BLOCKLIGHT_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define BLOCKLIGHT_WARMTH 1.0 // [0.0 0.25 0.5 0.75 1.0]
#define EMISSIVE_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define GEM_GLOW 1 // [0 1]
#define GEM_GLOW_STRENGTH 1.0 // [0.5 1.0 1.5 2.0]
#define ORE_GLOW 1 // [0 1]
#define ORE_GLOW_STRENGTH 1.0 // [0.5 1.0 1.5 2.0]
#define HANDHELD_LIGHT 1 // [0 1]
#define HELD_LIGHT_SHADOWS 1 // [0 1]
#define SKY_LIGHT_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.25 1.5]
#define NIGHT_BRIGHTNESS 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define CAVE_BRIGHTNESS 1.0 // [0.0 0.5 1.0 2.0 4.0]
#define MATERIALS 1 // [0 1]
#define NORMAL_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define SPECULAR_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define PBR_AO 1 // [0 1]
#define PBR_EMISSION 1 // [0 1]
#define DEFAULT_SHINE 1 // [0 1 2]
#define GENERATED_NORMALS 1 // [0 1]
#define GENERATED_NORMAL_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define SSAO 1 // [0 1]
#define SSAO_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define GLASS_TINT 1.5 // [0.0 0.5 1.0 1.5 2.0 3.0 4.0]
#define GLASS_OPACITY 0.5 // [0.0 0.25 0.4 0.5 0.6 0.75 0.9 1.0]
#define GLASS_FROST 0.75 // [0.0 0.25 0.5 0.75 1.0]
#define SAND_SATURATION 1.0 // [0.6 0.7 0.8 0.9 1.0]
#define PARALLAX 1 // [0 1]
#define PARALLAX_DEPTH 0.25 // [0.1 0.15 0.25 0.35 0.5]
#define PARALLAX_SAMPLES 32 // [16 32 64]
#define FOLIAGE_GLOW 1 // [0 1]

// ------------------------------------------------------------ Shadows -----
#define SHADOWS 1 // [0 1]
const int shadowMapResolution = 2048; // [512 1024 1536 2048 3072 4096]
const float shadowDistance = 128.0; // [64.0 96.0 128.0 160.0 192.0 256.0 320.0 384.0]
#define SHADOW_SOFTNESS 1 // [0 1 2]
#define COLORED_SHADOWS 1 // [0 1]

// ---------------------------------------------------------- Firelight -----
#define FIRE_FLICKER 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]
#define SHADOW_DANCE 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]

// ------------------------------------------------------------ Weather -----
#define WET_SURFACES 1 // [0 1]
#define PUDDLES 1 // [0 1]
#define PUDDLE_AMOUNT 1.0 // [0.5 0.75 1.0 1.25 1.5]
#define RAIN_RIPPLES 1 // [0 1]
#define RAIN_OPACITY 0.6 // [0.2 0.4 0.6 0.8 1.0]
#define RAIN_GLOOM 1.0 // [0.0 0.5 1.0 1.5]
#define SNOW_STYLE 1 // [0 1]
#define SPLASH_STYLE 1 // [0 1]
#define WET_MODE 1 // [1 2]
#define WALL_DRIPS 1 // [0 1]
#define CANOPY_DRIPS 2 // [0 1 2 3]
#define RAIN_ON_SCREEN 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define PUDDLE_COVERAGE 1 // [1 2]
#define WEATHER_SLANT 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define STORM_DARKNESS 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define LIGHTNING_FLASH 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define LIGHTNING_STYLE 2 // [2 0 1]
// (A bolt is drawn even with Lightning Flashes off.)
#define LIGHTNING_FLASH_VIS 1.0
#define CLOUD_RAYS 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define SNOW_COVER 1.0 // [0.0 0.25 0.5 0.75 1.0]
#define SNOWSTORMS 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]
#define BREATH 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define SCREEN_FROST 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define NETHER_ASH 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0]
#define NETHER_EMBERS 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0]

// --------------------------------------------------------------- Wind -----
#define WIND_DIRECTION 45 // [0 45 90 135 180 225 270 315]
#define WIND_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]
#define WAVING_PLANTS 1 // [0 1]
#define WAVING_LEAVES 1 // [0 1]
#define FALLING_LEAVES 1 // [0 1]
#define FALLING_LEAVES_AMOUNT 1.0 // [0.25 0.5 1.0 1.5 2.0 3.0]
#define WAVING_LANTERNS 1 // [0 1]
#define SMOKE_DRIFT 1 // [0 1]
#define SMOKE_STYLE 2 // [2 0 1]
#define SMOKE_HEIGHT 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define SMOKE_THICKNESS 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define GRASS_PLAYER_BEND 1 // [0 1]
#define LAVA_WAVES 1 // [0 1]
#define END_SKY 1 // [0 1]
#define END_HOLE_SIZE 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define END_GLOW 1.0 // [0.0 0.5 1.0 1.5 2.0]
// Fixed places in the sky of the End's black hole and the Nether roof's black sun.
#define END_HOLE_DIR vec3(-0.636, 0.423, -0.646)
#define NETHER_SUN_DIR vec3(0.470, 0.342, -0.814)
#define NETHER_ROOF_SKY 1 // [0 1]
#define NETHER_CLOUD_AMOUNT 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define NETHER_SUN_SIZE 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
#define NETHER_LIGHTNING 1 // [0 1]
#define END_PILLARS 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define END_VORTEX 1 // [0 1]
#define END_SHADOWS 1 // [0 1]
#define END_MIST 1 // [0 1]
#define END_MIST_STRENGTH 2.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 5.0]
#define END_STORM 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define END_SWIRL 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define NETHER_MIST 1 // [0 1]
#define NETHER_MIST_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 5.0]
#define NETHER_GLOW 1.0 // [0.0 0.5 1.0 1.5 2.0]

// ------------------------------------------------------- Nether portals ----
// Portal Style: 1 Vortex (purple), 2 Rift (red), 0 Minecraft's own texture.
#define PORTAL_STYLE 1 // [1 2 0]
#define PORTAL_SWIRL 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define PORTAL_CORE 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define PORTAL_TENDRILS 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define PORTAL_MIST 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
// End Portal Style: 1 Void (a window into the End, breathing out vapour and sparks), 0 Minecraft.
#define END_PORTAL_STYLE 1 // [1 0]
#define END_PORTAL_VAPOUR 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define END_PORTAL_SPARKS 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]

// ---------------------------------------------------- Distance and Haze ----
// Off by default: switches turn each on, the sliders beside them only set how much.
#define HAZE 0 // [0 1]
#define HAZE_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define LOW_MIST 0 // [0 1]
#define MIST_STRENGTH 0.5 // [0.25 0.5 1.0 1.5 2.0]
#define BORDER_FOG 1 // [0 1]
#define GROUND_FOG 0 // [0 1]
#define GROUND_FOG_DENSITY 1.0 // [0.25 0.5 1.0 1.5 2.0 3.0]
#define GROUND_FOG_HEIGHT 10 // [4 6 10 16 24]
#define VOLUMETRIC_LIGHT 1 // [0 1]
#define VOLUMETRIC_STRENGTH 1.0 // [0.5 1.0 1.5 2.0]

// ---------------------------------------------------- Colour and Camera ----
// 0 follow Look, 1 Natural, 2 Storybook, 3 Vivid, 4 Punchy
#define COLOUR_GRADE 0 // [0 5 1 2 3 4]
#define EXPOSURE 0.0 // [-1.5 -1.0 -0.5 0.0 0.5 1.0 1.5]
#define SATURATION 1.0 // [0.6 0.8 0.9 1.0 1.1 1.2 1.4]
#define CONTRAST 1.0 // [0.8 0.9 1.0 1.1 1.2]
#define BLOOM 1 // [0 1]
#define BLOOM_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define VIGNETTE 1 // [0 1]
#define TAA 1 // [0 1 2]
#define SHARPEN 0.5 // [0.0 0.25 0.5 0.75 1.0]
// World blur: 0 off, 1 distance blur, 2 depth of field
#define WORLD_BLUR 2 // [0 1 2]
#define WB_FOV_SCALED 0 // [0 1]
#define WB_CHROMATIC 0 // [0 1]
#define WB_ANAMORPHIC 0 // [0 1]
#define DOF_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 4.0]
const float DOF_APERTURE = 36.0;   // blur (px at 1080p) per unit of nearness away from the focus
const float DOF_MAX_BLUR = 10.0;   // the blur eases towards this many px (at 1080p)
#define DOF_FOCUS 0 // [0 2 4 8 16 32 64 128 256]
#define DOF_QUALITY 48 // [16 32 48 64 96]
#define DB_DAY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define DB_NIGHT 0.75 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define DB_RAIN 1.5 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define DB_WATER 2.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define DB_NETHER 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define DB_END 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define DISTANT_LIGHT_BOKEH 0 // [0 1]
#define VIBRANCE 0.0 // [-0.2 -0.1 0.0 0.1 0.2 0.3 0.5]
#define DARK_DESATURATION 0.0 // [0.0 0.25 0.5 0.75 1.0]
#define WHITE_POINT 1.0 // [0.6 0.8 1.0 1.25 1.5 2.0]
#define MOTION_BLUR 1 // [0 1]
#define MOTION_BLUR_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define CHROMATIC_ABERRATION 0.0 // [0.0 0.25 0.5 1.0 1.5 2.0]
#define LENS_FLARE 1 // [0 1 2]
#define LENS_FLARE_STRENGTH 1.0 // [0.25 0.5 1.0 1.5 2.0]
#define UNDERWATER_DISTORTION 1 // [0 1]

// ----------------------------------------------------------- Advanced -----
#define DEBUG_VIEW 0 // [0 1 2 3 4 5 6 7]

// ------------------------------------------------- engine constants -------
const float shadowDistanceRenderMul = 1.0;
const float shadowIntervalSize = 2.0;
const bool shadowtex0Nearest = true;
const bool shadowtex1Nearest = true;
const bool shadowcolor0Nearest = true;
// Iris draws everything this close into the shadow map whichever way you look (and
// beyond it only what its own sun could shadow into view). In the End the light comes
// from the black hole, not that sun, so there the whole island area is kept.
#ifdef DIM_END
const float voxelDistance = 192.0;
#else
const float voxelDistance = 64.0;
#endif
// How far the shadow map reaches towards the light and away from it. Iris's own
// default (100 blocks towards the sun, 156 away) left out anything higher up
// towards the sun, like a floating island, so its shadow came and went as you
// walked. 512 both ways covers the whole build height from anywhere.
const float shadowNearPlane = -512.0;
const float shadowFarPlane = 512.0;
const int noiseTextureResolution = 256;
const float wetnessHalflife = 300.0;
const float drynessHalflife = 120.0;
const float eyeBrightnessHalflife = 4.0;
const float ambientOcclusionLevel = 1.0;
const float centerDepthHalflife = 0.5;

// ============================================== Look resolution ===========
// Sun: 1 Round, 2 Square, 3 Vanilla texture, 4 Off
#if SUN_STYLE != 0
    #define SUN_SHAPE SUN_STYLE
#elif LOOK == 3
    #define SUN_SHAPE 2
#else
    #define SUN_SHAPE 1
#endif

#if MOON_STYLE != 0
    #define MOON_SHAPE MOON_STYLE
#elif LOOK == 3
    #define MOON_SHAPE 2
#else
    #define MOON_SHAPE 1
#endif

// Clouds: 1 Blocky, 2 Volumetric, 5 Realistic (wide decks), 3 Vanilla, 4 Off
#if CLOUD_STYLE != 0
    #define CLOUD_MODE CLOUD_STYLE
#elif LOOK == 2
    #define CLOUD_MODE 5
#elif LOOK == 5
    #define CLOUD_MODE 2
#else
    #define CLOUD_MODE 1
#endif

// Lightning bolts: 2 Follow Clouds (Minecraft's blocky bolt with Blocky or Vanilla
// clouds, the realistic bolt with the others), 0 Minecraft, 1 Realistic.
#if LIGHTNING_STYLE == 1 || (LIGHTNING_STYLE == 2 && CLOUD_MODE != 1 && CLOUD_MODE != 3)
    #define LIGHTNING_REAL 1
#else
    #define LIGHTNING_REAL 0
#endif

// Water: 1 Natural, 2 Crystal, 3 Tropical
#if WATER_STYLE != 0
    #define WATER_MODE WATER_STYLE
#elif LOOK == 4 || LOOK == 5
    #define WATER_MODE 3
#elif LOOK == 2
    #define WATER_MODE 2
#else
    #define WATER_MODE 1
#endif

// Grade: 1 Natural, 2 Storybook, 3 Vivid, 4 Punchy
#if COLOUR_GRADE != 0
    #define GRADE_MODE COLOUR_GRADE
#elif LOOK == 2
    #define GRADE_MODE 1
#elif LOOK == 3
    #define GRADE_MODE 4
#elif LOOK == 4
    #define GRADE_MODE 2
#elif LOOK == 5
    #define GRADE_MODE 3
#else
    #define GRADE_MODE 5
#endif

// Storybook look softens shadows and lifts the night a little.
#if LOOK == 4
    #define LOOK_NIGHT_LIFT 1.6
    #define LOOK_SHADOW_LIFT 0.18
#elif LOOK == 3
    #define LOOK_NIGHT_LIFT 1.2
    #define LOOK_SHADOW_LIFT 0.08
#else
    #define LOOK_NIGHT_LIFT 1.0
    #define LOOK_SHADOW_LIFT 0.0
#endif

// Coloured light spread needs Iris custom images + compute shaders.
#if LIGHT_SPREAD > 0 && defined IRIS_FEATURE_CUSTOM_IMAGES && defined IRIS_FEATURE_COMPUTE_SHADERS
    #define USE_FLOODFILL 1
#else
    #define USE_FLOODFILL 0
#endif

// Drips from the edges of trees and overhangs: 1 light, 2 normal, 3 heavy.
#if CANOPY_DRIPS > 0
    #define CANOPY_DRIPS_ON 1
#else
    #define CANOPY_DRIPS_ON 0
#endif

// Smoke: 2 Follow Clouds (Minecraft's puffs with Blocky or Vanilla clouds, realistic
// plumes with the others), 0 Minecraft, 1 Realistic. The plumes need the light grid.
#if USE_FLOODFILL == 1 && (SMOKE_STYLE == 1 || (SMOKE_STYLE == 2 && CLOUD_MODE != 1 && CLOUD_MODE != 3))
    #define SMOKE_REAL 1
#else
    #define SMOKE_REAL 0
#endif

#if LIGHT_SPREAD == 2
    #define FF_SIZE_XZ 128
    #define FF_SIZE_Y 128
#else
    #define FF_SIZE_XZ 64
    #define FF_SIZE_Y 64
#endif

// Nether portals centred on the whole portal (its middle found in the light grid).
#if USE_FLOODFILL == 1 && PORTAL_STYLE != 0
    #define PORTAL_LIST 1
#else
    #define PORTAL_LIST 0
#endif
// End portals found in the light grid (they light it in colour and breathe out vapour).
#if USE_FLOODFILL == 1 && END_PORTAL_STYLE == 1
    #define END_PORTAL_LIST 1
#else
    #define END_PORTAL_LIST 0
#endif

// Distant light colour: beyond the light grid, a coarse grid of 4-block cells
// remembers the colour of the light sources out to the shadow distance.
#if USE_FLOODFILL == 1 && DISTANT_LIGHT_COLOUR == 1
    #define USE_FAR_LIGHT 1
#else
    #define USE_FAR_LIGHT 0
#endif
#define FAR_CELL 4.0
#if LIGHT_SPREAD == 2
    #define FAR_SIZE_XZ 128
    #define FAR_SIZE_Y 48
#else
    #define FAR_SIZE_XZ 64
    #define FAR_SIZE_Y 32
#endif

#if SHADOWS == 1
    #define USE_SHADOWS 1
#else
    #define USE_SHADOWS 0
#endif

// What the Haze and Low Mist switches leave of their sliders.
#if HAZE == 1
    #define HAZE_K HAZE_STRENGTH
#else
    #define HAZE_K 0.0
#endif
#if LOW_MIST == 1
    #define MIST_K MIST_STRENGTH
#else
    #define MIST_K 0.0
#endif

#endif
