/*
    Tempered Light - wind-driven plant, leaf and lantern movement (vertex stage).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_WAVING
#define LF_WAVING

vec3 swayOffset(vec3 worldPos, float amount, float speed, float t) {
    vec2 d = windDirection();
    float s = windStrength();
    float ph = dot(worldPos.xz, d) * 0.21 + hash12(floor(worldPos.xz)) * 6.2831;
    float gust = windGust(worldPos.xz, t);
    // In storms plants thrash: a quicker, choppier flutter on top, and the gusts
    // bend them right over.
    float storm = saturate(lfThunder + 0.4 * lfRain);
    float swing = sin(t * speed + ph) * 0.55 + sin(t * speed * 2.3 + ph * 1.7) * 0.2
                + sin(t * speed * 4.1 + ph * 2.9) * 0.22 * storm;
    float lean = gust * (0.9 + 0.7 * storm) + 0.25;
    vec2 side = vec2(-d.y, d.x) * sin(t * speed * 1.37 + ph * 0.7) * (0.25 + 0.2 * storm);
    vec2 xz = (d * (swing + lean) + side) * amount * s;
    return vec3(xz.x, -abs(swing) * amount * s * 0.15, xz.y);
}

// worldPos: vertex position in world space. playerPos: camera-relative.
// top: the vertex is on the top edge of its quad's texture.
// blockY: how high the vertex sits in its block (0 bottom, 1 top).
vec3 wavingOffset(int cat, vec3 worldPos, vec3 playerPos, bool top, float skyLight, float blockY) {
    vec3 o = vec3(0.0);
    float t = frameTimeCounter;
    float outdoor = mix(0.2, 1.0, smoothstep(0.3, 0.9, skyLight));
    #if WAVING_PLANTS == 1
        if (cat == CAT_PLANT_SHORT || cat == CAT_CROP || cat == CAT_GLOW_BUSH) {
            if (top) o = swayOffset(worldPos, cat == CAT_CROP ? 0.07 : 0.10, 1.6, t) * outdoor;
        } else if (cat == CAT_PLANT_TALL_LOWER) {
            if (top) o = swayOffset(worldPos, 0.05, 1.4, t) * outdoor;
        } else if (cat == CAT_PLANT_TALL_UPPER) {
            o = swayOffset(worldPos - vec3(0, 1, 0), top ? 0.15 : 0.05, 1.4, t) * outdoor;
        } else if (cat == CAT_BUSH) {
            // Azalea bushes: the leafy top sways on its stem. Weighted by height in the
            // block, so the faces of the leafy cube stay joined.
            o = swayOffset(worldPos, 0.07, 1.3, t) * saturate(blockY) * outdoor;
        } else if (cat == CAT_VINE || cat == CAT_GLOW_VINE) {
            o = swayOffset(worldPos, 0.05, 1.1, t) * outdoor;
        } else if (cat == CAT_GROUND_COVER) {
            // Petals, wildflowers and fallen leaves rustle; the parts on the ground stay put.
            float above = worldPos.y - floor(worldPos.y + 0.002);
            o = swayOffset(worldPos, 0.03, 2.1, t) * smoothstep(0.01, 0.12, above) * outdoor;
        } else if (cat == CAT_CANE) {
            o = swayOffset(worldPos, 0.025 * fract(worldPos.y - 0.001), 1.0, t) * outdoor;
        } else if (cat == CAT_LILY_PAD) {
            o.y = sin(t * 1.3 + dot(worldPos.xz, vec2(0.7, 0.4))) * 0.015;
        } else if (cat == CAT_SEAGRASS) {
            if (top) o.xz = vec2(sin(t * 1.1 + worldPos.x * 0.4), cos(t * 0.9 + worldPos.z * 0.4)) * 0.07;
        } else if (cat == CAT_KELP) {
            // Kelp and tall seagrass wave as one strand: the offset follows the height,
            // so stacked pieces stay joined while a slow wave runs up them.
            float ph = hash12(floor(worldPos.xz)) * 6.2831;
            o.xz = vec2(sin(t * 1.05 + worldPos.y * 0.55 + ph), cos(t * 0.85 + worldPos.y * 0.5 + ph)) * 0.08;
        } else if (cat == CAT_CORAL) {
            // Coral and sea fans stir gently in the current.
            if (top) o.xz = vec2(sin(t * 0.9 + worldPos.x * 0.5 + worldPos.z * 0.3), cos(t * 0.75 + worldPos.z * 0.5)) * 0.035;
        }
        #if GRASS_PLAYER_BEND == 1
            if (top && (cat == CAT_PLANT_SHORT || cat == CAT_PLANT_TALL_LOWER || cat == CAT_PLANT_TALL_UPPER || cat == CAT_CROP || cat == CAT_GLOW_BUSH)) {
                vec3 rel = playerPos - vec3(0.0, -1.2, 0.0);
                float dist = length(rel.xz);
                if (dist < 1.3 && abs(rel.y) < 1.4) o.xz += normalize(rel.xz + 1e-4) * (1.3 - dist) * 0.45;
            }
        #endif
    #endif
    #if WAVING_LEAVES == 1
        if (cat == CAT_LEAVES) {
            o = swayOffset(worldPos, 0.035, 1.2, t) * outdoor;
            float flutter = sin(t * 7.0 + dot(worldPos, vec3(2.1, 1.7, 2.9))) * 0.012 * windStrength();
            o += vec3(flutter, flutter * 0.5, -flutter) * outdoor;
        }
    #endif
    #if WAVING_LANTERNS == 1
        if (cat == CAT_LANTERN_HANGING || cat == CAT_SOUL_LANTERN_HANGING || cat == CAT_COPPER_LANTERN_HANGING) {
            float drop = 1.0 - fract(worldPos.y - 0.001);
            vec2 d = windDirection();
            float ph = dot(floor(worldPos.xz), vec2(1.3, 2.1));
            o.xz += (d * (0.6 + sin(t * 1.4 + ph)) + vec2(-d.y, d.x) * sin(t * 0.9 + ph) * 0.4) * 0.035 * drop * windStrength() * outdoor;
        }
    #endif
    return o;
}

#endif
