/*
    Tempered Light - the End Storm's cloud (End Storm on the Nether & End page), shared
    by the sky (fog.glsl) and the island's lighting (deferred), so the clouds you see
    are the clouds that shade the island.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_ENDSTORM
#define LF_ENDSTORM

// Storm & Mist Swirl: the End's storm cloud and mist turn steadily about the island,
// wound into spiral arms that seem to pour in towards it as they turn (a turning spiral
// reads as an inflow). The turn is the same at every distance, so the cloud never winds
// itself into thin streaks however long you stay; the small billows turn a little faster
// than the big shapes, so the cloud churns as it goes round.
float endSwirlAngle(float t) { return t * 0.04 * END_SWIRL; }
vec3 endSwirlTurn(vec3 c, float ang) {
    float ca = cos(ang), sa = sin(ang);
    return vec3(ca * c.x - sa * c.z, c.y, sa * c.x + ca * c.z);
}
// 0..1 across the spiral arms. s: the point in the turning frame (about the island's
// axis), r: its distance from that axis, rag: noise that roughens the arms' edges.
// The arms fade out near the axis, where they would otherwise pinch into a pinwheel.
float endSpiralArms(vec3 s, float r, float arms, float wind, float rag) {
    float ph = arms * atan(s.z, s.x + 1e-4) + wind * log(max(r, 8.0)) + rag;
    return mix(0.5, 0.5 + 0.5 * cos(ph), smoothstep(25.0, 90.0, r));
}

// End Storm: a wall of heavy violet cloud wrapped round the main island like the eye
// of a storm, with a gap towards the black hole so its light still pours across the
// island. Lit by the hole: bright, silvered edges on the side facing it, deep
// blue-violet in the folds. Drawn from where you are out to 700 blocks.
float endStormDensity(vec3 p, float t, int octaves) {
    // Distance from the island's heart, squashed a little up and down.
    vec3 c = p - vec3(0.0, 70.0, 0.0);
    float q = length(vec3(c.x, c.y * 1.25, c.z));
    float wall = smoothstep(115.0, 190.0, q) * (1.0 - smoothstep(520.0, 800.0, q));
    if (wall <= 0.0 || p.y < -60.0) return 0.0;
    // The gap towards the black hole: thinner there, with ragged streamers drifting
    // across it, so the light pours through but cloud shadows sweep the island.
    float toHole = dot(normalize(c), normalize(END_HOLE_DIR));
    float gap = smoothstep(0.80, 0.93, toHole);
    wall *= 1.0 - 0.22 * gap;
    float r = length(c.xz);
    float ang = endSwirlAngle(t);
    const vec3 SC = vec3(0.009, 0.014, 0.009);
    vec3 s = endSwirlTurn(c, ang);
    // A slow rise keeps the shapes changing as they turn.
    vec3 n3 = s * SC + vec3(0.0, t * 0.003, 0.0);
    float n = vnoise3(n3) * 0.55;
    if (octaves > 1) {
        vec3 n4 = endSwirlTurn(c, ang * 1.6) * SC + vec3(0.0, t * 0.005, 0.0);
        n += vnoise3(n4 * 2.7 + 3.1) * 0.3 + vnoise3(n4 * 6.3 + 7.7) * 0.15;
    } else n += 0.22;
    if (END_SWIRL > 0.0) {
        // Three ragged arms spiralling in to the island.
        float arms = endSpiralArms(s, r, 3.0, 6.0, n * 3.0);
        n += (arms - 0.5) * 0.38 * min(END_SWIRL, 1.0);
    }
    // A heavy storm closes in: the billows fill out until there are few clear gaps
    // (fewer still in front of the hole, where streamers break its light into beams).
    float cover = 0.08 * min(END_STORM, 1.5);
    float billow = saturate((n - 0.42 + cover) * 2.4);
    return wall * billow;
}
// The breaks in the storm the hole's light falls through (0..1): a pattern on the
// plane facing the hole, drifting as the storm turns, so a beam in the air and the
// bright patch it lights on the ground line up.
float endBeams(vec3 worldPos, float t) {
    vec3 L = normalize(END_HOLE_DIR);
    vec3 bx = normalize(cross(vec3(0.0, 1.0, 0.0), L));
    vec3 by = cross(L, bx);
    vec2 lp = vec2(dot(worldPos, bx), dot(worldPos, by)) + vec2(t * 0.9, t * 0.25) * (0.3 + END_SWIRL);
    float m = vnoise(lp * 0.055) * 0.62 + vnoise(lp * 0.16 + 7.3) * 0.38;
    return smoothstep(0.47, 0.72, m);
}

// How much of the black hole's light gets through the storm cloud to this point:
// shade under the cloud, bright patches where beams break through, both drifting
// across the island.
float endStormShadow(vec3 worldPos, int samples) {
    if (END_STORM <= 0.0) return 1.0;
    vec3 L = normalize(END_HOLE_DIR);
    float t = frameTimeCounter;
    float od = 0.0;
    float stepL = 660.0 / float(samples);
    for (int i = 0; i < 6; i++) {
        if (i >= samples) break;
        float d = 120.0 + stepL * (float(i) + 0.5);
        od += endStormDensity(worldPos + L * d, t, 1) * stepL;
    }
    float T = exp(-od * 0.012 * END_STORM * 1.3);
    return mix(T, 1.0, 0.85 * endBeams(worldPos, t));
}

// Now and then a flash of blue lightning deep in the End Storm, lighting up the
// cloud and the mist round it (Lightning Flashes sets how bright). xyz: where
// (world), w: how bright now.
const vec3 END_FLASH_COL = vec3(0.45, 0.62, 1.0);
vec4 endFlash() {
    if (END_STORM <= 0.0 || LIGHTNING_FLASH <= 0.0) return vec4(0.0);
    float t = frameTimeCounter;
    const float rate = 0.35;
    float cell = floor(t * rate);
    if (hash12(vec2(cell, 13.7)) < 0.45) return vec4(0.0);
    float age = fract(t * rate) / rate;
    float pulse = exp(-age * 3.5) * (0.35 + 0.65 * step(0.3, hash12(vec2(floor(t * 16.0), cell))));
    vec2 h = hash22(vec2(cell, 5.9));
    float ang = h.x * 6.2832, r = mix(220.0, 560.0, h.y);
    float y = 70.0 + (hash12(vec2(cell, 2.1)) - 0.4) * 160.0;
    return vec4(r * cos(ang), y, r * sin(ang), pulse * min(END_STORM, 1.5) * LIGHTNING_FLASH);
}

#endif
