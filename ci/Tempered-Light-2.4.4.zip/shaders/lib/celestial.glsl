/*
    Tempered Light - sun, moon (with phases), stars and the Milky Way.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_CELESTIAL
#define LF_CELESTIAL

#define SUN_RADIUS (0.0200 * SUN_SIZE)
#define MOON_RADIUS (0.0190 * MOON_SIZE)

// Axis the sky turns around (follows sunPathRotation), made orthogonal to the sun.
vec3 celestialAxis(vec3 sunDir) {
    float a = radians(sunPathRotation);
    vec3 axis = vec3(0.0, sin(a), cos(a));
    return normalize(axis - sunDir * dot(axis, sunDir));
}

// Sky-fixed coordinates: stars turn with the sun. Sky Rotation speeds that up
// (2x, 4x, 8x, like a time-lapse) or holds the stars still (0).
vec3 toCelestial(vec3 dir, vec3 sunDir) {
    vec3 e3 = celestialAxis(sunDir);
    vec3 e1 = sunDir;
    vec3 e2 = cross(e3, e1);
    vec3 c = vec3(dot(dir, e1), dot(dir, e2), dot(dir, e3));
    #if SKY_ROTATION != 1
        float phi = -float(SKY_ROTATION - 1) * sunAngle * TAU;
        c.xy = rot2(phi) * c.xy;
    #endif
    return c;
}

// Local disk coordinates in units of the body's radius (x along its path, y along the axis).
vec2 diskCoords(vec3 dir, vec3 bodyDir, vec3 axis, float radius) {
    vec3 ex = normalize(cross(axis, bodyDir));
    vec3 d = dir - bodyDir * dot(dir, bodyDir);
    return vec2(dot(d, ex), dot(d, axis)) / radius;
}

// Sun disk radiance. tView: atmospheric transmittance towards the sun.
vec3 sunDisk(vec3 dir, vec3 sunDir, vec3 tView, float pixelAngle) {
    #if SUN_SHAPE == 4 || SUN_SHAPE == 3
        return vec3(0.0);
    #else
        if (dot(dir, sunDir) < 0.99) return vec3(0.0);
        vec3 axis = celestialAxis(sunDir);
        vec2 q = diskCoords(dir, sunDir, axis, SUN_RADIUS);
        float aa = pixelAngle / SUN_RADIUS * 1.5;
        #if SUN_SHAPE == 2
            float edge = max(abs(q.x), abs(q.y));
            float disk = 1.0 - smoothstep(1.0 - aa, 1.0 + aa, edge);
            float limb = 1.0 - 0.25 * smoothstep(0.5, 1.0, edge);
        #else
            float r = length(q);
            float disk = 1.0 - smoothstep(1.0 - aa, 1.0 + aa, r);
            float mu = sqrt(max(1.0 - r * r, 0.0));
            float limb = 1.0 - 0.55 * (1.0 - mu) - 0.15 * (1.0 - mu * mu);
        #endif
        return vec3(1.0, 0.96, 0.9) * tView * disk * limb * 60.0 * SUN_BRIGHTNESS * (0.55 + 0.45 * min(SUN_GLOW, 1.5));
    #endif
}

// Moon disk radiance with real phases and earthshine.
vec3 moonDisk(vec3 dir, vec3 sunDir, vec3 tView, float pixelAngle) {
    #if MOON_SHAPE == 4 || MOON_SHAPE == 3
        return vec3(0.0);
    #else
        vec3 moonDir = -sunDir;
        if (dot(dir, moonDir) < 0.99) return vec3(0.0);
        vec3 axis = celestialAxis(sunDir);
        vec2 q = diskCoords(dir, moonDir, axis, MOON_RADIUS);
        float aa = pixelAngle / MOON_RADIUS * 1.5;
        #if MOON_PHASES == 1
            float th = float(moonPhase) * 0.785398;
        #else
            float th = 0.0;
        #endif
        vec3 L = vec3(-sin(th), 0.0, cos(th));
        #if MOON_SHAPE == 2
            float edge = max(abs(q.x), abs(q.y));
            float disk = 1.0 - smoothstep(1.0 - aa, 1.0 + aa, edge);
            vec3 n = normalize(vec3(q * 0.9, 1.0));
            vec2 cell = floor((q * 0.5 + 0.5) * 8.0);
            float albedo = 0.75 + 0.25 * hash12(cell + 3.0) - 0.2 * step(0.78, hash12(cell));
        #else
            float r2 = dot(q, q);
            float disk = 1.0 - smoothstep(1.0 - aa, 1.0 + aa, sqrt(r2));
            vec3 n = vec3(q, sqrt(max(1.0 - r2, 0.0)));
            // Maria and a few craters, fixed to the moon's face.
            float maria = smoothstep(0.45, 0.62, fbm2(q * 1.6 + 4.0, 4));
            vec2 cc = q * 5.0;
            vec2 ci = floor(cc);
            vec2 cp = hash22(ci) * 0.6 + 0.2;
            float crater = smoothstep(0.3, 0.12, length(fract(cc) - cp)) * step(0.55, hash12(ci + 9.0));
            float albedo = 0.82 - 0.32 * maria - 0.12 * crater;
        #endif
        float lit = smoothstep(-0.06, 0.12, dot(n, L));
        float earthshine = 0.035;
        // A rising moon turns pale gold rather than red.
        vec3 tv = mix(vec3(luminance(tView)), tView, 0.35);
        return vec3(0.92, 0.95, 1.0) * tv * disk * albedo * (lit + earthshine) * 3.2 * MOON_BRIGHTNESS;
    #endif
}

// Procedural stars on a cubed grid in sky-fixed coordinates.
vec3 starField(vec3 c, float density) {
    float scale = 90.0;
    vec3 p = c * scale;
    vec3 cell = floor(p);
    vec3 h = hash33(cell);
    if (h.x > 0.32 * STAR_AMOUNT * density) return vec3(0.0);
    vec3 starPos = cell + 0.25 + 0.5 * hash33(cell + 17.0);
    float d = length(p - starPos);
    float size = 0.07 + 0.05 * h.y;
    float core = exp(-d * d / (size * size));
    float mag = pow(h.y, 7.0) * 3.0 + 0.08;
    float twinkle = 0.75 + 0.25 * sin(frameTimeCounter * (2.0 + 6.0 * h.z) + h.x * 40.0);
    vec3 col = blackbody(mix(3200.0, 11000.0, h.z * h.z));
    return col * core * mag * twinkle;
}

float fbm3(vec3 p) {
    float s = 0.0, a = 0.5;
    for (int i = 0; i < 4; i++) {
        s += a * vnoise3(p);
        p = p * 2.03 + 11.7;
        a *= 0.5;
    }
    return s / 0.9375;
}

// Milky Way: blue-white star clouds along the band, a golden core, dark rifts of
// dust with reddened edges, and scattered pink glowing nebulae.
vec3 milkyWay(vec3 c, out float band) {
    vec3 nb = normalize(vec3(0.18, 0.62, 0.76));
    float x = dot(c, nb);
    vec3 b1 = normalize(cross(nb, vec3(0.0, 0.0, 1.0)));
    vec3 b2 = cross(nb, b1);
    float ang = atan(dot(c, b2), dot(c, b1));
    float width = 0.165 + 0.055 * sin(ang * 2.0 + 1.0) + 0.02 * sin(ang * 5.0 + 2.0);
    band = exp(-x * x / (2.0 * width * width));
    float core = exp(-ang * ang / 0.5) * exp(-x * x / (2.0 * sqr(width * 1.6)));
    // A broad warm glow from the old stars round the centre of the galaxy.
    float warm = exp(-ang * ang / 1.6) * band;
    float clump = fbm3(c * 6.5);
    float fine = vnoise3(c * 28.0);
    float knots = smoothstep(0.55, 0.85, vnoise3(c * 14.0 + 2.0));
    // Dust: a main rift along the middle plus finer filaments across the band.
    float lane = exp(-sqr(x - 0.02 + 0.03 * sin(ang * 3.0)) / (2.0 * sqr(width * 0.38)));
    float dustN = fbm3(c * 11.0 + 5.0);
    float dust = smoothstep(0.40, 0.70, dustN) * lane + smoothstep(0.62, 0.82, fbm3(c * 23.0 + 9.0)) * band * 0.6;
    dust = saturate(dust);
    float I = (band * (0.3 + 0.9 * clump + 0.3 * fine + 0.5 * knots) + core * 2.4) * (1.0 - 0.88 * dust);
    vec3 blue = vec3(0.50, 0.68, 1.00), white = vec3(0.92, 0.93, 1.0), gold = vec3(1.0, 0.64, 0.34);
    vec3 col = mix(blue, white, saturate(clump * 0.9 + knots * 0.5));
    col = mix(col, vec3(1.0, 0.66, 0.40), saturate(warm * 0.9));
    col = mix(col, gold, saturate(core * 1.5));
    // Starlight reddened to orange and red at the edges of the dust.
    col = mix(col, vec3(1.0, 0.42, 0.24), saturate(dust * (1.0 - dust) * 3.0) * 0.85);
    vec3 L = col * I;
    // The young blue stars of the outer arms shine a little brighter.
    L += vec3(0.40, 0.62, 1.0) * band * (1.0 - saturate(warm * 1.5)) * (0.12 + 0.3 * clump + 0.2 * knots) * (1.0 - 0.8 * dust);
    // Red and pink glowing gas clouds dotted along the band, most towards the centre.
    float neb = smoothstep(0.62, 0.90, vnoise3(c * 9.0 + 13.0)) * smoothstep(0.45, 0.8, vnoise3(c * 31.0 + 4.0)) * band;
    vec3 nebCol = mix(vec3(1.0, 0.22, 0.30), vec3(1.0, 0.36, 0.62), vnoise3(c * 5.0 + 7.0));
    L += nebCol * neb * (1.8 + 1.6 * warm);
    // A touch richer in colour than plain starlight, as in long-exposure photos.
    L = mix(vec3(luminance(L)), L, 1.25);
    return max(L, 0.0) * 0.011;
}

// Everything that shows past the atmosphere at night. Stars start to show just
// before sunset and are boosted through twilight so they read against the sky.
vec3 nightSky(vec3 dir, vec3 sunDir, vec3 tView) {
    float night = smoothstep(0.16, -0.10, sunDir.y);
    #if DAY_MILKY_WAY == 1
        float dayBand = 1.0 - night;
    #else
        float dayBand = 0.0;
    #endif
    if ((night <= 0.0 && dayBand <= 0.0) || dir.y < -0.05) return vec3(0.0);
    float twilight = night * (1.0 - smoothstep(-0.10, -0.25, sunDir.y));
    vec3 c = toCelestial(dir, sunDir);
    vec3 col = vec3(0.0);
    float band = 0.0;
    #if MILKY_WAY == 1
        col += milkyWay(c, band) * MILKY_WAY_BRIGHTNESS * (night + dayBand * 6.0);
    #endif
    #if STARS == 1
        col += starField(c, 1.0 + 2.5 * band) * 0.05 * STAR_BRIGHTNESS * night * (1.0 + 5.0 * twilight);
    #endif
    float clearSky = 1.0 - skyRain();
    return col * tView * clearSky * NIGHT_BRIGHTNESS;
}

// Soft glow around the sun and moon (forward scattering in the air near them).
// Sun Glow and Moon Glow set its strength; the moon's follows its phase.
vec3 celestialGlow(vec3 dir, vec3 sunDir, vec3 sunT, vec3 moonT) {
    float muS = dot(dir, sunDir), muM = -muS;
    vec3 g = vec3(0.0);
    if (muS > 0.0) {
        float p = phaseHG(muS, 0.93) * 0.6 + phaseHG(muS, 0.75) * 0.4;
        g += vec3(1.0, 0.93, 0.82) * sunT * SUN_ILLUMINANCE * p * 0.012 * SUN_GLOW * SUN_BRIGHTNESS * 1.4 * (1.0 - 0.8 * skyRain());
    }
    if (muM > 0.0) {
        // A broad, soft halo (the look of a bright moon through clean air).
        float p = phaseHG(muM, 0.88) * 0.35 + phaseHG(muM, 0.55) * 0.65;
        vec3 mt = mix(vec3(luminance(moonT)), moonT, 0.35);
        g += vec3(0.80, 0.88, 1.0) * mt * MOON_ILLUMINANCE * moonPhaseLight() * p * 0.16 * MOON_GLOW * (0.5 + MOON_BRIGHTNESS) * (1.0 - 0.6 * skyRain());
    }
    return g;
}

#endif
