/*
    Tempered Light - temporal anti-aliasing helpers: a sub-pixel camera
    jitter that cycles every 8 frames, and the matching per-frame noise.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_TAA
#define LF_TAA

// Offset to add to gl_Position.xy (times gl_Position.w).
vec2 taaJitter() {
    #if TAA >= 1
        const vec2 h[8] = vec2[8](vec2(0.5, 0.3333), vec2(0.25, 0.6667), vec2(0.75, 0.1111), vec2(0.125, 0.4444),
                                  vec2(0.625, 0.7778), vec2(0.375, 0.2222), vec2(0.875, 0.5556), vec2(0.0625, 0.8889));
        return (h[frameCounter & 7] - 0.5) * 2.0 / vec2(viewWidth, viewHeight);
    #else
        return vec2(0.0);
    #endif
}

// Per-pixel noise for sampling patterns: changes every frame when TAA can
// average it away, otherwise stays put so it never flickers.
float frameDither(vec2 fragCoord) {
    #if TAA >= 1
        return ignAnimated(fragCoord, frameCounter);
    #else
        return ign(fragCoord);
    #endif
}

#endif
