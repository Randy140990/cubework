/*
    Tempered Light - block categories, light colours and wet-surface behaviour.
    Category = block.properties ID - 1000 (0 when a block isn't listed).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_MATERIALS
#define LF_MATERIALS

#define CAT_DEFAULT 0
#define CAT_PLANT_SHORT 1
#define CAT_PLANT_TALL_LOWER 2
#define CAT_PLANT_TALL_UPPER 3
#define CAT_CROP 4
#define CAT_LEAVES 5
#define CAT_VINE 6
#define CAT_LILY_PAD 7
#define CAT_CANE 8
#define CAT_LANTERN_HANGING 9
#define CAT_SOUL_LANTERN_HANGING 10
#define CAT_SEAGRASS 11
#define CAT_WATER 12
#define CAT_GLASS 13
#define CAT_ICE 14
#define CAT_TRANSLUCENT 15
#define CAT_LAVA 16
#define CAT_FIRE 17
#define CAT_SOUL_FIRE 18
#define CAT_COPPER_LANTERN_HANGING 19
#define CAT_TORCH 20
#define CAT_SOUL 21
#define CAT_SEA_LANTERN 22
#define CAT_GLOWSTONE 23
#define CAT_END_ROD 24
#define CAT_REDSTONE 25
#define CAT_MAGMA 26
#define CAT_PURPLE 27
#define CAT_GREEN_GLOW 28
#define CAT_PINK 29
#define CAT_COPPER_TORCH 30
#define CAT_COPPER_BULB 31
#define CAT_CANDLE 32
#define CAT_DIM_WARM 33
#define CAT_CREAKING 34
#define CAT_LIGHT_BLOCK 35
#define CAT_SCULK 36
#define CAT_TRIAL 37
#define CAT_LANTERN 38
#define CAT_PORTAL 39
#define CAT_EMITTER 40
#define CAT_SHROOMLIGHT 41
#define CAT_REDSTONE_LAMP 42
#define CAT_FROGLIGHT_OCHRE 43
#define CAT_FROGLIGHT_VERDANT 44
#define CAT_FURNACE 45
#define CAT_JACK_O_LANTERN 46
#define CAT_CAMPFIRE 47
#define CAT_CRYING 48
#define CAT_BEACON 49
#define CAT_GEM_EMERALD 50
#define CAT_GEM_DIAMOND 51
#define CAT_GEM_LAPIS 52
#define CAT_GEM_AMETHYST 53
#define CAT_GEM_REDSTONE 54
#define CAT_ORE_DIAMOND 55
#define CAT_ORE_EMERALD 56
#define CAT_ORE_REDSTONE 57
#define CAT_ORE_LAPIS 58
#define CAT_ORE_GOLD 59
#define CAT_SAND 60
#define CAT_DIRT 61
#define CAT_STONE_ROUGH 62
#define CAT_STONE_SMOOTH 63
#define CAT_WOOD 64
#define CAT_METAL 65
#define CAT_WOOL 66
#define CAT_SNOW 67
#define CAT_GLAZED 68
#define CAT_CONCRETE 69
#define CAT_TERRACOTTA 70
#define CAT_SOLID_LAST 70
#define CAT_STAINED_GLASS 71
#define CAT_CARPET 72
#define CAT_GLOW_VINE 73      // cave vines with glow berries: glow like GREEN_GLOW, sway like vines
#define CAT_GLOW_BUSH 74      // firefly bush: glows like GREEN_GLOW, sways like a plant
#define CAT_GROUND_COVER 75   // pink petals, wildflowers, leaf litter
#define CAT_CORAL 76          // live corals and coral fans
#define CAT_KELP 77           // kelp and tall seagrass: strands that wave as one
#define CAT_BUSH 78           // azaleas: a leafy top on a stem
#define CAT_SOUL_CAMPFIRE 79  // lit soul campfire: soul light, smokes like a campfire
#define CAT_END_PORTAL 80     // End portal (block entity): a window into the End (End Portal Style Void)
#define CAT_END_GATEWAY 81    // End gateway (block entity): glows like amethyst
// Not from block.properties: set by programs.
#define CAT_ENTITY 200
#define CAT_HAND 201
#define CAT_UNLIT 202
#define CAT_CLOUD 203
#define CAT_EMISSIVE_ENTITY 204
#define CAT_PARTICLE 205

// entity.properties IDs
#define ENTITY_LIGHTNING 1250

int catFromId(float id) {
    int i = int(id + 0.5) - 1000;
    return (i < 0 || i > 199) ? CAT_DEFAULT : i;
}

bool isFoliage(int c) { return (c >= CAT_PLANT_SHORT && c <= CAT_CANE) || c == CAT_SEAGRASS || (c >= CAT_GLOW_VINE && c <= CAT_BUSH); }
bool isLeaves(int c) { return c == CAT_LEAVES; }
bool isGem(int c) { return c >= CAT_GEM_EMERALD && c <= CAT_GEM_REDSTONE; }
bool isOre(int c) { return c >= CAT_ORE_DIAMOND && c <= CAT_ORE_GOLD; }
// Plants that glow use the same light as the green glow category.
// End gateways (and End portals with Minecraft's look) glow like amethyst.
int glowAlias(int c) {
    if (c == CAT_GLOW_VINE || c == CAT_GLOW_BUSH) return CAT_GREEN_GLOW;
    #if END_PORTAL_STYLE == 0
        if (c == CAT_END_PORTAL) return CAT_PURPLE;
    #endif
    return c == CAT_END_GATEWAY ? CAT_PURPLE : c;
}
bool isEmitterCat(int c) {
    return c == CAT_GLOW_VINE || c == CAT_GLOW_BUSH || c == CAT_LANTERN_HANGING || c == CAT_SOUL_LANTERN_HANGING || c == CAT_COPPER_LANTERN_HANGING ||
           (c >= CAT_LAVA && c <= CAT_SOUL_FIRE) || (c >= CAT_TORCH && c <= CAT_BEACON) || c == CAT_SOUL_CAMPFIRE ||
           c == CAT_END_PORTAL || c == CAT_END_GATEWAY;
}
bool isGlass(int c) { return c == CAT_GLASS || c == CAT_STAINED_GLASS; }

// How much light of each colour gets through a pane of stained glass of this
// (linear) colour. Brighter than the view through it so coloured patches of
// sunlight and lamplight still read as light, not shadow.
vec3 glassLightFilter(vec3 c) {
    c = max(c, vec3(0.05));
    vec3 t = pow(c / maxOf(c), vec3(1.3)) * mix(0.35, 1.0, sqrt(maxOf(c)));
    return saturate(t);
}

// Colour (linear) and strength of the light a block gives off. Each kind of light
// has its own strength: a lantern is gentler than a sea lantern, lava outshines both.
vec4 emitterLight(int c) {
    c = glowAlias(c);
    if (c == CAT_TORCH) return vec4(1.00, 0.55, 0.22, 0.85);
    if (c == CAT_LANTERN || c == CAT_LANTERN_HANGING) return vec4(1.00, 0.70, 0.36, 0.95);
    if (c == CAT_SOUL || c == CAT_SOUL_LANTERN_HANGING || c == CAT_SOUL_FIRE || c == CAT_SOUL_CAMPFIRE) return vec4(0.25, 0.78, 1.00, 0.90);
    if (c == CAT_SEA_LANTERN) return vec4(0.84, 0.96, 1.00, 1.60);   // near-white, a touch of sea blue
    if (c == CAT_GLOWSTONE) return vec4(1.00, 0.76, 0.42, 1.00);
    if (c == CAT_SHROOMLIGHT) return vec4(1.00, 0.56, 0.26, 1.05);
    if (c == CAT_REDSTONE_LAMP) return vec4(1.00, 0.72, 0.42, 1.05);
    if (c == CAT_FROGLIGHT_OCHRE) return vec4(1.00, 0.86, 0.46, 1.10);
    if (c == CAT_FROGLIGHT_VERDANT) return vec4(0.62, 1.00, 0.52, 1.10);
    if (c == CAT_PINK) return vec4(1.00, 0.80, 0.95, 1.10);          // pearlescent froglight: soft pink-white
    if (c == CAT_END_ROD) return vec4(1.00, 0.93, 0.98, 1.25);       // warm white with a hint of pink
    if (c == CAT_BEACON) return vec4(0.82, 0.95, 1.00, 1.50);
    if (c == CAT_REDSTONE) return vec4(1.00, 0.10, 0.04, 0.90);
    if (c == CAT_MAGMA) return vec4(1.00, 0.32, 0.07, 0.75);
    if (c == CAT_PURPLE) return vec4(0.66, 0.30, 1.00, 1.00);
    if (c == CAT_END_PORTAL) return vec4(0.46, 0.44, 1.00, 1.00);   // the End's violet, a touch of teal
    if (c == CAT_CRYING) return vec4(0.55, 0.20, 1.00, 0.90);
    if (c == CAT_GREEN_GLOW) return vec4(0.55, 1.00, 0.42, 0.90);
    if (c == CAT_COPPER_TORCH || c == CAT_COPPER_LANTERN_HANGING) return vec4(0.42, 1.00, 0.55, 1.00);
    if (c == CAT_COPPER_BULB) return vec4(1.00, 0.82, 0.60, 1.20);
    if (c == CAT_CANDLE) return vec4(1.00, 0.58, 0.28, 0.80);
    if (c == CAT_DIM_WARM) return vec4(1.00, 0.60, 0.35, 0.70);
    if (c == CAT_CREAKING) return vec4(1.00, 0.48, 0.14, 0.90);
    if (c == CAT_LIGHT_BLOCK) return vec4(1.00, 0.90, 0.80, 1.00);
    if (c == CAT_SCULK) return vec4(0.20, 0.80, 1.00, 0.70);
    if (c == CAT_TRIAL) return vec4(1.00, 0.55, 0.20, 1.00);
    if (c == CAT_LAVA) return vec4(1.00, 0.40, 0.09, 2.20);
    if (c == CAT_FIRE) return vec4(1.00, 0.42, 0.10, 1.10);
    if (c == CAT_CAMPFIRE) return vec4(1.00, 0.46, 0.13, 1.15);
    if (c == CAT_FURNACE) return vec4(1.00, 0.52, 0.20, 0.85);
    if (c == CAT_JACK_O_LANTERN) return vec4(1.00, 0.62, 0.20, 1.00);
    #if PORTAL_STYLE == 2
        if (c == CAT_PORTAL) return vec4(1.00, 0.16, 0.07, 1.00);    // Rift portals glow red
    #else
        if (c == CAT_PORTAL) return vec4(0.62, 0.22, 1.00, 1.00);
    #endif
    if (c == CAT_GEM_EMERALD) return vec4(0.18, 1.00, 0.40, 1.00);
    if (c == CAT_GEM_DIAMOND) return vec4(0.30, 0.78, 1.00, 1.00);
    if (c == CAT_GEM_LAPIS) return vec4(0.16, 0.35, 1.00, 1.00);
    if (c == CAT_GEM_AMETHYST) return vec4(0.70, 0.36, 1.00, 1.00);
    if (c == CAT_GEM_REDSTONE) return vec4(1.00, 0.10, 0.05, 1.00);
    if (c == CAT_ORE_DIAMOND) return vec4(0.30, 0.85, 1.00, 1.00);
    if (c == CAT_ORE_EMERALD) return vec4(0.20, 1.00, 0.42, 1.00);
    if (c == CAT_ORE_REDSTONE) return vec4(1.00, 0.08, 0.04, 1.00);
    if (c == CAT_ORE_LAPIS) return vec4(0.18, 0.35, 1.00, 1.00);
    if (c == CAT_ORE_GOLD) return vec4(1.00, 0.78, 0.25, 1.00);
    return vec4(1.00, 0.72, 0.48, 1.00);
}

// Strength set per kind of light on the Light Sources page.
float lightTypeStrength(int c) {
    c = glowAlias(c);
    if (c == CAT_TORCH) return LIGHT_TORCH;
    if (c == CAT_LANTERN || c == CAT_LANTERN_HANGING) return LIGHT_LANTERN;
    if (c == CAT_CANDLE || c == CAT_DIM_WARM) return LIGHT_CANDLE;
    if (c == CAT_FIRE || c == CAT_CAMPFIRE || c == CAT_CREAKING || c == CAT_TRIAL) return LIGHT_FIRE;
    if (c == CAT_FURNACE || c == CAT_JACK_O_LANTERN) return LIGHT_FURNACE;
    if (c == CAT_SOUL || c == CAT_SOUL_FIRE || c == CAT_SOUL_LANTERN_HANGING || c == CAT_SOUL_CAMPFIRE) return LIGHT_SOUL;
    if (c == CAT_SEA_LANTERN) return LIGHT_SEA_LANTERN;
    if (c == CAT_GLOWSTONE) return LIGHT_GLOWSTONE;
    if (c == CAT_SHROOMLIGHT) return LIGHT_SHROOMLIGHT;
    if (c == CAT_REDSTONE_LAMP) return LIGHT_REDSTONE_LAMP;
    if (c == CAT_FROGLIGHT_OCHRE || c == CAT_FROGLIGHT_VERDANT || c == CAT_PINK) return LIGHT_FROGLIGHT;
    if (c == CAT_END_ROD || c == CAT_BEACON) return LIGHT_END_ROD;
    if (c == CAT_REDSTONE) return LIGHT_REDSTONE;
    if (c == CAT_COPPER_TORCH || c == CAT_COPPER_LANTERN_HANGING || c == CAT_COPPER_BULB) return LIGHT_COPPER;
    if (c == CAT_LAVA) return LIGHT_LAVA;
    if (c == CAT_MAGMA) return LIGHT_MAGMA;
    if (c == CAT_PURPLE || c == CAT_PORTAL || c == CAT_END_PORTAL) return LIGHT_AMETHYST;
    if (c == CAT_CRYING) return LIGHT_CRYING;
    if (c == CAT_GREEN_GLOW || c == CAT_SCULK) return LIGHT_NATURE;
    if (c >= CAT_GEM_EMERALD && c <= CAT_GEM_REDSTONE) return 1.0;   // Gem Glow Strength handles these
    if (isOre(c)) return LIGHT_ORES;
    return LIGHT_OTHER;
}

// Default block-light colour when the light spread volume has no data.
vec3 defaultBlockLightColor() {
    vec3 warm = vec3(1.00, 0.56, 0.26);
    vec3 neutral = vec3(1.00, 0.82, 0.66);
    return mix(neutral, warm, saturate(BLOCKLIGHT_WARMTH));
}

// Vanilla light level (0..1) to light intensity: bright near the source, quick falloff.
float blockLightCurve(float x) {
    x = saturate(x);
    // Bright next to the light with a long, soft reach; kept below the point where
    // light colours burn out to white once exposure opens up at night.
    return (pow(x, 2.4) * 0.6 + pow(x, 1.2) * 0.05) * BLOCKLIGHT_BRIGHTNESS;
}

// How much of a texel glows. level = vanilla light level / 15.
float emissionMask(int c, vec3 albedo, float level) {
    c = glowAlias(c);
    float mx = maxOf(albedo);
    float bright = smoothstep(0.52, 0.92, mx);
    if (c == CAT_SEA_LANTERN || c == CAT_LIGHT_BLOCK || c == CAT_LAVA || c == CAT_PORTAL || c == CAT_BEACON)
        return 0.35 + 0.65 * smoothstep(0.25, 0.8, mx);
    // Glowstone, shroomlight, lamps and froglights: the bright parts glow, the darker
    // texture still shows, so the block is not a flat blown-out square.
    if (c == CAT_GLOWSTONE || c == CAT_SHROOMLIGHT || c == CAT_REDSTONE_LAMP || c == CAT_PINK ||
        c == CAT_FROGLIGHT_OCHRE || c == CAT_FROGLIGHT_VERDANT)
        return 0.18 + 0.52 * smoothstep(0.35, 0.9, mx);
    if (c == CAT_MAGMA || c == CAT_PURPLE || c == CAT_SCULK || c == CAT_CRYING)
        return smoothstep(0.35, 0.8, mx);
    if (c == CAT_END_ROD) return smoothstep(0.6, 0.95, mx);
    if (c == CAT_REDSTONE) return smoothstep(0.45, 0.8, albedo.r - albedo.g * 0.5);
    if (c == CAT_GREEN_GLOW) return smoothstep(0.45, 0.85, mx);
    if (isGem(c)) return 0.0;
    if (isEmitterCat(c) || level > 0.0) return bright * (level > 0.0 ? 0.5 + 0.5 * level : 1.0);
    return 0.0;
}

// How much a texel looks like an ore's gem rather than its rock: saturated and bright.
float oreSpeck(vec3 c) {
    return smoothstep(0.12, 0.35, maxOf(c) - minOf(c)) * smoothstep(0.25, 0.55, maxOf(c));
}

// The glow of a block's own texture, placed or held: light blocks, gem blocks
// (Gem Glow) and the specks of ores (Glowing Ores).
float blockGlow(int c, vec3 albedo, float level) {
    float e = emissionMask(c, albedo, level);
    #if GEM_GLOW == 1
        // An even inner glow that keeps the texture readable.
        if (isGem(c)) e = max(e, GEM_GLOW_STRENGTH * (0.10 + 0.16 * smoothstep(0.3, 0.9, maxOf(albedo))));
    #endif
    #if ORE_GLOW == 1
        if (isOre(c)) e = max(e, ORE_GLOW_STRENGTH * 0.42 * oreSpeck(albedo));
    #endif
    return e;
}

// Category of a held item (item.properties uses the block ids), or -1.
int heldItemCat(int itemId) {
    if (itemId < 1000) return -1;
    int c = catFromId(float(itemId));
    // Lamps, furnaces and similar are unlit as items: no glow in the hand.
    if (c == CAT_REDSTONE_LAMP || c == CAT_FURNACE) return -1;
    return c;
}

// 1 = soaks up water and darkens a lot, 0 = sheds it and turns glossy.
float porosity(int c) {
    if (c == CAT_SAND) return 0.9;
    if (c == CAT_DIRT) return 0.8;
    if (c == CAT_WOOL || c == CAT_CARPET) return 1.0;
    if (c == CAT_WOOD) return 0.45;
    if (c == CAT_STONE_ROUGH) return 0.3;
    if (c == CAT_STONE_SMOOTH || c == CAT_METAL || isGlass(c) || c == CAT_ICE) return 0.05;
    if (c == CAT_SNOW) return 0.0;
    if (c == CAT_GLAZED) return 0.05;
    if (c == CAT_CONCRETE) return 0.15;
    if (c == CAT_TERRACOTTA) return 0.3;
    if (isFoliage(c)) return 0.15;
    return 0.35;
}
// How shiny a block is when the resource pack gives no specular map (Default Shine).
// Smooth, hard surfaces catch the sun; rough ones only at grazing angles.
float defaultShine(int c) {
    if (c == CAT_GLAZED) return 0.82;
    if (c == CAT_STONE_SMOOTH) return 0.62;
    if (c == CAT_CONCRETE) return 0.5;
    if (c == CAT_TERRACOTTA) return 0.42;
    if (c == CAT_METAL) return 0.7;
    if (c == CAT_ICE) return 0.92;
    if (c == CAT_WOOD) return 0.3;
    if (c == CAT_STONE_ROUGH) return 0.22;
    if (c == CAT_DEFAULT) return 0.18;
    return 0.0;
}
bool allowsPuddles(int c) {
    return !(isFoliage(c) || c == CAT_SNOW || c == CAT_WOOL || c == CAT_CARPET || c >= CAT_ENTITY || isEmitterCat(c) || c == CAT_SAND);
}

#endif
