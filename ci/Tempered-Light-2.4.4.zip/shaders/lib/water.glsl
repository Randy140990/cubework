/*
    Tempered Light - water waves (follow the wind), colour and caustics.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_WATER
#define LF_WATER

#if WATER_WAVE_DETAIL == 0
    #define WAVE_OCTAVES 4
#elif WATER_WAVE_DETAIL == 1
    #define WAVE_OCTAVES 6
#else
    #define WAVE_OCTAVES 8
#endif

// The water's own clock: waves, streams and waterfalls all move at a calm,
// natural pace that Water Speed scales.
float waterClock() {
    return frameTimeCounter * 0.4 * WATER_SPEED;
}

// Long, slow swell (blocks). The water surface itself is moved by this in the
// vertex shader, so waves have real height; Wave Height scales it.
float waterSwell(vec2 p, float t) {
    vec2 wd = windDirection();
    vec2 wd2 = rot2(0.6) * wd;
    float ws = 0.6 + 0.5 * windStrength();
    float s = sin(dot(p, wd) * 0.34 - t * 1.05) + 0.6 * sin(dot(p, wd2) * 0.53 - t * 1.37 + 1.7)
            + 0.3 * sin(dot(p, rot2(-0.9) * wd) * 0.81 - t * 1.8 + 4.1);
    return s * 0.045 * WAVE_HEIGHT * ws;
}

// Height of the water surface (blocks) at xz.
float waterHeight(vec2 p, float t, int octaves) {
    vec2 wd = windDirection();
    float ws = windStrength();
    // Calm and choppy patches drift across the surface.
    float calm = smoothstep(0.25, 0.8, vnoise(p * 0.018 + wd * t * 0.03));
    float amp = mix(0.4, 1.0, calm) * WATER_WAVES * (0.65 + 0.45 * ws);
    float h = 0.0;
    float a = 0.055, k = 0.45, ang = 0.0;
    for (int i = 0; i < 8; i++) {
        if (i >= octaves) break;
        vec2 d = rot2(ang) * wd;
        float warp = vnoise(p * k * 0.4 + float(i) * 3.17) * 2.4;
        float ph = dot(p, d) * k - t * sqrt(9.81 * k) * 0.55 + warp;
        h += a * exp(sin(ph) - 1.0);
        a *= 0.6;
        k *= 1.72;
        ang += (i % 2 == 0) ? 1.05 : -1.75;
    }
    return h * amp * (0.75 + 0.25 * WAVE_HEIGHT) + waterSwell(p, t);
}

// World-space normal of the water surface. dist: distance from the camera.
vec3 waterNormal(vec3 worldPos, float dist) {
    float t = waterClock();
    float e = 0.05 + dist * 0.0012;
    int oct = dist > 96.0 ? max(WAVE_OCTAVES - 2, 3) : WAVE_OCTAVES;
    vec2 p = worldPos.xz;
    float hx = waterHeight(p + vec2(e, 0.0), t, oct) - waterHeight(p - vec2(e, 0.0), t, oct);
    float hz = waterHeight(p + vec2(0.0, e), t, oct) - waterHeight(p - vec2(0.0, e), t, oct);
    vec3 n = normalize(vec3(-hx / (2.0 * e), 1.0, -hz / (2.0 * e)));
    // Ease off far away to limit shimmer, but keep the waves readable from high up.
    float keep = exp(-dist / 260.0);
    return normalize(mix(vec3(0.0, 1.0, 0.0), n, 0.5 + 0.5 * keep));
}

// Per-block absorption and scattering of the water body.
vec3 waterAbsorption() {
    #if WATER_MODE == 2
        return vec3(0.20, 0.045, 0.028);
    #elif WATER_MODE == 3
        return vec3(0.30, 0.060, 0.050);
    #else
        return vec3(0.42, 0.105, 0.065);
    #endif
}
vec3 waterScatter() {
    #if WATER_MODE == 2
        return vec3(0.004, 0.016, 0.022);
    #elif WATER_MODE == 3
        return vec3(0.010, 0.060, 0.062);
    #else
        return vec3(0.012, 0.040, 0.055);
    #endif
}

// Bright web of focused light on the sea bed.
float causticLayer(vec2 p, float t) {
    vec2 q = p + vec2(vnoise(p * 0.8 + t * 0.35), vnoise(p * 0.8 - t * 0.3 + 4.7)) * 1.7;
    float v = vnoise(q * 1.6 + t * 0.15);
    return pow(1.0 - abs(v * 2.0 - 1.0), 6.0);
}
float caustics(vec3 worldPos) {
    #if CAUSTICS == 1
        float t = frameTimeCounter * 0.5 * WATER_SPEED;
        vec2 p = worldPos.xz + windDirection() * t * 0.2;
        float c = causticLayer(p * 0.9, t) + causticLayer(p * 1.31 + 11.0, t * 1.17);
        return 0.35 + c * 1.6;
    #else
        return 1.0;
    #endif
}

// ------------------------------------------------------------ your wake ---
// Ripples you make in the water: rings spreading round you as you tread water, and
// as you swim (or row) a V-shaped wake trailing behind and a small bow wave ahead.
// r: from you to the point, v: your velocity (blocks per second).
float wakeHeight(vec2 r, vec2 v, float t) {
    float speed = length(v);
    float d = length(r);
    float h = sin(d * 6.5 - t * 5.0) * exp(-d * 0.6) * smoothstep(0.1, 0.6, d) * (0.25 + 0.5 * smoothstep(0.0, 1.5, speed));
    if (speed > 0.2) {
        vec2 dir = v / speed;
        float along = -dot(r, dir);                      // behind you is positive
        float across = abs(dot(r, vec2(-dir.y, dir.x)));
        float k = smoothstep(0.2, 3.0, speed);
        float a = max(along, 0.0);
        float arm = across - a * 0.36;                   // 0 on the wake's two arms (about 20 degrees out)
        float arms = exp(-arm * arm * 2.5) * sin(a * 4.2 + across * 2.0 - t * 6.0);
        float trans = (1.0 - smoothstep(-0.3, 0.2, arm)) * sin(a * 3.2 - t * 4.5) * 0.45;
        h += (arms + trans) * exp(-a / (2.5 + 1.5 * speed)) * k * step(-0.5, along);
        vec2 b = r - dir * 0.45;
        h += exp(-dot(b, b) * 3.5) * 0.7 * k;            // water pushed up in front of you
    }
    return h;
}
vec3 applyPlayerWake(vec3 wn, vec3 worldPos) {
    #if PLAYER_WAKE == 1
        vec3 eye = cameraPosition - relativeEyePosition;
        vec2 r = worldPos.xz - eye.xz;
        if (dot(r, r) > 196.0) return wn;
        // Only while you are in the water at its surface: from your feet just under
        // it to your eyes just above it.
        float rel = eye.y - worldPos.y;
        float inWater = smoothstep(-0.5, 0.05, rel) * (1.0 - smoothstep(1.75, 2.3, rel));
        if (inWater <= 0.0) return wn;
        vec2 v = vec2(lfVelX, lfVelZ);
        float t = frameTimeCounter;
        const float e = 0.05;
        float h0 = wakeHeight(r, v, t);
        vec2 g = vec2(wakeHeight(r + vec2(e, 0.0), v, t) - h0, wakeHeight(r + vec2(0.0, e), v, t) - h0) / e;
        return normalize(wn - vec3(g.x, 0.0, g.y) * 0.2 * inWater);
    #else
        return wn;
    #endif
}

#endif
