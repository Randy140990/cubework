/*
    Tempered Light - clouds and their shadows: Blocky, Volumetric (separate soft
    cumulus you can fly through) and Realistic (wide cloud decks with wispy edges).
    Positions are world space (blocks). Results: rgb = in-scattered light, a = transmittance.

    Blocky clouds come in up to three stacked layers. Within a layer, each cloud
    (a cluster of cells) sits at its own base height, so the bottoms vary like
    real clouds. Cells fade in and out rather than popping, and the weather
    values used here are eased over tens of seconds, so clouds gather and clear
    gradually.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_CLOUDS
#define LF_CLOUDS

// Lightning inside the clouds for this pixel's clouds (set by renderClouds or the
// Nether roof sky): xyz where, w how bright; and its colour.
vec4 gCloudFlash = vec4(0.0);
vec3 gCloudFlashCol = vec3(0.70, 0.78, 1.0);
vec3 cloudFlashGlow(vec3 p, float radius) {
    if (gCloudFlash.w <= 0.0) return vec3(0.0);
    vec3 d = p - gCloudFlash.xyz;
    // (A quarter brighter than the flash on the world below: the cloud it fires in glows hardest.)
    return gCloudFlashCol * gCloudFlash.w * 1.25 * exp(-length(d * vec3(1.0, 1.6, 1.0)) / (radius * 1.08));
}

#define REAL_Y0 float(REALISTIC_CLOUD_ALTITUDE)
#define REAL_Y1 float(REALISTIC_CLOUD_ALTITUDE + 360)

// Share of the sky covered (0 = clear). Rain bunches clouds together and fills in
// the upper layers; it does not turn every layer solid.
float cloudCoverage() {
    #ifdef DIM_NETHER
        // The clouds over the Nether roof have their own amount (Nether & End page).
        return saturate(0.55 * NETHER_CLOUD_AMOUNT);
    #else
        return saturate(0.55 * CLOUD_COVERAGE + 0.42 * lfRain + 0.12 * lfThunder);
    #endif
}

// Clouds drift along the chosen wind heading at a steady speed. (Scaling the
// clock by weather would teleport the whole field when rain starts or stops.)
vec2 cloudOffset() {
    float a = radians(float(WIND_DIRECTION));
    // Clouds are looked up at (position + offset), so the offset runs against the
    // wind for the clouds themselves to travel with it, like the plants and waves.
    return -vec2(cos(a), sin(a)) * frameTimeCounter * 2.2 * CLOUD_SPEED;
}

float cloudPhase(float mu) {
    return mix(phaseHG(mu, 0.62), phaseHG(mu, -0.25), 0.3);
}

// ---------------------------------------------------------------- blocky ---
struct BlockyLayer {
    float y0;       // lowest possible base
    float var;      // how much cloud bases vary
    float thick;    // typical thickness
    float size;     // cell size (blocks)
    float cov;      // coverage 0..1
    vec2 off;       // drift offset
    float seed;
};

BlockyLayer blockyLayer(int i) {
    BlockyLayer L;
    float fi = float(i);
    L.y0 = float(BLOCKY_CLOUD_ALTITUDE) + fi * (34.0 + float(CLOUD_HEIGHT_VARIATION));
    L.var = float(CLOUD_HEIGHT_VARIATION) * (1.0 - 0.3 * fi);
    L.thick = float(BLOCKY_CLOUD_THICKNESS) * (1.0 - 0.22 * fi);
    L.size = float(BLOCKY_CLOUD_SIZE) * (1.0 + 0.5 * fi);
    float c = cloudCoverage();
    // Higher layers are sparser in fair weather and fill in when it rains.
    L.cov = i == 0 ? c : saturate(c * (0.9 - 0.12 * fi) + lfRain * (0.25 + 0.1 * fi));
    L.off = cloudOffset() * (1.0 + 0.35 * fi) + vec2(fi * 517.0, fi * 311.0);
    L.seed = fi * 37.7;
    return L;
}

// The broad shape of the clouds: smooth, so every cloud is one whole piece.
float blockyBigNoise(vec2 cell, float seed) {
    vec2 c = cell + seed;
    float n = vnoise(c * 0.11) * 0.62 + vnoise(c * 0.23 + 3.1) * 0.16 + 0.11;
    n += (vnoise(c * 0.03 + 31.0) - 0.5) * 0.42;
    #if CLOUD_EVOLVE == 1
        // Clouds slowly change shape: they grow and melt away over a few minutes.
        n += (vnoise3(vec3(c * 0.08, frameTimeCounter * 0.006 * CLOUD_SPEED + seed)) - 0.5) * 0.22;
    #endif
    return n;
}
// Edges are bitten into a little for a ragged outline, but nothing is added, so no
// stray single squares float beside a cloud.
float blockyCellNoise(vec2 cell, float seed) {
    return blockyBigNoise(cell, seed) - vnoise((cell + seed) * 0.37 + 7.3) * 0.09;
}
// Threshold for a coverage: no clouds at all at 0.
float blockyThreshold(float cov) {
    // (Never quite solid: even in a storm a few gaps let the sun through.)
    return cov <= 0.001 ? 2.0 : mix(0.86, 0.22, min(cov, 0.8));
}
// 0..1: cells near the threshold are thin, so changes in coverage fade them in.
float blockyWeight(vec2 cell, BlockyLayer L, float thr) {
    return smoothstep(thr, thr + 0.02, blockyCellNoise(cell, L.seed));
}
// The highest a cloud top can reach above its base (thickest cloud, both heaps).
float blockyMaxRise(BlockyLayer L) { return L.thick * 1.3 * (1.0 + 1.4 * BLOCKY_CLOUD_TOWERS) + 2.0; }
float blockyMaxSag(BlockyLayer L) { return 0.0; }
// A cell's cloud: returns how solid it is (0..1) and, in r, its bottom and top.
// Each cloud is one whole slab: one flat base and one thickness shared by the whole
// cloud (they change only over hundreds of blocks, so neighbouring clouds differ).
// Bigger clouds heap up in the middle, in at most two broad steps, never cell by cell.
float blockyCellCloud(vec2 cell, BlockyLayer L, float thr, out vec2 r) {
    float n = blockyCellNoise(cell, L.seed);
    float w = smoothstep(thr, thr + 0.02, n);
    r = vec2(0.0);
    if (w <= 0.0) return 0.0;
    vec2 c = cell + L.seed;
    float base = L.y0 + floor(saturate(vnoise(c * 0.018 + 91.0) * 1.2 - 0.1) * 3.0 + 0.5) / 3.0 * L.var;
    float th = max(floor(L.thick * (0.8 + 0.5 * vnoise(c * 0.025 + 17.0)) + 0.5), 3.0);
    // How far into its cloud this cell is, from the smooth shape alone.
    float core = saturate((blockyBigNoise(cell, L.seed) - thr) / 0.16);
    float step1 = floor(th * 0.7 * BLOCKY_CLOUD_TOWERS + 0.5);
    float rise = step(0.35, core) * step1 + step(0.7, core) * step(0.99, BLOCKY_CLOUD_TOWERS) * step1;
    r = vec2(base, base + th + rise);
    return w;
}
vec2 blockyCell(vec2 xz, BlockyLayer L) {
    return floor((xz + L.off) / L.size);
}
float blockyDensityAt(vec3 p, BlockyLayer L, float thr) {
    vec2 r;
    float w = blockyCellCloud(blockyCell(p.xz, L), L, thr, r);
    return (w > 0.0 && p.y >= r.x && p.y <= r.y) ? w : 0.0;
}

// Exact traversal of one layer's grid: crisp block edges, no noise.
// Returns rgb scatter, a transmittance; tFirst = distance where the layer starts.
vec4 blockyLayerMarch(int li, vec3 ro, vec3 rd, float maxDist, vec3 lightDir, vec3 lightE, vec3 ambTop, vec3 ambBottom, int maxCells, out float tFirst) {
    BlockyLayer L = blockyLayer(li);
    tFirst = 1e9;
    float thr = blockyThreshold(L.cov);
    if (thr > 1.5) return vec4(0.0, 0.0, 0.0, 1.0);
    float y0 = L.y0 - blockyMaxSag(L) - 1.0, y1 = L.y0 + L.var + blockyMaxRise(L) + 1.0;
    float tEnter, tExit;
    if (abs(rd.y) < 1e-5) {
        if (ro.y < y0 || ro.y > y1) return vec4(0.0, 0.0, 0.0, 1.0);
        tEnter = 0.0; tExit = 1e5;
    } else {
        float ta = (y0 - ro.y) / rd.y, tb = (y1 - ro.y) / rd.y;
        tEnter = max(min(ta, tb), 0.0);
        tExit = max(ta, tb);
    }
    tExit = min(tExit, min(maxDist, 4000.0));
    if (tEnter >= tExit) return vec4(0.0, 0.0, 0.0, 1.0);
    tFirst = tEnter;

    // Dense enough that each cloud has solid, lit and shaded faces.
    float sigma = (0.34 + 0.28 * lfRain) * (li == 0 ? 1.0 : 0.8);
    vec2 q = (ro.xz + rd.xz * tEnter + L.off) / L.size;
    vec2 cell = floor(q);
    vec2 dxz = rd.xz / L.size;
    vec2 stepDir = vec2(dxz.x >= 0.0 ? 1.0 : -1.0, dxz.y >= 0.0 ? 1.0 : -1.0);
    vec2 invD = 1.0 / max(abs(dxz), vec2(1e-6));
    vec2 tNextXZ = tEnter + (stepDir * (cell - q) + max(stepDir, 0.0)) * invD;

    float mu = dot(rd, lightDir);
    float phase = cloudPhase(mu);
    // Layers above this one shade it.
    float upperShade = 1.0;
    #if CLOUD_LAYERS > 1
        for (int u = li + 1; u < CLOUD_LAYERS; u++) {
            BlockyLayer U = blockyLayer(u);
            float tu = blockyThreshold(U.cov);
            if (tu > 1.5 || lightDir.y < 0.05) continue;
            vec3 pu = ro + rd * tEnter;
            pu += lightDir * ((U.y0 + U.thick - pu.y) / max(lightDir.y, 0.05));
            upperShade *= 1.0 - 0.55 * blockyWeight(blockyCell(pu.xz, U), U, tu);
        }
    #endif
    int lightSteps = li == 0 ? 4 : 2;
    // A ray that runs nearly level through the layer (you are at the clouds' height)
    // crosses many more cells than one that cuts through it: give it up to three times
    // the usual budget so clouds of your own layer don't vanish a few hundred blocks out.
    float cellsOnPath = (tExit - tEnter) * (abs(dxz.x) + abs(dxz.y)) + 2.0;
    int budget = int(clamp(cellsOnPath, float(maxCells), float(maxCells) * 3.0));
    vec3 scatter = vec3(0.0);
    float T = 1.0;
    float t = tEnter;
    float tHit = -1.0;
    for (int i = 0; i < 288; i++) {
        if (i >= budget) break;
        float tn = min(min(tNextXZ.x, tNextXZ.y), tExit);
        vec2 r = vec2(0.0);
        float w = tn > t ? blockyCellCloud(cell, L, thr, r) : 0.0;
        if (w > 0.0) {
            // Where the ray is inside this cell's cloud (its own base and top).
            float lo = t, hi = tn;
            if (abs(rd.y) > 1e-5) {
                float ta = (r.x - ro.y) / rd.y, tb = (r.y - ro.y) / rd.y;
                lo = max(lo, min(ta, tb)); hi = min(hi, max(ta, tb));
            } else if (ro.y < r.x || ro.y > r.y) {
                hi = lo;
            }
            float seg = hi - lo;
            if (seg > 0.0) {
                int sub = int(clamp(ceil(seg / 1.5), 1.0, li == 0 ? 4.0 : 2.0));
                float ss = seg / float(sub);
                float a = 1.0 - exp(-sigma * w * ss);
                if (tHit < 0.0) tHit = lo;
                for (int j = 0; j < 4; j++) {
                    if (j >= sub) break;
                    vec3 pm = ro + rd * (lo + ss * (float(j) + 0.5));
                    float hFrac = saturate((pm.y - r.x) / max(r.y - r.x, 1.0));
                    // Height in the cloud as a whole: bellies dark, heaped tops bright.
                    float hAbs = saturate((pm.y - (L.y0 - blockyMaxSag(L))) / (blockyMaxSag(L) + L.thick * 2.5));
                    // Walk towards the light: from the top when the sun is high,
                    // through the side of the cloud when it is low.
                    float dExit = lightDir.y > 1e-3 ? (r.y - pm.y) / lightDir.y : 60.0;
                    dExit = min(dExit, 60.0);
                    float odLight = 0.0, prevD = 0.0;
                    for (int k = 0; k < 4; k++) {
                        if (k >= lightSteps) break;
                        float dk = min(k == 0 ? 1.5 : (k == 1 ? 4.0 : (k == 2 ? 9.0 : 18.0)), dExit);
                        vec3 pl = pm + lightDir * ((prevD + dk) * 0.5);
                        odLight += sigma * (dk - prevD) * blockyDensityAt(pl, L, thr);
                        prevD = dk;
                        if (prevD >= dExit) break;
                    }
                    odLight += sigma * max(dExit - prevD, 0.0) * 0.5;
                    float Tl = (exp(-odLight) + 0.12 * exp(-odLight * 0.3)) * upperShade;
                    // Sky light: the open sky above lights the tops, the dim ground below
                    // the bellies; deep inside, little of either gets in.
                    float hMix = saturate(0.5 * hFrac + 0.5 * hAbs);
                    vec3 amb = mix(ambBottom * 0.8, ambTop * 1.1, hMix * hMix);
                    // Light bounced through the cloud keeps shaded sides from going flat grey.
                    float multi = exp(-odLight * 0.15) * 0.10;
                    vec3 S = (lightE * (Tl * phase * 1.3 + multi) + amb * (0.5 + 0.7 * hMix)) * 0.95;
                    S *= mix(vec3(1.0), vec3(0.68, 0.72, 0.80), saturate(skyRain() * 0.9 + lfThunder * 0.3));
                    S += cloudFlashGlow(pm, 90.0) * 1.0;
                    scatter += T * S * a;
                    T *= 1.0 - a;
                }
                if (T < 0.02) break;
            }
        }
        if (tn >= tExit) break;
        if (tNextXZ.x < tNextXZ.y) { cell.x += stepDir.x; tNextXZ.x += invD.x; }
        else { cell.y += stepDir.y; tNextXZ.y += invD.y; }
        t = tn;
    }
    // Far clouds sink into the haze (by how far the cloud itself is, so a cloud at
    // your own height fades with distance just as one seen from below does).
    float fade = exp(-max((tHit < 0.0 ? tEnter : tHit) - 400.0, 0.0) / 2200.0);
    return vec4(scatter * fade, mix(1.0, T, fade));
}

// Front-to-back over the stacked layers (nearest first).
vec4 blockyClouds(vec3 ro, vec3 rd, float maxDist, vec3 lightDir, vec3 lightE, vec3 ambTop, vec3 ambBottom, int maxCells) {
    vec4 res[3];
    float tf[3];
    for (int i = 0; i < 3; i++) {
        res[i] = vec4(0.0, 0.0, 0.0, 1.0); tf[i] = 1e9;
        if (i < CLOUD_LAYERS) res[i] = blockyLayerMarch(i, ro, rd, maxDist, lightDir, lightE, ambTop, ambBottom, i == 0 ? maxCells : maxCells * 2 / 3, tf[i]);
    }
    // Tiny sort by distance.
    for (int a = 0; a < 2; a++) for (int b = 0; b < 2 - a; b++) {
        if (tf[b] > tf[b + 1]) { vec4 r = res[b]; res[b] = res[b + 1]; res[b + 1] = r; float t = tf[b]; tf[b] = tf[b + 1]; tf[b + 1] = t; }
    }
    vec3 S = res[0].rgb + res[0].a * (res[1].rgb + res[1].a * res[2].rgb);
    return vec4(S, res[0].a * res[1].a * res[2].a);
}

// ------------------------------------------------------------- realistic ---
// Fair-weather cumulus: separate clouds a few hundred blocks across, gathered by a
// slow large-scale "weather" pattern. Flat bases at slightly different heights,
// tall cauliflower tops where clouds are densest, towering in rain.
float realCoverageAt(vec2 xz) {
    float cov = cloudCoverage();
    if (cov <= 0.001) return 0.0;
    vec2 o = cloudOffset() * 3.0;
    float weather = fbm2((xz + o * 0.7) * 0.00032 + 3.7, 3);
    float cells = fbm2((xz + o) * 0.0024 + 17.0, 4);
    #if CLOUD_EVOLVE == 1
        // Slowly building and fading: each cloud grows, changes shape and melts away.
        cells += (vnoise3(vec3((xz + o) * 0.0042, frameTimeCounter * 0.004 * CLOUD_SPEED)) - 0.5) * 0.3;
    #endif
    float base = cells * 0.78 + weather * 0.42 - 0.12;
    cov = min(cov, 0.72);   // a few gaps even in a storm, for the sun to break through
    return smoothstep(0.80 - cov * 0.8, 0.96 - cov * 0.7, base);
}
// Height of this cloud's base above the layer bottom (0..1 of the layer).
float realBaseAt(vec2 xz) {
    return vnoise((xz + cloudOffset() * 3.0) * 0.0009 + 5.3) * 0.12;
}
float realDensity(vec3 p, float detail) {
    float h = (p.y - REAL_Y0) / (REAL_Y1 - REAL_Y0);
    if (h <= 0.0 || h >= 1.0) return 0.0;
    float c = realCoverageAt(p.xz);
    if (c <= 0.0) return 0.0;
    float b = realBaseAt(p.xz);
    // Denser clouds grow taller; rain builds towers.
    // sqrt: steep sides and a rounded dome rather than a cone.
    float top = b + (0.18 + 0.72 * sqrt(c)) * (0.7 + 0.3 * lfRain);
    float shape = smoothstep(b, b + 0.05, h) * smoothstep(top, mix(b, top, 0.7), h);
    float d = c * shape;
    if (detail > 0.0 && d > 0.0) {
        // Billowing detail eats into the edges, more towards the rounded tops.
        vec3 q = p * 0.011 + vec3(cloudOffset().x, frameTimeCounter * 0.25, cloudOffset().y) * 0.006;
        float n1 = vnoise3(q);
        float n2 = vnoise3(q * 2.8 + 3.1);
        float n3 = vnoise3(q * 7.3 + 9.7);
        float billow = (1.0 - abs(n1 * 2.0 - 1.0)) * 0.55 + n2 * 0.3 + n3 * 0.15;
        float erode = (0.35 + 0.45 * saturate((h - b) / max(top - b, 0.05))) * detail;
        d = saturate((d - billow * erode * (1.15 - d)) * 1.6);
    }
    return d;
}

// ---------------------------------------------------- realistic (decks) ---
// Wide cloud decks: broad banks and sheets of cloud that spread across much of the
// sky, broken by lanes and holes, with soft rounded tops and wisps combed out along
// the wind at their edges. Lower and flatter than the separate cumulus.
#define DECK_Y0 float(REALISTIC_CLOUD_ALTITUDE - 90)
#define DECK_Y1 float(REALISTIC_CLOUD_ALTITUDE + 460)

vec2 deckWindDir() {
    float a = radians(float(WIND_DIRECTION));
    return vec2(cos(a), sin(a));
}
// Position in the deck's own frame: drifting with the wind, along-wind first.
vec2 deckFrame(vec2 xz) {
    vec2 p = xz + cloudOffset() * 3.0;
    vec2 wd = deckWindDir();
    return vec2(dot(p, wd), dot(p, vec2(-wd.y, wd.x)));
}
float deckCoverageAt(vec2 xz) {
    float cov = cloudCoverage();
    if (cov <= 0.001) return 0.0;
    vec2 p = deckFrame(xz);
    p.x *= 0.75;                                  // clouds run out a little along the wind
    // Big, slow weather: some stretches of sky are fuller than others.
    float weather = vnoise(p * 0.00035 + 5.1);
    // A warp bends the field into lanes and swirls instead of round blobs.
    vec2 w = vec2(vnoise(p * 0.0011 + 1.3), vnoise(p * 0.0011 + 8.1)) - 0.5;
    p += w * 420.0;
    // Clouds of every size, from banks a few hundred blocks across to small puffs.
    float n = fbm2(p * 0.0034 + 3.7, 5);
    #if CLOUD_EVOLVE == 1
        // Slowly building and thinning.
        n += (vnoise3(vec3(p * 0.006, frameTimeCounter * 0.004 * CLOUD_SPEED)) - 0.5) * 0.12;
    #endif
    // At the same Cloud Amount a deck covers more of the sky than separate clouds.
    // (Capped so even a storm deck keeps a few breaks for the sun to pierce.)
    float thr = mix(0.62, 0.30, min(cov * 1.3, 0.85)) + (0.5 - weather) * 0.16;
    return smoothstep(thr, thr + 0.16, n);
}
float deckDensity(vec3 p, float detail) {
    if (p.y <= DECK_Y0 || p.y >= DECK_Y1) return 0.0;
    float c = deckCoverageAt(p.xz);
    if (c <= 0.0) return 0.0;
    vec2 f = deckFrame(p.xz);
    // Not one flat sheet: whole banks sit higher or lower than their neighbours, and
    // rain brings the bases down. Bases are flat-ish, with a few lumps.
    float alt = float(REALISTIC_CLOUD_ALTITUDE);
    float base = alt - 25.0 + (vnoise(f * 0.0011 + 2.7) - 0.5) * 70.0 + (vnoise(f * 0.004 + 9.3) - 0.5) * 20.0 - 30.0 * lfRain;
    // Thin at the edges of a bank and thick in its heart; here and there the heart
    // heaps up into a tower, taller and more often in rain and thunder.
    float thick = 25.0 + 95.0 * pow(c, 0.8);
    float tower = smoothstep(0.55, 0.85, vnoise(f * 0.0035 + 5.1)) * c * c * (90.0 + 160.0 * lfRain + 60.0 * lfThunder);
    float top = base + thick + tower;
    float shape = smoothstep(base, base + 10.0, p.y) * smoothstep(top, base + (top - base) * 0.4, p.y);
    float d = c * shape;
    float h = (p.y - base) / max(top - base, 1.0);
    if (detail > 0.0 && d > 0.0) {
        // Billows: rounded puffs eating into the tops and sides...
        vec3 q = vec3(f.x, p.y, f.y) * 0.018 + vec3(0.0, frameTimeCounter * 0.002, 0.0);
        float n1 = vnoise3(q);
        float n2 = vnoise3(q * 2.7 + 4.7);
        float n3 = vnoise3(q * 7.1 + 1.9);
        float billow = 1.0 - abs(n1 * 2.0 - 1.0);
        // ...and fine wisps drawn out along the wind, strongest at the edges.
        float wisp = vnoise3(vec3(f.x * 0.012, p.y * 0.06, f.y * 0.07) + 2.3);
        // (Value noise sits mostly near the middle: stretch it to use the full range.)
        float er = saturate((billow * 0.42 + n2 * 0.25 + n3 * 0.13 + wisp * 0.35 - 0.42) * 2.4);
        float hh = saturate(h);
        d = saturate((d - er * detail * (0.7 + 0.4 * hh) * (1.2 - d)) * 2.2);
        // Thicker and thinner patches inside, so the light falls unevenly across it.
        d *= 1.0 - 0.5 * detail * saturate((n2 - 0.3) * 2.5);
    }
    return d;
}

// The layer the volumetric marcher runs through, for whichever style is on.
#if CLOUD_MODE == 5
    #define VOL_Y0 DECK_Y0
    #define VOL_Y1 DECK_Y1
    float volDensity(vec3 p, float detail) { return deckDensity(p, detail); }
#else
    #define VOL_Y0 REAL_Y0
    #define VOL_Y1 REAL_Y1
    float volDensity(vec3 p, float detail) { return realDensity(p, detail); }
#endif

vec4 realisticClouds(vec3 ro, vec3 rd, float maxDist, vec3 lightDir, vec3 lightE, vec3 ambTop, vec3 ambBottom, int steps, float dither) {
    float y0 = VOL_Y0, y1 = VOL_Y1;
    float tEnter, tExit;
    if (abs(rd.y) < 1e-5) {
        if (ro.y < y0 || ro.y > y1) return vec4(0.0, 0.0, 0.0, 1.0);
        tEnter = 0.0; tExit = 6000.0;
    } else {
        float ta = (y0 - ro.y) / rd.y, tb = (y1 - ro.y) / rd.y;
        tEnter = max(min(ta, tb), 0.0);
        tExit = max(ta, tb);
    }
    tExit = min(tExit, min(maxDist, tEnter + 3000.0));
    tExit = min(tExit, 9000.0);
    if (tEnter >= tExit || cloudCoverage() <= 0.001) return vec4(0.0, 0.0, 0.0, 1.0);
    float stepLen = (tExit - tEnter) / float(steps);
    float sigma = 0.05 + 0.05 * lfRain;
    float mu = dot(rd, lightDir);
    vec3 scatter = vec3(0.0);
    float T = 1.0;
    for (int i = 0; i < steps; i++) {
        float t = tEnter + stepLen * (float(i) + dither);
        vec3 p = ro + rd * t;
        float d = volDensity(p, 1.0);
        if (d <= 0.001) continue;
        float od = 0.0;
        #if CLOUD_MODE == 5
            // Decks are thinner and finer: short first steps catch the shade
            // of each billow on the next.
            float ls = 5.0;
            const float lgrow = 2.0;
        #else
            float ls = 14.0;
            const float lgrow = 1.8;
        #endif
        vec3 pl = p;
        for (int k = 0; k < 5; k++) {
            pl += lightDir * ls;
            od += volDensity(pl, k < 2 ? 0.6 : 0.0) * ls;
            ls *= lgrow;
        }
        float h = saturate((p.y - y0) / (y1 - y0));
        // Sky light from above, darker light bounced up from the ground below.
        vec3 amb = mix(ambBottom * 0.8, ambTop * 1.15, smoothstep(0.0, 0.7, h));
        // Multiple scattering (three octaves) with a silver lining towards the sun. The
        // forward glow is kept moderate: a real sun-facing cloud would be blinding, which
        // in Minecraft just washes the sky round the sun out to white.
        vec3 Ls = vec3(0.0);
        float a = 1.0, b = 1.0, c = 1.0;
        for (int o = 0; o < 3; o++) {
            float ph = mix(phaseHG(mu, 0.6 * c), phaseHG(mu, -0.2 * c), 0.25) + 0.06 * phaseHG(mu, 0.85 * c) * c;
            Ls += lightE * a * exp(-sigma * od * b) * ph;
            a *= 0.55; b *= 0.4; c *= 0.5;
        }
        // "Powder": the sunny side of a cloud's interior is darker than its thin edges,
        // which gives the deep creases between billows.
        float powder = 1.0 - exp(-sigma * d * 45.0);
        Ls *= mix(1.0, powder * 1.5, 0.45 * (0.6 - 0.4 * mu));
        vec3 S = Ls * 2.1 + amb * (0.4 + 0.55 * h);
        // Rain clouds turn a heavy blue-grey.
        S *= mix(vec3(1.0), vec3(0.68, 0.72, 0.80), saturate(skyRain() * 0.9 + lfThunder * 0.3));
        // Lit up from inside by lightning.
        S += cloudFlashGlow(p, 120.0) * 1.2;
        float alpha = 1.0 - exp(-sigma * d * stepLen);
        scatter += T * S * alpha;
        T *= 1.0 - alpha;
        if (T < 0.02) break;
    }
    float fade = exp(-max(tEnter - 900.0, 0.0) / 5000.0);
    return vec4(scatter * fade, mix(1.0, T, fade));
}

// A thin high layer (altostratus) above the realistic clouds: fills in with rain.
float highLayerCov() {
    return saturate(cloudCoverage() * 0.6 + lfRain * 0.5 - 0.15);
}
vec4 highCloudLayer(vec3 ro, vec3 rd, vec3 lightDir, vec3 lightE, vec3 ambTop) {
    float alt = VOL_Y1 + 380.0;
    if (abs(rd.y) < 1e-4) return vec4(0.0, 0.0, 0.0, 1.0);
    float t = (alt - ro.y) / rd.y;
    if (t <= 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
    float cov = highLayerCov();
    if (cov <= 0.001) return vec4(0.0, 0.0, 0.0, 1.0);
    vec3 p = ro + rd * t;
    // Wispy cirrus, drawn out along the wind.
    float wa = radians(float(WIND_DIRECTION));
    vec2 wd = vec2(cos(wa), sin(wa));
    vec2 xz = p.xz + cloudOffset() * 4.0;
    vec2 q = vec2(dot(xz, wd) * 0.25, dot(xz, vec2(-wd.y, wd.x))) * 0.0011;
    float n = fbm2(q, 4) * 0.75 + fbm2(q * vec2(1.0, 3.5) + 3.1, 3) * 0.25;
    float d = smoothstep(1.0 - cov, 1.0 - cov + 0.25, n);
    float pathLen = 40.0 / max(abs(rd.y), 0.08);
    float alpha = 1.0 - exp(-0.02 * d * pathLen);
    // Thin ice cloud: lit softly, without a bright forward glare round the sun.
    float muH = dot(rd, lightDir);
    vec3 S = lightE * mix(phaseHG(muH, 0.4), phaseHG(muH, -0.2), 0.3) * 0.7 + ambTop * 0.9;
    float fade = exp(-max(t - 1500.0, 0.0) / 9000.0);
    return vec4(S * alpha * fade, 1.0 - alpha * fade);
}

// A patchy middle layer (altocumulus) between the Realistic decks and the cirrus:
// fields of small rounded cloudlets in loose rows, so the sky shows cloud at several
// heights at once. Thickens in rain.
#define MID_ALT (VOL_Y1 + 120.0)
float midLayerCov() {
    return saturate(cloudCoverage() * 0.75 + lfRain * 0.3 - 0.05);
}
float midLayerDensity(vec2 xz) {
    float cov = midLayerCov();
    if (cov <= 0.001) return 0.0;
    vec2 p = xz + cloudOffset() * 3.5;
    float wa = radians(float(WIND_DIRECTION));
    vec2 wd = vec2(cos(wa), sin(wa));
    vec2 q = vec2(dot(p, wd), dot(p, vec2(-wd.y, wd.x))) * 0.012;
    // Where the fields are...
    float field = fbm2(p * 0.0009 + 7.7, 3);
    // ...and the cloudlets in them, in loose rows across the wind.
    float cells = vnoise(q) * 0.6 + vnoise(q * 2.3 + 1.7) * 0.4;
    float rows = 0.5 + 0.5 * sin(q.x * 3.0 + vnoise(q * 0.5) * 4.0);
    float n = field * 0.55 + cells * 0.3 + rows * 0.15;
    float thr = 1.0 - cov * 0.8;
    return smoothstep(thr, thr + 0.12, n);
}
vec4 midCloudLayer(vec3 ro, vec3 rd, vec3 lightDir, vec3 lightE, vec3 ambTop, vec3 ambBottom) {
    if (abs(rd.y) < 1e-4) return vec4(0.0, 0.0, 0.0, 1.0);
    float t = (MID_ALT - ro.y) / rd.y;
    if (t <= 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
    vec3 p = ro + rd * t;
    float d = midLayerDensity(p.xz);
    if (d <= 0.001) return vec4(0.0, 0.0, 0.0, 1.0);
    float pathLen = 25.0 / max(abs(rd.y), 0.06);
    float alpha = 1.0 - exp(-0.05 * d * pathLen);
    float mu = dot(rd, lightDir);
    // Thin edges glow with the sun behind them; thick hearts are greyer.
    vec3 S = lightE * (mix(phaseHG(mu, 0.6), phaseHG(mu, -0.2), 0.35) * 0.9 + 0.08) * (0.6 + 0.4 * (1.0 - d))
           + mix(ambBottom, ambTop, 0.6);
    S *= mix(vec3(1.0), vec3(0.68, 0.72, 0.80), saturate(skyRain() * 0.9 + lfThunder * 0.3));
    S += cloudFlashGlow(p, 180.0) * 0.8;
    float fade = exp(-max(t - 1200.0, 0.0) / 7000.0);
    return vec4(S * alpha * fade, 1.0 - alpha * fade);
}
vec4 cloudOver(vec4 front, vec4 back) { return vec4(front.rgb + front.a * back.rgb, front.a * back.a); }

// ------------------------------------------------------------- dispatch ----
vec4 renderClouds(vec3 ro, vec3 rd, float maxDist, vec3 lightDir, vec3 lightE, vec3 ambTop, vec3 ambBottom, int quality, float dither) {
    #if !defined DIM_NETHER && !defined DIM_END
        gCloudFlash = cloudFlash();
        gCloudFlashCol = vec3(0.70, 0.78, 1.0);
    #endif
    #if CLOUD_MODE == 1
        int cells = quality == 0 ? 24 : quality == 1 ? 40 : quality == 2 ? 64 : 96;
        return blockyClouds(ro, rd, maxDist, lightDir, lightE, ambTop, ambBottom, cells);
    #elif CLOUD_MODE == 2 || CLOUD_MODE == 5
        int steps = quality == 0 ? 12 : quality == 1 ? 20 : quality == 2 ? 32 : 48;
        vec4 c = realisticClouds(ro, rd, maxDist, lightDir, lightE, ambTop, ambBottom, steps, dither);
        #if CLOUD_LAYERS > 1
            if (maxDist > 1e5) {
                vec4 h = highCloudLayer(ro, rd, lightDir, lightE, ambTop);
                #if CLOUD_MODE == 5
                    // Three heights: the decks, the patchy middle layer, the cirrus.
                    vec4 m = midCloudLayer(ro, rd, lightDir, lightE, ambTop, ambBottom);
                    if (ro.y < MID_ALT) c = cloudOver(c, cloudOver(m, h));
                    else if (ro.y < VOL_Y1 + 380.0) c = rd.y < 0.0 ? cloudOver(m, c) : cloudOver(h, c);
                    else c = cloudOver(h, cloudOver(m, c));
                #else
                    // Seen from below, the high layer is behind the main clouds.
                    c = ro.y < VOL_Y1 + 380.0 ? cloudOver(c, h) : cloudOver(h, c);
                #endif
            }
        #endif
        return c;
    #else
        return vec4(0.0, 0.0, 0.0, 1.0);
    #endif
}

// Shadow cast on the ground by the clouds: the sunlight that makes it through the
// clouds actually drawn in the sky, so a cloud passing over the sun dims it the way
// it looks like it should. Cloud Shadow Strength is the share of the sun a thick
// cloud takes away: 0.75 (default) most of it, 1.0 all of it, leaving the sky's light.
float cloudShadowAmount() { return saturate(CLOUD_SHADOW_STRENGTH); }
// k: how much of the light a thick cloud takes away (1 = all of it).
float cloudShadowK(vec3 worldPos, vec3 lightDir, float k, bool cheap) {
    #if CLOUD_MODE == 1 || CLOUD_MODE == 2 || CLOUD_MODE == 5
        if (lightDir.y < 0.02) return 1.0;
        float fadeIn = smoothstep(0.02, 0.12, lightDir.y);
        float lit = 1.0;
        #if CLOUD_MODE == 1
            for (int i = 0; i < CLOUD_LAYERS; i++) {
                BlockyLayer L = blockyLayer(i);
                float thr = blockyThreshold(L.cov);
                if (thr > 1.5) continue;
                float ymid = L.y0 + L.var * 0.5 + L.thick * 0.8;
                if (worldPos.y > ymid) continue;
                vec3 q = worldPos + lightDir * ((ymid - worldPos.y) / lightDir.y);
                float r = L.size * 0.16;
                float occ = 0.0;
                if (cheap) {
                    occ = 4.0 * blockyWeight(blockyCell(q.xz, L), L, thr);
                } else {
                    occ += blockyWeight(blockyCell(q.xz + vec2( r,  0.5 * r), L), L, thr);
                    occ += blockyWeight(blockyCell(q.xz + vec2(-r, -0.5 * r), L), L, thr);
                    occ += blockyWeight(blockyCell(q.xz + vec2( 0.5 * r, -r), L), L, thr);
                    occ += blockyWeight(blockyCell(q.xz + vec2(-0.5 * r,  r), L), L, thr);
                }
                lit *= 1.0 - k * 0.9 * occ * 0.25 * (i == 0 ? 1.0 : 0.6);
            }
        #else
            // Optical depth along the light through the lower half of the cloud layer.
            float od = 0.0;
            for (int i = 0; i < 4; i++) {
                if (cheap && (i & 1) == 1) continue;
                #if CLOUD_MODE == 5
                    float y = float(REALISTIC_CLOUD_ALTITUDE) - 30.0 + 45.0 * float(i);   // through the decks' bodies
                #else
                    float y = VOL_Y0 + (VOL_Y1 - VOL_Y0) * (0.05 + 0.14 * float(i));
                #endif
                if (worldPos.y >= y) continue;
                vec3 q = worldPos + lightDir * ((y - worldPos.y) / lightDir.y);
                od += volDensity(q, 0.0) * (cheap ? 2.0 : 1.0);
            }
            lit *= mix(1.0, exp(-od * 1.4), k);
            #if CLOUD_LAYERS > 1
              #if CLOUD_MODE == 5
                if (worldPos.y < MID_ALT) {
                    vec3 qm = worldPos + lightDir * ((MID_ALT - worldPos.y) / lightDir.y);
                    lit *= 1.0 - 0.55 * k * midLayerDensity(qm.xz);
                }
              #endif
              if (!cheap) {
                float yh = VOL_Y1 + 380.0;
                vec3 qh = worldPos + lightDir * ((yh - worldPos.y) / lightDir.y);
                vec2 hq = (qh.xz + cloudOffset() * 4.0) * 0.0006;
                float hc = highLayerCov();
                lit *= 1.0 - 0.3 * k * smoothstep(1.0 - hc, 1.0 - hc + 0.3, fbm2(hq, 3)) * step(0.001, hc);
              }
            #endif
        #endif
        return mix(1.0, lit, fadeIn);
    #else
        return 1.0;
    #endif
}
float cloudShadow(vec3 worldPos, vec3 lightDir) {
    #if CLOUD_SHADOWS == 1
        return cloudShadowK(worldPos, lightDir, cloudShadowAmount(), false);
    #else
        return 1.0;
    #endif
}



#endif
