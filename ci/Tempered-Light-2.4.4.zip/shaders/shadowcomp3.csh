#version 430
// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define FAR_PASS_XZ
#include "/program/farlight_comp.glsl"
