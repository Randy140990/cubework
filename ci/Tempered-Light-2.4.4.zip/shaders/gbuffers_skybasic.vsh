#version 330 compatibility
// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define VSH
#define PROGRAM_SKYBASIC
#include "/program/gbuffers_sky.glsl"
