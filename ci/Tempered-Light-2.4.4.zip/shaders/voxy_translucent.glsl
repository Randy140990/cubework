// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#include "/program/voxy_translucent_impl.glsl"
