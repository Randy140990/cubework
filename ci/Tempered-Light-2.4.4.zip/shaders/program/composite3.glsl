/*
    Tempered Light - world blur (distance blur or depth of field) and distant
    light bokeh. Runs after anti-aliasing. Each pixel gathers its neighbours on a
    spiral; a neighbour only counts if its own blur is big enough to reach this
    pixel, so sharp things in front never smear onto blurred things behind them
    (and the held item never blurs or bleeds).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/space.glsl"

#ifdef VSH
out vec2 texcoord;
flat out float distBlur;     // distance blur strength for the current conditions
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    #if defined DIM_NETHER
        distBlur = DB_NETHER;
    #elif defined DIM_END
        distBlur = DB_END;
    #else
        float sunY = normalize(mat3(gbufferModelViewInverse) * sunPosition).y;
        float outdoors = smoothstep(0.1, 0.7, float(eyeBrightnessSmooth.y) / 240.0);
        float day = smoothstep(-0.05, 0.15, sunY) * outdoors;
        distBlur = mix(DB_NIGHT, DB_DAY, day);
        distBlur = mix(distBlur, DB_RAIN, rainStrength * outdoors);
    #endif
    if (isEyeInWater == 1) distBlur = DB_WATER;
}
#endif

#ifdef FSH
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float centerDepthSmooth;
#ifdef VOXY
uniform sampler2D vxDepthTexOpaque;
uniform sampler2D vxDepthTexTrans;
#endif
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
#endif

in vec2 texcoord;
flat in float distBlur;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

const float SKY_DIST = 4096.0;
const float GOLDEN_ANGLE = 2.39996323;

// Distance in blocks to what this pixel shows (vanilla, Distant Horizons or Voxy).
// Negative for the held item.
float pixelDistance(ivec2 p) {
    float d = texelFetch(depthtex0, p, 0).r;
    if (d < 0.56) return -1.0;
    vec2 uv = (vec2(p) + 0.5) / vec2(viewWidth, viewHeight);
    if (d < 1.0) return length(screenToView(uv, d, gbufferProjectionInverse));
    #ifdef DISTANT_HORIZONS
        float dd = texelFetch(dhDepthTex0, p, 0).r;
        if (dd < 1.0) return length(screenToView(uv, dd, dhProjectionInverse));
    #endif
    #ifdef VOXY
        float vd = min(texelFetch(vxDepthTexOpaque, p, 0).r, texelFetch(vxDepthTexTrans, p, 0).r);
        if (vd < 1.0) return length(screenToView(uv, vd, vxProjInv));
    #endif
    return SKY_DIST;
}

float focusDistance() {
    #if DOF_FOCUS > 0
        return float(DOF_FOCUS);
    #else
        // The game tracks the depth at the centre of the screen, eased over time.
        if (centerDepthSmooth >= 0.99999) return min(farDistance(), SKY_DIST);
        return max(length(screenToView(vec2(0.5), centerDepthSmooth, gbufferProjectionInverse)), 0.3);
    #endif
}

// How much a zoomed-in (narrower) view enlarges the blur, when FOV Scaled Blur
// is on. Kept gentle and capped: a spyglass softens the background a little more,
// it never smears the whole picture.
float lensScale() {
    #if WB_FOV_SCALED == 1
        return clamp(sqrt(gbufferProjection[1][1] / 1.43), 0.85, 1.4);
    #else
        return 1.0;
    #endif
}

// Blur radius in pixels for something at distance d.
float blurSize(float d, float focus, float pxScale) {
    if (d < 0.0) return 0.0;               // held item stays sharp
    float r = 0.0;
    #if WORLD_BLUR == 2
        // Like a camera lens, blur follows how different the thing's nearness
        // (1 / distance) is from the focus's, so the far landscape behind a statue
        // at 8 blocks softens about as much as the ground 4 blocks in front of it.
        // A small dead band keeps the whole of what you look at crisp, and the blur
        // eases into a ceiling: near and far go soft, never melt away.
        float defocus = DOF_APERTURE * DOF_STRENGTH * abs(1.0 / focus - 1.0 / d);
        defocus = max(defocus - 0.5, 0.0);
        float ceiling = DOF_MAX_BLUR * sqrt(DOF_STRENGTH);
        r = ceiling * (1.0 - exp(-defocus / ceiling));
    #elif WORLD_BLUR == 1
        // Like fog: far things soften, near things stay sharp.
        float fb = 1.0 - exp(-max(d - 12.0, 0.0) / 110.0);
        r = 8.0 * distBlur * fb;
    #endif
    return r * lensScale() * pxScale;
}

// The furthest any blur can reach, in pixels.
float maxBlur(float pxScale) {
    #if WORLD_BLUR == 2
        return DOF_MAX_BLUR * sqrt(DOF_STRENGTH) * lensScale() * pxScale;
    #else
        return 8.0 * max(distBlur, 0.0) * lensScale() * pxScale;
    #endif
}

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    ivec2 lim = ivec2(viewWidth, viewHeight) - 1;
    vec3 center = texelFetch(colortex0, px, 0).rgb;
    float pxScale = viewHeight / 1080.0;
    float cDist = pixelDistance(px);
    vec3 result = center;

    #if WORLD_BLUR > 0
        float focus = focusDistance();
        #if WORLD_BLUR == 2 && DOF_FOCUS == 0
            // Whatever is under the crosshair is sharp at once: round the middle of the
            // screen the focus is where you look now, while the rest of the view eases
            // over to it.
            float nowFocus = pixelDistance(ivec2(viewWidth, viewHeight) / 2);
            if (nowFocus > 0.0) {
                vec2 cuv = (gl_FragCoord.xy / vec2(viewWidth, viewHeight) - 0.5) * vec2(viewWidth / viewHeight, 1.0);
                float zone = smoothstep(0.16, 0.07, length(cuv));
                focus = 1.0 / mix(1.0 / focus, 1.0 / max(nowFocus, 0.3), zone);
            }
        #endif
        float cSize = blurSize(cDist, focus, pxScale);
        float maxR = max(maxBlur(pxScale), 0.5);
        #if WB_ANAMORPHIC == 1
            const vec2 shape = vec2(1.0, 0.45);     // stretched sideways, like an anamorphic lens
        #else
            const vec2 shape = vec2(1.0);
        #endif
        // How far to gather: this pixel's own blur, or further if something blurred
        // in front of it is close enough to spill over it.
        float reach = cSize;
        for (int i = 0; i < 8; i++) {
            float a = float(i) * 0.785398 + 0.39;
            float pr = (i < 4 ? 0.5 : 1.0) * maxR;
            ivec2 sp = clamp(px + ivec2(round(vec2(cos(a), sin(a)) * pr * shape)), ivec2(0), lim);
            float sDist = pixelDistance(sp);
            if (sDist >= 0.0 && (sDist < cDist || cDist < 0.0))
                reach = max(reach, min(blurSize(sDist, focus, pxScale), pr * 1.2 + 1.0));
        }
        reach = min(reach, maxR);
        vec3 acc = center;
        float tot = 1.0;
        if (reach > 0.6) {
            for (int i = 0; i < DOF_QUALITY; i++) {
                float r = sqrt((float(i) + 0.5) / float(DOF_QUALITY)) * reach;
                float a = float(i) * GOLDEN_ANGLE;
                vec2 off = vec2(cos(a), sin(a)) * r * shape;
                ivec2 sp = clamp(px + ivec2(round(off)), ivec2(0), lim);
                float sDist = pixelDistance(sp);
                float sSize = blurSize(sDist, focus, pxScale);
                // Something behind this pixel can't blur over it by more than this pixel's own blur.
                if (sDist > cDist && cDist >= 0.0) sSize = min(sSize, cSize * 2.0);
                float m = smoothstep(r - 0.5, r + 0.5, sSize);
                // Filtered reads keep small blurs smooth instead of blocky.
                vec2 suv = clamp((vec2(px) + 0.5 + off) / vec2(viewWidth, viewHeight), vec2(0.0), vec2(1.0));
                vec3 sc = texture(colortex0, suv).rgb;
                #if DISTANT_LIGHT_BOKEH == 1
                    // Bright points bloom into soft discs (bokeh) as they blur.
                    m *= 1.0 + 2.0 * smoothstep(1.5, 6.0, luminance(sc)) * m;
                #endif
                acc += mix(acc / tot, sc, saturate(m));
                tot += 1.0;
            }
        }
        result = acc / tot;
        #if WB_CHROMATIC == 1
            // Colour fringes in the blurred parts, as from a real lens.
            if (cSize > 1.0) {
                vec2 rad = texcoord - 0.5;
                float rl = length(rad);
                vec2 o = (rl > 1e-4 ? rad / rl : vec2(1.0, 0.0)) * min(cSize * 0.3, 4.0) / vec2(viewWidth, viewHeight);
                result.r = mix(result.r, texture(colortex0, texcoord + o).r, 0.6);
                result.b = mix(result.b, texture(colortex0, texcoord - o).b, 0.6);
            }
        #endif
    #endif

    #if DISTANT_LIGHT_BOKEH == 1
        // Distant lamps and glowing windows scatter into a soft point of light.
        if (cDist > 40.0 && cDist < SKY_DIST - 1.0) {
            vec3 g = vec3(0.0);
            float k = 0.0;
            for (int i = 0; i < 8; i++) {
                float a = float(i) * 0.785398;
                vec2 o = vec2(cos(a), sin(a)) * 1.6 * pxScale;
                vec3 s = texelFetch(colortex0, clamp(px + ivec2(round(o)), ivec2(0), lim), 0).rgb;
                float w = smoothstep(1.0, 4.0, luminance(s));
                g += s * w; k += w;
            }
            float fade = smoothstep(40.0, 96.0, cDist);
            if (k > 0.0) result = max(result, mix(result, g / k, 0.5 * fade * min(k / 3.0, 1.0)));
        }
    #endif
    outColor = vec4(max(result, 0.0), 1.0);
}
#endif
