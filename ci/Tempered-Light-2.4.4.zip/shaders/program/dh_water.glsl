/*
    Tempered Light - Distant Horizons water and glass: the data the composite
    pass shades (same targets and flags as gbuffers_water.glsl).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/program/dh_common.glsl"

#ifdef FSH
uniform sampler2D depthtex1;

/* RENDERTARGETS: 0,4,7,8,9 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outWater;
layout(location = 2) out vec4 outTint;
layout(location = 3) out vec4 outWaterDist;
layout(location = 4) out vec4 outGlass;

void main() {
    dhNearDiscard();
    // DH water only depth-tests against DH depth: never draw it over nearer vanilla terrain.
    if (texelFetch(depthtex1, ivec2(gl_FragCoord.xy), 0).r < 1.0) discard;
    vec3 N = normalize(normalW);
    outColor = vec4(0.0);
    outWaterDist = vec4(0.0);   // 0: composite places LOD water from the DH depth
    if (cat == CAT_WATER) {
        outWater = vec4(encodeNormal(N), pack2x8(vec2(lm.y, 64.0 / 255.0)), 1.0);   // texture brightness 0.5, not flowing
        outTint = vec4(vcol.rgb, 1.0);
        outGlass = vec4(0.0);
    } else {
        outWater = vec4(0.0);
        outTint = vec4(0.0);
        outGlass = vec4(encodeNormal(N), pack2x8(vec2(lm.y, 0.0)), 1.0);
    }
}
#endif
