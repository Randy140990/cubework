/*
    Tempered Light - distant light colour. The shadow pass leaves, in each
    4-block cell of a coarse grid, the colour of the strongest light source there.
    These two passes spread each colour over the cells its light reaches (first
    across, then up and down), weighted by how much light gets there, so a surface
    far from you takes on the colour of the lamps around it.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#define FF_COMPUTE
uniform vec3 cameraPosition;

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#include "/lib/floodfill.glsl"

layout(local_size_x = 8, local_size_y = 4, local_size_z = 8) in;
// Iris reads this line as plain text: literals only.
#if FAR_SIZE_XZ == 128
const ivec3 workGroups = ivec3(16, 12, 16);
#else
const ivec3 workGroups = ivec3(8, 8, 8);
#endif

#if USE_FAR_LIGHT == 1
    #ifdef FAR_PASS_XZ
        layout(r32ui) uniform readonly uimage3D lfFarSrc;
        layout(rgba16f) uniform writeonly image3D lfFarA;
    #else
        layout(rgba16f) uniform readonly image3D lfFarA;
        layout(rgba16f) uniform writeonly image3D lfFarB;
    #endif
#endif

void main() {
    #if USE_FAR_LIGHT == 1
        ivec3 c = ivec3(gl_GlobalInvocationID);
        if (!farInside(c)) return;
        vec4 acc = vec4(0.0);
        #ifdef FAR_PASS_XZ
            // Across: light from a level-15 lamp fades out over about 14 blocks.
            for (int dz = -3; dz <= 3; dz++) {
                for (int dx = -3; dx <= 3; dx++) {
                    ivec3 n = c + ivec3(dx, 0, dz);
                    if (!farInside(n)) continue;
                    uint u = imageLoad(lfFarSrc, n).r;
                    if (u == 0u) continue;
                    float d = length(vec2(dx, dz)) * FAR_CELL;
                    float w = max(float(farLevel(u)) - d, 0.0) / 15.0;
                    acc += vec4(farColor(u) * w, w);
                }
            }
            imageStore(lfFarA, c, acc);
        #else
            // Up and down.
            for (int dy = -3; dy <= 3; dy++) {
                ivec3 n = c + ivec3(0, dy, 0);
                if (!farInside(n)) continue;
                float w = max(1.0 - float(abs(dy)) * FAR_CELL / 15.0, 0.0);
                acc += imageLoad(lfFarA, n) * w;
            }
            imageStore(lfFarB, c, acc);
        #endif
    #endif
}
