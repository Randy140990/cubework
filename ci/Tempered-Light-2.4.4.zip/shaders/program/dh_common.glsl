/*
    Tempered Light - shared Distant Horizons vertex stage.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl"
#include "/lib/materials.glsl"

#ifdef VSH
out vec4 vcol;
out vec2 lm;
out vec3 normalW;
out vec3 playerPos;
flat out int cat;

int catFromDh(int id) {
    if (id == DH_BLOCK_LEAVES) return CAT_LEAVES;
    if (id == DH_BLOCK_SAND) return CAT_SAND;
    if (id == DH_BLOCK_DIRT) return CAT_DIRT;
    if (id == DH_BLOCK_STONE || id == DH_BLOCK_DEEPSLATE || id == DH_BLOCK_TERRACOTTA || id == DH_BLOCK_NETHER_STONE) return CAT_STONE_ROUGH;
    if (id == DH_BLOCK_WOOD) return CAT_WOOD;
    if (id == DH_BLOCK_METAL) return CAT_METAL;
    if (id == DH_BLOCK_SNOW) return CAT_SNOW;
    if (id == DH_BLOCK_LAVA) return CAT_LAVA;
    if (id == DH_BLOCK_WATER) return CAT_WATER;
    if (id == DH_BLOCK_ILLUMINATED) return CAT_EMITTER;
    return CAT_DEFAULT;
}

void main() {
    vcol = gl_Color;
    lm = saturate(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 1.0 / 32.0) * 16.0 / 15.0);
    normalW = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
    vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    playerPos = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
    cat = catFromDh(dhMaterialId);
    gl_Position = ftransform();
    // Sub-pixel jitter for temporal anti-aliasing.
    gl_Position.xy += taaJitter() * gl_Position.w;
}
#endif

#ifdef FSH
in vec4 vcol;
in vec2 lm;
in vec3 normalW;
in vec3 playerPos;
flat in int cat;

// Let vanilla chunks win inside the normal render distance.
void dhNearDiscard() {
    float edge = far - 12.0 - ign(gl_FragCoord.xy) * 10.0;
    if (length(playerPos) < edge) discard;
}
#endif
