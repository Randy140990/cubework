/*
    Tempered Light - sky panorama. Left half: sky only (for the sky and haze).
    Right half: sky with clouds (for reflections and sky light).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/wind.glsl"
#include "/lib/sky.glsl"
#include "/lib/clouds.glsl"

#ifdef VSH
out vec2 texcoord;
flat out vec3 sunDir;
flat out vec3 lightDir;
flat out vec3 lightE;
flat out vec3 ambient;
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    sunDir = worldSunDir();
    lightDir = worldLightDir();
    lightE = directLightIrradiance(sunDir);
    ambient = skyAmbientFromLut();  // last frame's panorama
}
#endif

#ifdef FSH
in vec2 texcoord;
flat in vec3 sunDir;
flat in vec3 lightDir;
flat in vec3 lightE;
flat in vec3 ambient;

const bool colortex6Clear = false;

/* RENDERTARGETS: 6 */
layout(location = 0) out vec4 outSky;

void main() {
    bool withClouds = texcoord.x >= 0.5;
    vec2 luv = vec2(fract(texcoord.x * 2.0), texcoord.y);
    vec3 dir = skyLutDir(luv);
    #if SKY_QUALITY == 0
        const int steps = 10; const int lsteps = 4;
    #elif SKY_QUALITY == 1
        const int steps = 16; const int lsteps = 6;
    #else
        const int steps = 24; const int lsteps = 8;
    #endif
    vec3 sunE = vec3(SUN_ILLUMINANCE) * (1.0 - 0.6 * skyRain());
    vec3 moonE = vec3(MOON_ILLUMINANCE * moonPhaseLight()) * vec3(0.78, 0.88, 1.12);
    vec3 sky = atmSkyRadiance(dir, sunDir, sunE, moonE, steps, lsteps);
    if (withClouds) {
        vec3 ambTop = ambient * 1.1;
        vec3 ambBottom = ambient * 0.32 + lightE * 0.02 * max(lightDir.y, 0.0);
        vec4 cl = renderClouds(cameraPosition, dir, 1e6, cloudLightDir(sunDir), cloudLightIrradiance(sunDir), ambTop, ambBottom, 0, 0.5);
        sky = sky * cl.a + cl.rgb;
    }
    outSky = vec4(sky, 1.0);
}
#endif
