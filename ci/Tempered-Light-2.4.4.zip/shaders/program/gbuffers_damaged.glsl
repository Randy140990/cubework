/*
    Tempered Light - block-breaking cracks, multiplied onto the albedo.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl"

#ifdef VSH
out vec2 uv;
out vec4 vcol;
void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vcol = gl_Color;
    gl_Position = ftransform();
    // Sub-pixel jitter for temporal anti-aliasing.
    gl_Position.xy += taaJitter() * gl_Position.w;
}
#endif

#ifdef FSH
uniform sampler2D gtexture;
in vec2 uv;
in vec4 vcol;

/* RENDERTARGETS: 1 */
layout(location = 0) out vec4 outAlbedo;

void main() {
    vec4 c = texture(gtexture, uv) * vcol;
    if (c.a < 0.02) discard;
    outAlbedo = c;
}
#endif
