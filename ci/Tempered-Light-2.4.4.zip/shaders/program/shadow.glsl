/*
    Tempered Light - shadow map (with waving so shadows sway) and, when light
    spread is on, the voxel grid of light sources, solid blocks and partial
    occluders.

    Iris does not set renderStage while drawing the shadow pass, so the kind of
    geometry comes from which shadow program is running (shadow_solid,
    shadow_cutout, shadow_water, shadow_entities, shadow_block); the generic
    "shadow" program falls back to renderStage and a geometry hint (terrain is
    the only geometry that carries at_midBlock).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#define SHADOW_PASS
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/materials.glsl"
#include "/lib/wind.glsl"
#include "/lib/shadows.glsl"
#include "/lib/floodfill.glsl"

/*
const int shadowcolor0Format = RGBA8;
*/

#ifdef VSH
#include "/lib/waving.glsl"
in vec4 mc_Entity;
in vec4 at_midBlock;
in vec2 mc_midTexCoord;

out vec2 uv;
out vec4 vcol;
flat out int cat;
flat out int translucent;

#if USE_FLOODFILL == 1
layout(r32ui) uniform uimage3D lfVoxel;
uniform ivec2 atlasSize;
uniform sampler2D gtexture;
#if FALLING_LEAVES == 1
layout(rgba8) uniform writeonly image2D lfLeafCol;
#endif
layout(r32ui) uniform uimage3D lfFaces;
#endif
#if USE_FAR_LIGHT == 1
layout(r32ui) uniform uimage3D lfFarSrc;
#endif

bool isTerrainGeometry() {
    #if defined SHADOW_STAGE_TERRAIN
        return true;
    #elif defined SHADOW_STAGE_OTHER
        return false;
    #else
        bool stage = renderStage == MC_RENDER_STAGE_TERRAIN_SOLID || renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT ||
                     renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED || renderStage == MC_RENDER_STAGE_TERRAIN_TRANSLUCENT;
        return stage || dot(at_midBlock.xyz, at_midBlock.xyz) > 0.5 || mc_Entity.x >= 1000.0;
    #endif
}

bool isTranslucentGeometry(int c) {
    #if defined SHADOW_STAGE_TRANSLUCENT
        return true;
    #elif defined SHADOW_STAGE_TERRAIN || defined SHADOW_STAGE_OTHER
        return false;
    #else
        return renderStage == MC_RENDER_STAGE_TERRAIN_TRANSLUCENT || isGlass(c) || c == CAT_ICE || c == CAT_TRANSLUCENT || c == CAT_PORTAL;
    #endif
}

void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vcol = gl_Color;
    vec2 lm = saturate(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 1.0 / 32.0) * 16.0 / 15.0);
    bool terrain = isTerrainGeometry();
    cat = terrain ? catFromId(mc_Entity.x) : CAT_ENTITY;
    bool trans = terrain && isTranslucentGeometry(cat);
    translucent = trans ? 1 : 0;

    vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    vec3 playerPos = mat3(shadowModelViewInverse) * viewPos + shadowModelViewInverse[3].xyz;

    #if USE_FLOODFILL == 1
        if (terrain) {
            vec3 mb = at_midBlock.xyz / 64.0;
            vec3 centreView = (gl_ModelViewMatrix * vec4(gl_Vertex.xyz + mb, 1.0)).xyz;
            vec3 centre = mat3(shadowModelViewInverse) * centreView + shadowModelViewInverse[3].xyz;
            ivec3 v = ffVoxelFromWorld(centre + cameraPosition);
            #ifdef IRIS_FEATURE_BLOCK_EMISSION_ATTRIBUTE
                int level = int(at_midBlock.w + 0.5);
            #else
                int level = 0;
                // No exact light level from Iris: estimate one from the block list.
                if (isEmitterCat(cat)) level = cat == CAT_MAGMA ? 4 : 10;
            #endif
            #if USE_FAR_LIGHT == 1
                // Light sources further out go into the coarse grid of distant light colour.
                if (level >= 6 && isEmitterCat(cat)) {
                    ivec3 fc = ivec3(floor(farCoord(centre)));
                    float strength = lightTypeStrength(cat);
                    if (farInside(fc) && strength > 0.0) {
                        vec4 eL = emitterLight(cat);
                        vec3 ec = eL.rgb / max(maxOf(eL.rgb), 1e-3) * strength * eL.a;
                        imageAtomicMax(lfFarSrc, fc, farPack(ec, level));
                    }
                }
            #endif
            if (ffInside(v)) {
                if (cat == CAT_LIGHT_BLOCK) level = max(level, int(lm.x * 15.0 + 0.5));
                #if GEM_GLOW == 1
                    if (isGem(cat)) level = max(level, min(15, int(7.0 + 4.0 * GEM_GLOW_STRENGTH)));
                #endif
                #if ORE_GLOW == 1
                    // Ores catch and give off a little light of their own colour.
                    if (isOre(cat)) level = max(level, min(15, int(4.0 + 3.5 * ORE_GLOW_STRENGTH)));
                #endif
                // Every corner of a full cube sits half a block from the centre on all three
                // axes, and its faces are square. (Slab, carpet and trapdoor sides also reach
                // the corners but their faces are not square.)
                vec2 halfTex = abs(gl_MultiTexCoord0.xy - mc_midTexCoord) * vec2(max(atlasSize, ivec2(1)));
                bool squareFace = atlasSize.x <= 0 || abs(halfTex.x - halfTex.y) < 0.1 * max(halfTex.x, halfTex.y);
                bool fullCube = all(greaterThan(abs(mb), vec3(0.45))) && squareFace;
                bool solid = fullCube && !trans && level == 0 && cat != CAT_WATER && !isLeaves(cat) && !isFoliage(cat) &&
                             (cat == CAT_DEFAULT || (cat >= CAT_SAND && cat <= CAT_SOLID_LAST) || isGem(cat) || isOre(cat));
                // Carpets are too thin to hide a light under them (lights under carpet are a
                // common build trick); they neither block nor shade it.
                bool partial = !solid && level == 0 && !trans && cat != CAT_WATER && cat != CAT_CARPET && cat != CAT_GROUND_COVER &&
                               (isFoliage(cat) || isLeaves(cat) || (abs(mb.y) > 0.45 && !fullCube));
                uint word = (level > 0 || solid || partial) ? ffPack(level, cat, solid, partial) : 0u;
                if (cat == CAT_STAINED_GLASS) {
                    // Stained glass colours the light that spreads through it: store the
                    // glass colour (the texture's average, from its smallest mipmap).
                    vec4 avg = textureLod(gtexture, mc_midTexCoord, 4.0);
                    vec3 gc = srgbToLinear(saturate(avg.rgb / max(avg.a, 0.02)) * gl_Color.rgb);
                    word |= ffPackTint(glassLightFilter(gc));
                }
                if (word != 0u) imageAtomicOr(lfVoxel, v, word);
                // Which faces of this block are drawn (see lib/floodfill.glsl): lets the light
                // pass find the buried blocks Minecraft never draws.
                uint fb = FF_FACE_OCCUPIED;
                if (minOf(abs(mb)) < 0.45) fb |= FF_FACE_NONFULL;
                else if (squareFace && !trans && cat != CAT_WATER && cat != CAT_LAVA && !isLeaves(cat) && !isFoliage(cat)) {
                    vec3 nW = mat3(shadowModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
                    fb |= FF_FACE_FULL | ffFaceBit(nW);
                }
                imageAtomicOr(lfFaces, v, fb);
                #if FALLING_LEAVES == 1
                    // The colour of each column's leaves (with the biome's tint), for the
                    // leaves that fall from them.
                    if (isLeaves(cat)) {
                        vec4 avg = textureLod(gtexture, mc_midTexCoord, 4.0);
                        imageStore(lfLeafCol, v.xz, vec4(saturate(avg.rgb / max(avg.a, 0.05)) * gl_Color.rgb, 1.0));
                    }
                #endif
            }
        } else if (blockEntityId == 1000 + CAT_END_PORTAL) {
            #if END_PORTAL_LIST == 1
                // An End portal's faces: mark their corners (see lib/floodfill.glsl).
                for (int k = 0; k < 4; k++) {
                    uint bit;
                    ivec3 v = ffVoxelFromWorld(vec3(ffEndCornerCell(playerPos + cameraPosition, k, bit)) + 0.5);
                    if (ffInside(v)) imageAtomicOr(lfFaces, v, bit);
                }
            #endif
        } else if (blockEntityId != 1024 && entityId != ENTITY_LIGHTNING) {
            // Mobs, the player and block entities: mark the blocks they fill so they cast
            // shadows from torches and lamps (beacon beams and lightning don't).
            ivec3 v = ffVoxelFromWorld(playerPos + cameraPosition);
            if (ffInside(v)) imageAtomicOr(lfVoxel, v, FF_ENTITY_BIT);
        }
    #endif

    if (terrain) {
        bool top = gl_MultiTexCoord0.y < mc_midTexCoord.y;
        playerPos += wavingOffset(cat, playerPos + cameraPosition, playerPos, top, lm.y, 0.5 - at_midBlock.y / 64.0);
    }
    vec4 clip = gl_ProjectionMatrix * (lfShadowModelView() * vec4(playerPos, 1.0));
    clip.xy = distortShadowXY(clip.xy);
    gl_Position = clip;
}
#endif

#ifdef FSH
uniform sampler2D gtexture;
in vec2 uv;
in vec4 vcol;
flat in int cat;
flat in int translucent;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outShadowColor;

void main() {
    if (cat == CAT_LIGHT_BLOCK) discard;
    vec4 c = texture(gtexture, uv) * vcol;
    if (cat == CAT_WATER) {
        outShadowColor = vec4(vcol.rgb, 0.0);
        return;
    }
    if (cat == CAT_STAINED_GLASS) {
        // Sunlight through stained glass takes its colour, like the view through it
        // (even where a resource pack makes the glass almost clear).
        vec3 gc = c.rgb;
        if (c.a < 0.1) {
            vec4 avg = textureLod(gtexture, uv, 4.0);
            gc = avg.a > 0.02 ? saturate(avg.rgb / avg.a) * vcol.rgb : vec3(1.0);
        }
        outShadowColor = vec4(glassLightFilter(srgbToLinear(gc)), 1.0);
        return;
    }
    if (c.a < 0.1) discard;
    if (translucent == 1) {
        // Ice, slime, honey: tint the light passing through.
        vec3 tint = srgbToLinear(c.rgb);
        tint = tint / max(maxOf(tint), 0.05);
        outShadowColor = vec4(tint, clamp(c.a, 0.1, 1.0));
    } else {
        outShadowColor = vec4(1.0);
    }
}
#endif
