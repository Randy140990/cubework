/*
    Tempered Light - spreads coloured block light through the voxel grid,
    one block per frame, like vanilla light levels. Alongside the light it keeps,
    for every block, the offsets to the two strongest light sources that reach it
    (used for shadows cast by light sources, so two lamps throw two shadows, and
    for round pools of light).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#define FF_COMPUTE
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform int frameCounter;

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#include "/lib/floodfill.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
// Iris reads this line as plain text: the numbers must be literals, not sums.
// (FF_SIZE / local size: 64 x 64 x 64 grid -> 8 8 8; 128 x 64 x 128 -> 16 8 16.)
#if FF_SIZE_XZ == 128
const ivec3 workGroups = ivec3(16, 16, 16);
#else
const ivec3 workGroups = ivec3(8, 8, 8);
#endif

#if USE_FLOODFILL == 1
layout(r32ui) uniform readonly uimage3D lfVoxel;
layout(rgba16f) uniform image3D lfLightA;
layout(rgba16f) uniform image3D lfLightB;
layout(rgba16f) uniform image3D lfSrcA;
layout(rgba16f) uniform image3D lfSrcB;
layout(rgba16f) uniform image3D lfSrc2A;
layout(rgba16f) uniform image3D lfSrc2B;

vec4 readPrev(ivec3 p, bool fromA) {
    if (!ffInside(p)) return vec4(0.0);
    return fromA ? imageLoad(lfLightA, p) : imageLoad(lfLightB, p);
}
vec4 readPrevSrc(ivec3 p, bool fromA) {
    if (!ffInside(p)) return vec4(0.0);
    return fromA ? imageLoad(lfSrcA, p) : imageLoad(lfSrcB, p);
}
vec4 readPrevSrc2(ivec3 p, bool fromA) {
    if (!ffInside(p)) return vec4(0.0);
    return fromA ? imageLoad(lfSrc2A, p) : imageLoad(lfSrc2B, p);
}

// Keeps the two strongest distinct sources. s: offset to the source + its level;
// est: how strongly it reaches this block.
void offerSource(vec4 s, float est, inout vec4 b1, inout float e1, inout vec4 b2, inout float e2) {
    if (s.w <= 0.0 || est <= 0.0) return;
    if (e1 > 0.0 && distance(s.xyz, b1.xyz) < 0.5) { if (est > e1) { b1 = s; e1 = est; } return; }
    if (e2 > 0.0 && distance(s.xyz, b2.xyz) < 0.5) {
        if (est > e2) { b2 = s; e2 = est; }
    } else if (est > e2) { b2 = s; e2 = est; }
    if (e2 > e1) { vec4 t = b1; b1 = b2; b2 = t; float te = e1; e1 = e2; e2 = te; }
}
#endif

void main() {
    #if USE_FLOODFILL == 1
        ivec3 v = ivec3(gl_GlobalInvocationID);
        if (!ffInside(v)) return;
        // This frame writes A on even frames, B on odd; reads the other one.
        bool writeA = (frameCounter & 1) == 0;
        bool readA = !writeA;
        // The grid follows the camera: shift last frame's light by the block offset.
        ivec3 shift = ivec3(floor(cameraPosition) - floor(previousCameraPosition));
        ivec3 pv = v + shift;

        uint vox = imageLoad(lfVoxel, v).r;
        vec4 result = vec4(0.0);
        vec4 src = vec4(0.0);   // xyz: offset from this block to its main source, w: source level
        vec4 src2 = vec4(0.0);  // the second strongest source
        float e1 = 0.0, e2 = 0.0;
        if (!ffSolid(vox)) {
            // Faces and edges (18 neighbours): a step along an edge costs sqrt(2) levels,
            // so pools of light come out round rather than vanilla's diamonds.
            const ivec3 dirs[18] = ivec3[18](
                ivec3(1, 0, 0), ivec3(-1, 0, 0), ivec3(0, 1, 0), ivec3(0, -1, 0), ivec3(0, 0, 1), ivec3(0, 0, -1),
                ivec3(1, 1, 0), ivec3(1, -1, 0), ivec3(-1, 1, 0), ivec3(-1, -1, 0),
                ivec3(1, 0, 1), ivec3(1, 0, -1), ivec3(-1, 0, 1), ivec3(-1, 0, -1),
                ivec3(0, 1, 1), ivec3(0, 1, -1), ivec3(0, -1, 1), ivec3(0, -1, -1));
            // Partial occluders (plants, leaves, fences) dim the light a little as it passes.
            float loss = ffPartial(vox) ? 1.6 / 15.0 : 1.0 / 15.0;
            vec3 colSum = vec3(0.0);
            float wSum = 0.0, maxLevel = 0.0;
            int best = -1;
            for (int i = 0; i < 18; i++) {
                ivec3 d = dirs[i];
                if (i >= 6) {
                    // No squeezing diagonally between two solid blocks that meet at an edge.
                    ivec3 a = ivec3(d.x, d.y, 0), b = ivec3(0, d.y, d.z);
                    if (d.y == 0) { a = ivec3(d.x, 0, 0); b = ivec3(0, 0, d.z); }
                    else if (d.x == 0) { a = ivec3(0, d.y, 0); b = ivec3(0, 0, d.z); }
                    else { a = ivec3(d.x, 0, 0); b = ivec3(0, d.y, 0); }
                    bool sa = ffInside(v + a) && ffSolid(imageLoad(lfVoxel, v + a).r);
                    bool sb = ffInside(v + b) && ffSolid(imageLoad(lfVoxel, v + b).r);
                    if (sa && sb) continue;
                }
                vec4 n = readPrev(pv + d, readA);
                if (n.a <= 0.0) continue;
                float lv = n.a - loss * (i >= 6 ? 1.41421 : 1.0);
                if (lv <= 0.0) continue;
                colSum += n.rgb / n.a * lv;   // colour weighted by the light arriving from there
                wSum += lv;
                if (lv > maxLevel) { maxLevel = lv; best = i; }
                // The sources the face neighbours know about, seen from here (sources travel
                // through faces only: just as exact, and a third of the reads).
                if (i < 6) {
                    vec4 s1 = readPrevSrc(pv + d, readA);
                    vec4 s2 = readPrevSrc2(pv + d, readA);
                    if (s1.w > 0.0) { vec3 o = s1.xyz + vec3(d); offerSource(vec4(o, s1.w), s1.w - length(o) / 15.0, src, e1, src2, e2); }
                    if (s2.w > 0.0) { vec3 o = s2.xyz + vec3(d); offerSource(vec4(o, s2.w), s2.w - length(o) / 15.0, src, e1, src2, e2); }
                }
            }
            float level = maxLevel;
            if (level > 0.0 && wSum > 0.0) result = vec4(colSum / wSum * level, level);

            // Light passing through stained glass leaves it in the glass's colour.
            if (ffTinted(vox)) result.rgb *= ffTint(vox);

            int el = ffLevel(vox);
            if (el > 0) {
                // The level always matches vanilla's (so the grid stays in step with the
                // game's own light levels); the Light Sources strength scales the colour,
                // so 0 is no light at all and 3 is three times as bright.
                float strength = lightTypeStrength(ffCat(vox));
                float elevel = float(el) / 15.0;
                vec4 eL = emitterLight(ffCat(vox));
                // Colour, scaled by how strong this kind of light is (lava and sea
                // lanterns outshine a torch) and the Light Sources setting.
                vec3 ec = eL.rgb / max(maxOf(eL.rgb), 1e-3) * strength * eL.a;
                if (elevel >= result.a) {
                    result = vec4(ec * elevel, elevel);
                } else {
                    result.rgb = mix(result.rgb, ec * result.a, 0.5);
                }
                offerSource(vec4(0.0, 0.0, 0.0, elevel), elevel + 0.01, src, e1, src2, e2);
            }
        }
        if (writeA) { imageStore(lfLightA, v, result); imageStore(lfSrcA, v, src); imageStore(lfSrc2A, v, src2); }
        else { imageStore(lfLightB, v, result); imageStore(lfSrcB, v, src); imageStore(lfSrc2B, v, src2); }
    #endif
}
