/*
    Tempered Light - rain and snow.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl"
#include "/lib/materials.glsl"
#include "/lib/wind.glsl"
#include "/lib/space.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/sky.glsl"

#if !defined DIM_NETHER && !defined DIM_END
    #define DIM_OVERWORLD
#endif

// ===== vertex

#ifdef VSH
#ifdef PROGRAM_WATER
in vec4 mc_Entity;
in vec4 at_midBlock;
#endif
in vec4 at_tangent;

out vec2 uv;
out vec2 lm;
out vec4 vcol;
out vec3 normalW;
out vec3 playerPos;
flat out int cat;
flat out float emitLevel;
flat out vec3 fwdSky;
flat out vec3 fwdLightE;
flat out vec3 fwdLightDir;
flat out vec3 fwdSunDir;

void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lm = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lm = saturate((lm - 1.0 / 32.0) * 16.0 / 15.0);
    vcol = gl_Color;
    normalW = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
    vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    playerPos = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
    #ifdef PROGRAM_WATER
        cat = catFromId(mc_Entity.x);
        emitLevel = 0.0;
    #elif defined PROGRAM_CLOUDS
        cat = CAT_CLOUD;
        emitLevel = 0.0;
    #else
        cat = CAT_PARTICLE;
        emitLevel = 0.0;
    #endif
    #if !defined PROGRAM_WATER && !defined PROGRAM_CLOUDS
        // Rain and snow lean with the wind: the higher up the column, the further
        // upwind, so they fall at a slant. Snow is lighter and blows further, most in
        // a snowstorm.
        if (WEATHER_SLANT > 0.0) {
            vec2 wd = windDirection();
            float k = WEATHER_SLANT * (0.08 + 0.22 * windStrength());
            k *= mix(1.0, 1.8 + 2.2 * saturate(snowStormHere() * SNOWSTORMS), lfSnowHere);
            // Only above your eyes: where rain stops (the ground, a roof, a porch below
            // you) stays where Minecraft puts it, so it never falls into shelters.
            playerPos.xz -= wd * min(k, 1.2) * max(playerPos.y, 0.0);
            viewPos = (gbufferModelView * vec4(playerPos, 1.0)).xyz;
        }
    #endif
    gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);

    #ifdef DIM_OVERWORLD
        fwdSunDir = worldSunDir();
        fwdLightDir = worldLightDir();
        fwdLightE = directLightIrradiance(fwdSunDir);
        fwdSky = skyAmbientFromLut();
    #else
        fwdSunDir = vec3(0.0, -1.0, 0.0);
        fwdLightDir = vec3(0.0, 1.0, 0.0);
        fwdLightE = vec3(0.0);
        fwdSky = otherDimAmbient();
    #endif
    // Sub-pixel jitter for temporal anti-aliasing.
    gl_Position.xy += taaJitter() * gl_Position.w;
}
#endif

// ===== fragment

#ifdef FSH

uniform sampler2D gtexture;

in vec2 uv;
in vec2 lm;
in vec4 vcol;
in vec3 normalW;
in vec3 playerPos;
flat in int cat;
flat in float emitLevel;
flat in vec3 fwdSky;
flat in vec3 fwdLightE;
flat in vec3 fwdLightDir;
flat in vec3 fwdSunDir;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;


void main() {
    vec4 tex = texture(gtexture, uv);
    vec4 albedo = tex * vcol;
    float snow = smoothstep(0.6, 0.85, luminance(tex.rgb));
    #if SNOW_STYLE == 1
        // Snow: turn the texture's square pixel flakes into soft round flakes, each a
        // disc centred on its cluster of pixels and sized by how many there are.
        vec2 ts = vec2(textureSize(gtexture, 0));
        vec2 p = uv * ts;
        vec2 base = floor(p);
        float sumA = 0.0; vec2 cen = vec2(0.0); float lum = 0.0;
        for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) {
            vec2 cell = base + vec2(x, y) + 0.5;
            vec4 t = texelFetch(gtexture, ivec2(mod(cell, ts)), 0);
            sumA += t.a; cen += cell * t.a; lum += luminance(t.rgb) * t.a;
        }
        if (sumA > 0.05 && lum / sumA > 0.6) {
            cen /= sumA;
            float r = 0.55 * sqrt(sumA);
            float disc = smoothstep(r, r * 0.35, length(p - cen));
            albedo = vec4(vec3(1.0), disc * min(sumA, 1.0) * vcol.a);
            snow = 1.0;
        }
    #endif

    if (albedo.a < 0.01) discard;
    vec3 light = fwdSky * (0.6 + 0.6 * lm.y) + fwdLightE * 0.05 + defaultBlockLightColor() * blockLightCurve(lm.x) * 0.5;
    vec3 rainTint = mix(vec3(0.75, 0.82, 0.9), vec3(1.0), snow);
    float a = albedo.a * RAIN_OPACITY * mix(0.55, 1.0, snow);
    #if !defined DIM_NETHER && !defined DIM_END
        a *= 1.0 + snow * saturate(snowStormHere() * SNOWSTORMS) * 0.6;   // thicker in a snowstorm
    #endif
    #if !defined DIM_NETHER && !defined DIM_END
        // Above the clouds nothing falls (Minecraft would show snow up there).
        a *= belowCloudDeck();
    #endif
    if (a < 0.003) discard;
    outColor = vec4(rainTint * light * 1.2, a);

}
#endif
