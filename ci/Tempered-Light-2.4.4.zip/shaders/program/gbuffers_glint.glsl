/*
    Tempered Light - enchantment glint. Adds its shimmer to the albedo (and
    to the colour when drawn after lighting). It never touches the normal or
    material targets, so enchanted gear is lit like the item underneath.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl"

#ifdef VSH
out vec2 uv;
out vec4 vcol;
void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vcol = gl_Color;
    gl_Position = gl_ProjectionMatrix * (gl_ModelViewMatrix * gl_Vertex);
    // Sub-pixel jitter for temporal anti-aliasing.
    gl_Position.xy += taaJitter() * gl_Position.w;
}
#endif

#ifdef FSH
uniform sampler2D gtexture;
in vec2 uv;
in vec4 vcol;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outAlbedo;

void main() {
    vec4 g = texture(gtexture, uv) * vcol;
    // Vanilla blends the glint additively; keep its strength modest in the albedo.
    outAlbedo = vec4(g.rgb * 0.75, g.a);
    outColor = vec4(srgbToLinear(g.rgb) * 0.35 * EMISSIVE_STRENGTH, g.a);
}
#endif
