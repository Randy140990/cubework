/*
    Tempered Light - opaque G-buffer programs (terrain, entities, block
    entities, hand, beacon beam, lines). Body: gbuffers_solid.glsl.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
/* RENDERTARGETS: 0,1,2,3 */
#include "/program/gbuffers_solid.glsl"
