/*
    Tempered Light - finds, for every column of the light grid, the underside
    of the lowest leaves with open air below them and the ground they would fall
    to (falling leaves), and whether rain runs off the edge of what covers it
    (a tree's canopy, an overhanging roof) to drip down to the ground there. The
    composite pass draws the leaves and the drips from this map.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#define FF_COMPUTE
uniform vec3 cameraPosition;

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#include "/lib/floodfill.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 1) in;
// Iris reads this line as plain text: literals only.
#if FF_SIZE_XZ == 128
const ivec3 workGroups = ivec3(16, 16, 1);
#else
const ivec3 workGroups = ivec3(8, 8, 1);
#endif

#if USE_FLOODFILL == 1 && (FALLING_LEAVES == 1 || CANOPY_DRIPS_ON == 1)
#define CANOPY_PASS
layout(r32ui) uniform readonly uimage3D lfVoxel;
layout(rgba16f) uniform writeonly image2D lfCanopy;

bool covers(uint w) { return ffSolid(w) || ffPartial(w); }
// Height of the topmost thing in a column (-1: open to the sky all the way down).
int coverTop(ivec2 c) {
    if (any(lessThan(c, ivec2(0))) || any(greaterThanEqual(c, FF_SIZE.xz))) return -1;
    for (int y = FF_SIZE.y - 1; y >= 0; y--) {
        if (covers(imageLoad(lfVoxel, ivec3(c.x, y, c.y)).r)) return y;
    }
    return -1;
}
#endif

void main() {
    #ifdef CANOPY_PASS
        ivec2 c = ivec2(gl_GlobalInvocationID.xy);
        if (any(greaterThanEqual(c, FF_SIZE.xz))) return;
        // Scan down the column: remember the lowest leaf block with air under it, then
        // the first solid block below that (where a leaf lands).
        float leafCell = -1.0, groundCell = -1.0;
        bool above = false;
        for (int y = FF_SIZE.y - 1; y >= 0; y--) {
            uint w = imageLoad(lfVoxel, ivec3(c.x, y, c.y)).r;
            bool leaf = ffCat(w) == CAT_LEAVES && ffPartial(w);
            bool solid = ffSolid(w);
            if (above && !leaf && !solid) { leafCell = float(y + 1); groundCell = -1.0; }
            if (leafCell >= 0.0 && groundCell < 0.0 && solid) groundCell = float(y + 1);
            above = leaf;
        }
        if (leafCell >= 0.0 && groundCell < 0.0) groundCell = max(leafCell - 16.0, 0.0);

        // Drips: the topmost cover in this column (open to the rain above), down to its
        // underside; if a column beside it is open to the sky lower than that, rain
        // runs off this edge and drips from the underside to the ground below.
        float dripCell = -1.0, dripGround = -1.0;
        int top = coverTop(c);
        if (top >= 0) {
            int u = top;
            while (u > 0 && covers(imageLoad(lfVoxel, ivec3(c.x, u - 1, c.y)).r)) u--;
            // u: the lowest cover block of the stack; air below it?
            int g = u - 1;
            while (g >= 0 && !covers(imageLoad(lfVoxel, ivec3(c.x, g, c.y)).r)) g--;
            float fall = float(u - (g + 1));
            if (u > 0 && fall >= 1.5) {
                int open = -1;
                if (coverTop(c + ivec2(1, 0)) < u) open = 0;
                else if (coverTop(c - ivec2(1, 0)) < u) open = 1;
                else if (coverTop(c + ivec2(0, 1)) < u) open = 2;
                else if (coverTop(c - ivec2(0, 1)) < u) open = 3;
                if (open >= 0) {
                    // Which side is open, in the quarter-cells (exact in half floats).
                    dripCell = float(u) + 0.25 * float(open);
                    dripGround = float(g + 1);
                }
            }
        }
        // Cell indices (exact in half floats); the reader adds the grid's world origin.
        // x leaf underside (-1 none), y where leaves land, z drip underside + side / 4
        // (-1 none), w where drips land.
        imageStore(lfCanopy, c, vec4(leafCell, groundCell, dripCell, dripGround));
    #endif
}
