/*
    Tempered Light - particles. Same body as the opaque programs, plus a
    mask (colortex4 alpha) so solid particles over water aren't shaded as water.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#define WRITES_WATER_MASK
/* RENDERTARGETS: 0,1,2,3,4 */
#include "/program/gbuffers_solid.glsl"
