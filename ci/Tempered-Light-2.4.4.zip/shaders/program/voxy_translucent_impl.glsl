/*
    Tempered Light - Voxy LOD water and glass. Writes the same data targets
    as gbuffers_water.glsl: water (colortex4, tint colortex7, distance colortex8)
    or glass (colortex9). Voxy draws these with blending off, so each fragment
    clears the other kind's target.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"

layout(location = 0) out vec4 lfWater;
layout(location = 1) out vec4 lfTint;
layout(location = 2) out vec4 lfWaterDist;
layout(location = 3) out vec4 lfGlass;

void voxy_emitFragment(VoxyFragmentParameters parameters) {
    int cat = catFromId(float(parameters.customId));
    uint axis = parameters.face >> 1u;
    float s = (parameters.face & 1u) == 0u ? -1.0 : 1.0;
    vec3 N = axis == 0u ? vec3(0.0, s, 0.0) : (axis == 1u ? vec3(0.0, 0.0, s) : vec3(s, 0.0, 0.0));
    vec2 lm = clamp((parameters.lightMap - 1.0 / 32.0) * 16.0 / 15.0, 0.0, 1.0);
    lfWaterDist = vec4(0.0);    // 0: composite places LOD water from the Voxy depth
    if (cat == CAT_WATER) {
        lfWater = vec4(encodeNormal(N), pack2x8(vec2(lm.y, 64.0 / 255.0)), 1.0);   // texture brightness 0.5, not flowing
        lfTint = vec4(parameters.tinting.rgb, 1.0);
        lfGlass = vec4(0.0);
    } else {
        lfWater = vec4(0.0);
        lfTint = vec4(0.0);
        lfGlass = vec4(encodeNormal(N), pack2x8(vec2(lm.y, 0.0)), 1.0);
    }
}
