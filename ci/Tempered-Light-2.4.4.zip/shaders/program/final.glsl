/*
    Tempered Light - bloom, exposure, film curve, colour grade, vignette.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/tonemap.glsl"

#if !defined DIM_NETHER && !defined DIM_END
    #define DIM_OVERWORLD
#endif

/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA8;
const int colortex2Format = RGBA16;
const int colortex3Format = RGBA8;
const int colortex4Format = RGBA16;
const int colortex5Format = RGBA16F;
const int colortex6Format = RGBA16F;
const int colortex7Format = RGBA8;
const int colortex8Format = R16F;
const int colortex9Format = RGBA16;
const int colortex10Format = RGBA16F;
const int colortex11Format = RGBA8;
const bool colortex10Clear = false;
const bool colortex6Clear = false;
const vec4 colortex4ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex5ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex7ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex8ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex9ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex11ClearColor = vec4(1.0, 1.0, 1.0, 1.0);
*/
const bool colortex0MipmapEnabled = true;

#ifdef VSH
#ifdef DIM_END
#include "/lib/endstorm.glsl"
#endif
out vec2 texcoord;
flat out float exposure;
flat out vec3 sunScreen;     // xy: sun (or moon) on screen, z: how strong a lens flare it makes
flat out vec3 flareTint;
flat out float flareBurst;   // how strong the starburst of rays round the light is
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    sunScreen = vec3(0.0);
    flareTint = vec3(1.0, 0.9, 0.75);
    flareBurst = 1.0;
    #if LENS_FLARE >= 1 && defined DIM_OVERWORLD
        // Lens Flare: 1 sun only, 2 sun and moon (the moon's much fainter and cooler).
        vec3 src = sunPosition;
        float srcH = normalize(mat3(gbufferModelViewInverse) * sunPosition).y;
        float k = smoothstep(-0.02, 0.08, srcH);
        #if LENS_FLARE == 2
            if (srcH < 0.0) {
                src = moonPosition;
                k = smoothstep(-0.02, 0.08, -srcH) * 0.3 * (0.15 + 0.85 * abs(4.0 - float(moonPhase)) / 4.0);
                flareTint = vec3(0.7, 0.8, 1.0);
            }
        #endif
        vec4 sc = gbufferProjection * vec4(src, 1.0);
        if (sc.w > 0.0) {
            vec2 suv = sc.xy / sc.w * 0.5 + 0.5;
            float onScreen = smoothstep(-0.1, 0.05, min(min(suv.x, suv.y), min(1.0 - suv.x, 1.0 - suv.y)));
            sunScreen = vec3(suv, onScreen * k * (1.0 - skyRain()) * float(isEyeInWater == 0));
        }
    #endif
    #if LENS_FLARE >= 1 && (defined DIM_END || defined DIM_NETHER)
        // The End's black hole and the black sun over the Nether roof flare like the sun.
        #ifdef DIM_END
            vec3 objW = normalize(END_HOLE_DIR); float objK = float(END_SKY == 1); flareTint = vec3(0.85, 0.6, 1.0);
        #else
            vec3 objW = normalize(NETHER_SUN_DIR); float objK = smoothstep(122.0, 130.0, cameraPosition.y) * 0.6; flareTint = vec3(1.0, 0.45, 0.25);
            flareBurst = 0.0;      // the black sun glares, but throws no rays
        #endif
        vec4 oc = gbufferProjection * vec4(mat3(gbufferModelView) * objW * 100.0, 1.0);
        if (oc.w > 0.0 && objK > 0.0) {
            vec2 ouv = oc.xy / oc.w * 0.5 + 0.5;
            float onS = smoothstep(-0.1, 0.05, min(min(ouv.x, ouv.y), min(1.0 - ouv.x, 1.0 - ouv.y)));
            sunScreen = vec3(ouv, onS * objK);
            #ifdef DIM_END
                // Behind the End Storm's cloud the hole only flares as much as its light
                // gets through to you.
                if (END_STORM > 0.0) sunScreen.z *= pow(endStormShadow(cameraPosition, 6), 1.6);
            #endif
        }
    #endif
    float skyEye = saturate(float(eyeBrightnessSmooth.y) / 240.0);
    #ifdef DIM_OVERWORLD
        float sunY = normalize(mat3(gbufferModelViewInverse) * sunPosition).y;
        // Exposure only opens up once the sun is below the horizon.
        float day = smoothstep(-0.25, 0.12, sunY);
        // Night stays night: eyes adjust, but moonlight is far dimmer than daylight.
        float nightExp = 4.5 * LOOK_NIGHT_LIFT;
        float outdoor = mix(nightExp, 1.0, day);
        // Twilight: the afterglow stays readable for a while after the sun has set.
        outdoor *= 1.0 + 0.6 * smoothstep(-0.32, -0.14, sunY) * (1.0 - smoothstep(-0.06, 0.08, sunY));
        exposure = mix(2.6, outdoor, smoothstep(0.08, 0.7, skyEye));
        // Your eyes adjust to lamps too: standing in a pool of light at night, exposure
        // falls back towards the indoor level, so the lit area keeps its colour.
        float blockEye = saturate(float(eyeBrightnessSmooth.x) / 240.0);
        exposure = mix(exposure, min(exposure, 2.6), smoothstep(0.3, 0.85, blockEye));
    #elif defined DIM_NETHER
        exposure = 2.2;
    #else
        exposure = 2.6;
    #endif
    exposure *= exp2(EXPOSURE);
}
#endif

#ifdef FSH
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
in vec2 texcoord;
flat in float exposure;
flat in vec3 sunScreen;
flat in vec3 flareTint;
flat in float flareBurst;

// Ghosts of the sun reflected inside the lens, spread along the line through the
// middle of the screen, plus a faint ring.
vec3 lensFlare(vec2 uv, vec2 sun, float strength) {
    vec2 asp = vec2(viewWidth / viewHeight, 1.0);
    vec2 axis = vec2(0.5) - sun;
    vec3 f = vec3(0.0);
    const float pos[5] = float[5](0.35, 0.62, 0.9, 1.25, 1.6);
    const float rad[5] = float[5](0.035, 0.06, 0.025, 0.09, 0.05);
    const vec3 tint[5] = vec3[5](vec3(1.0, 0.75, 0.45), vec3(0.45, 0.8, 1.0), vec3(1.0, 0.5, 0.8), vec3(0.5, 1.0, 0.6), vec3(0.7, 0.6, 1.0));
    for (int i = 0; i < 5; i++) {
        vec2 c = sun + axis * pos[i] * 2.0;
        float d = length((uv - c) * asp);
        f += tint[i] * smoothstep(rad[i], rad[i] * 0.55, d) * 0.05;
    }
    float r = length((uv - 0.5 - axis * 0.6) * asp);
    f += vec3(0.8, 0.9, 1.0) * smoothstep(0.012, 0.0, abs(r - 0.42)) * 0.012;
    // Looking into the sun: a bright glare round it, a starburst of rays, and a
    // veil over the whole picture that grows the closer the sun is to the middle.
    vec2 ds = (uv - sun) * asp;
    float dl = length(ds);
    float glare = exp(-dl * 11.0) * 0.12;
    float ang = atan(ds.y, ds.x);
    float rays = pow(abs(cos(ang * 3.0)), 40.0) * 0.6 + pow(abs(cos(ang * 3.0 + 0.52)), 60.0) * 0.4;
    float burst = rays * exp(-dl * 7.0) * 0.08 * flareBurst;
    float veil = 0.03 * exp(-length((sun - 0.5) * asp) * 2.5);
    return (f + (glare + burst + veil) * flareTint) * strength;
}

layout(location = 0) out vec4 fragColor;

// Water running down the screen: streams stretched up and down, sliding down.
float filmHeight(vec2 p, float t) {
    // Streams: stretched up and down, sliding downwards, the quick ones thinner.
    float a = vnoise(vec2(p.x * 9.0, p.y * 1.8 + t * 1.3));
    float b = vnoise(vec2(p.x * 21.0 + 3.7, p.y * 3.5 + t * 2.4));
    float c = vnoise(vec2(p.x * 4.0 + 9.1, p.y * 1.1 + t * 0.7));
    return a * 0.5 + b * 0.25 + c * 0.25;
}

#if SCREEN_DROPLETS == 1
// Water on the screen after you come up out of the water: a thin film that runs
// down the screen in wavering streams, bending the view behind it. The top dries
// first and the wet edge slides down until the screen is clear. wet: 1 just out of
// the water, falling to 0 over a few seconds. Returns how far to shift the picture.
vec2 screenFilm(vec2 uv, float wet, float t) {
    vec2 p = uv * vec2(viewWidth / viewHeight, 1.0);
    // How far down the screen is already dry (from the top).
    float dry = (1.0 - wet) * 1.15;
    float edge = 1.0 - uv.y - dry + (vnoise(vec2(p.x * 6.0, 1.3)) - 0.5) * 0.12;
    float cover = smoothstep(-0.06, 0.12, edge) * smoothstep(0.0, 0.15, wet);
    if (cover <= 0.0) return vec2(0.0);
    const float e = 0.004;
    float h0 = filmHeight(p, t);
    vec2 g = vec2(filmHeight(p + vec2(e, 0.0), t) - h0, filmHeight(p + vec2(0.0, e), t) - h0) / e;
    // Thicker water lower down, where it gathers before running off.
    float thick = 0.5 + 0.5 * smoothstep(0.0, 0.6, edge);
    return g * 0.0028 * cover * thick;
}
#endif

#if defined IRIS_FEATURE_CUSTOM_IMAGES && defined DIM_OVERWORLD
#define HAS_RAIN_LENS
uniform sampler2D lfLodSampler;
// Rain on the screen: drops running down the screen as if down your face, each
// leaving a wet trail, and a little water running down at its left and right
// edges. The middle of the view stays clear. xy: how far to shift the view, z: a
// glint along the drops.
vec3 rainLens(vec2 uv, float wet, float t) {
    float asp = viewWidth / viewHeight;
    vec2 p = uv * vec2(asp, 1.0);
    vec2 off = vec2(0.0);
    float rim = 0.0;
    // Water running down the edges of the view only.
    float sides = smoothstep(0.72, 0.97, abs(uv.x * 2.0 - 1.0));
    if (sides > 0.0) {
        const float e = 0.004;
        float h0 = filmHeight(p, t);
        vec2 g = vec2(filmHeight(p + vec2(e, 0.0), t) - h0, filmHeight(p + vec2(0.0, e), t) - h0) / e;
        off += g * 0.0016 * wet * sides;
    }
    // Runners: every so often a drop slides down, leaving a trail of water.
    float cw = 0.11;
    float col = floor(p.x / cw);
    vec3 hr = hash33(vec3(col, 5.7, 1.1));
    float period = 4.0 + 6.0 * hr.x;
    float tt = t + hr.y * 53.0;
    float cyc = floor(tt / period);
    if (hash12(vec2(cyc, col * 0.37 + 9.0)) < wet * 0.5) {
        float age = fract(tt / period) * period;
        float speed = 0.18 + 0.25 * hr.z;
        float x = (col + 0.3 + 0.4 * hr.y) * cw + sin(age * 2.3 + hr.x * 6.0) * 0.006;
        float y = 1.15 - speed * age;                         // from the top, down
        float r = 0.016 + 0.01 * hr.z;
        vec2 d = (p - vec2(x, y)) / vec2(r * 0.85, r);
        float dd = length(d);
        if (dd < 1.0) {
            off -= d * r * (1.0 - dd * dd) * 1.8;
            rim += smoothstep(0.55, 1.0, dd) * (d.y > 0.0 ? 0.9 : -0.35) * abs(d.y) / max(dd, 1e-5);
        }
        // The wet trail above it, narrowing and drying.
        float above = p.y - y;
        if (above > 0.0 && above < 0.35) {
            float tw = r * 0.35 * (1.0 - above / 0.35);
            float dx = (p.x - x) / max(tw, 1e-4);
            if (abs(dx) < 1.0) {
                off.x -= dx * tw * (1.0 - dx * dx) * 1.4;
                rim += 0.25 * smoothstep(0.5, 1.0, abs(dx)) * (1.0 - above / 0.35);
            }
        }
    }
    return vec3(off / vec2(asp, 1.0), rim);
}

// Frost on the screen in the cold: ice creeping in from the edges, about a tenth of
// the way at most, with a jagged, crystalline front and fine veins, see-through.
// xy: how far the ice bends the view, z: how thick (0..1), w: the crystal veins.
float ridge(vec2 p) { float n = vnoise(p); return pow(1.0 - abs(2.0 * n - 1.0), 3.0); }
vec4 screenFrost(vec2 uv, float f) {
    float asp = viewWidth / viewHeight;
    vec2 p = uv * vec2(asp, 1.0);
    float dx = min(uv.x, 1.0 - uv.x) * asp, dy = min(uv.y, 1.0 - uv.y);
    // A soft minimum, so the frost reaches further into the corners.
    const float k = 18.0;
    float e = -log(exp(-dx * k) + exp(-dy * k)) / k;
    float W = 0.105 * f;
    if (e > W * 1.5 + 0.03) return vec4(0.0);
    // The front grows in spiky fingers (crystals), not a smooth line.
    float n = vnoise(p * 7.0) * 0.45 + ridge(p * 23.0 + 3.1) * 0.35 + ridge(p * 57.0 + 7.7) * 0.2;
    float front = W * (0.45 + 1.1 * n);
    float cover = 1.0 - smoothstep(front - 0.006, front, e);
    if (cover <= 0.0) return vec4(0.0);
    float veins = ridge(p * 26.0) * 0.5 + ridge(p * 61.0 + 5.3) * 0.3 + ridge(p * 140.0 + 9.1) * 0.2;
    // Thicker at the very edge.
    float thick = cover * (0.55 + 0.45 * (1.0 - e / max(front, 1e-3)));
    const float h = 0.002;
    float n0 = vnoise(p * 19.0 + 3.1);
    vec2 g = vec2(vnoise(p * 19.0 + vec2(h, 0.0) + 3.1) - n0, vnoise(p * 19.0 + vec2(0.0, h) + 3.1) - n0) / h;
    return vec4(g * 0.0018 * thick, thick, veins);
}
#endif

vec3 bloomTap(vec2 uv, float lod) {
    vec2 o = exp2(lod) / vec2(viewWidth, viewHeight);
    return (textureLod(colortex0, uv + vec2(o.x, o.y) * 0.5, lod).rgb + textureLod(colortex0, uv - vec2(o.x, o.y) * 0.5, lod).rgb +
            textureLod(colortex0, uv + vec2(o.x, -o.y) * 0.5, lod).rgb + textureLod(colortex0, uv - vec2(o.x, -o.y) * 0.5, lod).rgb) * 0.25;
}

void main() {
    vec2 uv = texcoord;
    #if UNDERWATER_DISTORTION == 1
        if (isEyeInWater == 1) {
            float t = frameTimeCounter;
            uv += vec2(sin(uv.y * 23.0 + t * 1.9), cos(uv.x * 19.0 + t * 1.6)) * 0.0018;
            uv = clamp(uv, vec2(0.001), vec2(0.999));
        }
    #endif
    #if SCREEN_DROPLETS == 1 && DEBUG_VIEW == 0
        if (isEyeInWater == 0 && lfEyeWet > 0.01) {
            uv = clamp(uv + screenFilm(uv, lfEyeWet, frameTimeCounter), vec2(0.001), vec2(0.999));
        }
    #endif
    float lensRim = 0.0;
    #if defined HAS_RAIN_LENS && DEBUG_VIEW == 0
        if (RAIN_ON_SCREEN > 0.0 && isEyeInWater == 0) {
            float wl = texelFetch(lfLodSampler, ivec2(7 + (frameCounter & 1), 0), 0).r;
            if (wl > 0.01 && wl <= 1.0) {
                vec3 rl = rainLens(uv, saturate(wl * RAIN_ON_SCREEN), frameTimeCounter);
                uv = clamp(uv + rl.xy, vec2(0.001), vec2(0.999));
                lensRim = rl.z * min(RAIN_ON_SCREEN, 1.0);
            }
        }
    #endif
    vec4 frost = vec4(0.0);
    #if defined HAS_RAIN_LENS && DEBUG_VIEW == 0
        if (SCREEN_FROST > 0.0 && isEyeInWater == 0) {
            float fr = texelFetch(lfLodSampler, ivec2(9 + (frameCounter & 1), 0), 0).r;
            if (fr > 0.005 && fr <= 1.0) {
                frost = screenFrost(uv, fr * min(SCREEN_FROST, 2.0));
                uv = clamp(uv + frost.xy, vec2(0.001), vec2(0.999));
            }
        }
    #endif
    vec3 col = texture(colortex0, uv).rgb;
    // A faint glint round the edge of each drop.
    col *= 1.0 + 0.3 * lensRim;
    if (frost.z > 0.0) {
        // Ice scatters the light behind it (a blurred, paler view), its crystals
        // catching more; see-through, about half as opaque as it could be.
        vec3 blur = textureLod(colortex0, uv, 3.0).rgb;
        vec3 ice = blur * vec3(0.90, 0.97, 1.08) * 1.25 + vec3(luminance(blur)) * 0.7 * frost.w + vec3(0.002, 0.003, 0.004);
        col = mix(col, ice, saturate(frost.z * (0.42 + 0.4 * frost.w)) * min(SCREEN_FROST, 1.25));
    }
    #if DEBUG_VIEW == 0
        if (CHROMATIC_ABERRATION > 0.0) {
            // Colour fringes towards the edges of the screen, like a real lens.
            vec2 ca = (uv - 0.5) * dot(uv - 0.5, uv - 0.5) * 0.022 * CHROMATIC_ABERRATION;
            col.r = texture(colortex0, uv - ca).r;
            col.b = texture(colortex0, uv + ca).b;
        }
    #endif
    #if TAA >= 1
        // Light sharpening to win back the crispness TAA softens.
        if (SHARPEN > 0.0) {
            ivec2 px = ivec2(gl_FragCoord.xy);
            ivec2 lim = ivec2(viewWidth, viewHeight) - 1;
            vec3 n0 = texelFetch(colortex0, clamp(px + ivec2(0, 1), ivec2(0), lim), 0).rgb;
            vec3 n1 = texelFetch(colortex0, clamp(px - ivec2(0, 1), ivec2(0), lim), 0).rgb;
            vec3 n2 = texelFetch(colortex0, clamp(px + ivec2(1, 0), ivec2(0), lim), 0).rgb;
            vec3 n3 = texelFetch(colortex0, clamp(px - ivec2(1, 0), ivec2(0), lim), 0).rgb;
            vec3 mn = min(min(n0, n1), min(n2, n3)), mx = max(max(n0, n1), max(n2, n3));
            vec3 sharp = col + (col - (n0 + n1 + n2 + n3) * 0.25) * SHARPEN * 0.8;
            col = clamp(sharp, min(mn, col), max(mx, col));
        }
    #endif
    #if LENS_FLARE >= 1 && DEBUG_VIEW == 0
        if (sunScreen.z > 0.001) {
            // Only when the sun itself can be seen (not behind blocks).
            float vis = 0.0;
            for (int i = 0; i < 5; i++) {
                vec2 o = vec2(i == 1 ? 1.0 : i == 2 ? -1.0 : 0.0, i == 3 ? 1.0 : i == 4 ? -1.0 : 0.0) * 6.0 / vec2(viewWidth, viewHeight);
                vec2 p = sunScreen.xy + o;
                if (all(greaterThan(p, vec2(0.0))) && all(lessThan(p, vec2(1.0)))) vis += step(1.0, texture(depthtex0, p).r);
            }
            vis /= 5.0;
            #ifdef DIM_OVERWORLD
            // ...and not behind clouds: the disc must stand out from the sky around it.
            vec2 asp = vec2(viewHeight / viewWidth, 1.0);
            float lc = luminance(texture(colortex0, sunScreen.xy).rgb);
            float lo = 0.0;
            for (int i = 0; i < 4; i++) {
                float a = float(i) * 1.5708 + 0.4;
                lo += luminance(texture(colortex0, clamp(sunScreen.xy + vec2(cos(a), sin(a)) * asp * 0.06, 0.0, 1.0)).rgb);
            }
            vis *= smoothstep(1.6, 4.0, lc / max(lo * 0.25, 1e-5));
            #endif
            col += lensFlare(uv, sunScreen.xy, sunScreen.z * vis * LENS_FLARE_STRENGTH) * 1.5;
        }
    #endif
    #if BLOOM == 1 && DEBUG_VIEW == 0
        vec3 b = vec3(0.0);
        b += bloomTap(uv, 1.5) * 0.30;
        b += bloomTap(uv, 2.5) * 0.25;
        b += bloomTap(uv, 3.5) * 0.20;
        b += bloomTap(uv, 4.5) * 0.15;
        b += bloomTap(uv, 5.5) * 0.10;
        float k = 0.045 * BLOOM_STRENGTH * (1.0 + 1.5 * skyRain());
        col = mix(col, b, k) + max(b - 1.0, 0.0) * 0.03 * BLOOM_STRENGTH;
    #endif
    #if DEBUG_VIEW == 0
        col *= exposure;
        col = grade(col);
        // Film curve per channel, blended with a hue-preserving version so bright
        // coloured light (lamps, lava, sunsets) keeps its colour instead of turning white.
        {
            float L = luminance(col);
            vec3 hp = col * (filmCurve(vec3(L)).x / max(L, 1e-5));
            col = mix(filmCurve(col), min(hp, vec3(1.0)), 0.35);
        }
        #if GRADE_MODE == 2
            col = col + 0.012 * (1.0 - col);
        #endif
        #if VIGNETTE == 1
            vec2 d = uv - 0.5;
            col *= 1.0 - 0.28 * smoothstep(0.25, 0.85, dot(d, d) * 2.0);
        #endif
    #else
        col = saturate(col);
    #endif
    col = linearToSrgb(col);
    col += (ign(gl_FragCoord.xy) - 0.5) / 255.0;
    fragColor = vec4(col, 1.0);
}
#endif
