/*
    Tempered Light - vanilla clouds (Vanilla cloud style only).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl"
#include "/lib/materials.glsl"
#include "/lib/wind.glsl"
#include "/lib/space.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/sky.glsl"

// ===== vertex

#ifdef VSH
#ifdef PROGRAM_WATER
in vec4 mc_Entity;
in vec4 at_midBlock;
#endif
in vec4 at_tangent;

out vec2 uv;
out vec2 lm;
out vec4 vcol;
out vec3 normalW;
out vec3 playerPos;
flat out int cat;
flat out float emitLevel;
flat out vec3 fwdSky;
flat out vec3 fwdLightE;
flat out vec3 fwdLightDir;
flat out vec3 fwdSunDir;

void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lm = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lm = saturate((lm - 1.0 / 32.0) * 16.0 / 15.0);
    vcol = gl_Color;
    normalW = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
    vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    playerPos = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
    #ifdef PROGRAM_WATER
        cat = catFromId(mc_Entity.x);
        emitLevel = saturate(at_midBlock.w / 15.0);
    #elif defined PROGRAM_CLOUDS
        cat = CAT_CLOUD;
        emitLevel = 0.0;
    #else
        cat = CAT_PARTICLE;
        emitLevel = 0.0;
    #endif
    gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);

    fwdSunDir = worldSunDir();
    fwdLightDir = worldLightDir();
    fwdLightE = directLightIrradiance(fwdSunDir);
    fwdSky = skyAmbientFromLut();
    // Sub-pixel jitter for temporal anti-aliasing.
    gl_Position.xy += taaJitter() * gl_Position.w;
}
#endif

// ===== fragment

#ifdef FSH

uniform sampler2D gtexture;

in vec2 uv;
in vec2 lm;
in vec4 vcol;
in vec3 normalW;
in vec3 playerPos;
flat in int cat;
flat in float emitLevel;
flat in vec3 fwdSky;
flat in vec3 fwdLightE;
flat in vec3 fwdLightDir;
flat in vec3 fwdSunDir;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;


void main() {
    vec4 tex = texture(gtexture, uv);
    vec4 albedo = tex * vcol;

    #if CLOUD_MODE != 3
        discard;
    #else
        if (albedo.a < 0.01) discard;
        vec3 N = normalize(normalW);
        float wrap = saturate(dot(N, fwdLightDir) * 0.5 + 0.5);
        vec3 col = srgbToLinear(albedo.rgb) * (fwdSky * (0.9 + 0.4 * N.y) + fwdLightE * wrap * RCP_PI * 1.3);
        outColor = vec4(col, albedo.a);
    #endif
}
#endif
