/*
    Tempered Light - water (data for the composite water pass) and glass,
    ice, slime and portals (forward lit).

    Water and glass keep separate data targets so water seen through a window,
    an aquarium wall or a layer of ice is still shaded as water:
      colortex4  water normal, sky light + texture brightness, flag   (water only)
      colortex7  biome water colour, flag                              (water only)
      colortex8  distance from the camera to the water surface        (water only)
      colortex9  glass normal, sky light, flag                         (glass only)
      colortex11 how much light gets through: every pane multiplies it  (glass only)
    Each fragment writes alpha 1 to its own targets and alpha 0 to the other
    kind's; the blend modes in shaders.properties make alpha 0 leave them as they are.
    Glass works like a filter, as real tinted glass does: stained glass darkens and
    colours whatever is behind it (deep blue behind blue glass, smoky behind black)
    instead of laying a pale wash of its own colour over it.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl"
#include "/lib/materials.glsl"
#include "/lib/wind.glsl"
#include "/lib/space.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/sky.glsl"
#include "/lib/water.glsl"

#if !defined DIM_NETHER && !defined DIM_END
    #define DIM_OVERWORLD
#endif
#if PORTAL_LIST == 1
    #include "/lib/floodfill.glsl"
#endif
#include "/lib/portal.glsl"

// ===== vertex

#ifdef VSH
#ifdef PROGRAM_WATER
in vec4 mc_Entity;
in vec4 at_midBlock;
#endif
in vec4 at_tangent;

out vec2 uv;
out vec2 lm;
out vec4 vcol;
out vec3 normalW;
out vec3 playerPos;
flat out int cat;
flat out float emitLevel;
flat out vec3 fwdSky;
flat out vec3 fwdLightE;
flat out vec3 fwdLightDir;
flat out vec3 fwdSunDir;
#if PORTAL_STYLE != 0
flat out vec4 portalA;   // xyz the middle of the portal (player space), w 1 = middle unknown
flat out vec3 portalB;   // xy half its width and height, z the way it runs (0 along x, 1 along z)
#endif

void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lm = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lm = saturate((lm - 1.0 / 32.0) * 16.0 / 15.0);
    vcol = gl_Color;
    normalW = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
    vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    playerPos = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
    #ifdef PROGRAM_WATER
        #ifdef PROGRAM_HAND_WATER
            cat = CAT_HAND;            // held items carry no block id
        #else
            cat = catFromId(mc_Entity.x);
        #endif
        #if defined IRIS_FEATURE_BLOCK_EMISSION_ATTRIBUTE && !defined PROGRAM_HAND_WATER
            emitLevel = saturate(at_midBlock.w / 15.0);
        #else
            emitLevel = 0.0;  // older Iris, or a held item (no at_midBlock): rely on the block list
        #endif
        // Swell: lift and lower the top of the water so waves have real height.
        if (cat == CAT_WATER && normalW.y > 0.5) {
            float sw = waterSwell(playerPos.xz + cameraPosition.xz, waterClock());
            playerPos.y += sw;
            viewPos = (gbufferModelView * vec4(playerPos, 1.0)).xyz;
        }
    #else
        cat = CAT_PARTICLE;
        emitLevel = 0.0;
    #endif
    #if PORTAL_STYLE != 0
        // Nether portals: find the whole portal this block is part of, so its vortex
        // is centred on the portal (see lib/portal.glsl).
        portalA = vec4(0.0, 0.0, 0.0, 1.0);
        portalB = vec3(1.0, 1.0, abs(normalW.x) > 0.5 ? 1.0 : 0.0);
        #if PORTAL_LIST == 1 && defined PROGRAM_WATER && !defined PROGRAM_HAND_WATER
            if (cat == CAT_PORTAL) {
                vec3 cv = (gl_ModelViewMatrix * vec4(gl_Vertex.xyz + at_midBlock.xyz / 64.0, 1.0)).xyz;
                vec3 bc = mat3(gbufferModelViewInverse) * cv + gbufferModelViewInverse[3].xyz;
                vec3 pc; vec2 ph; int pax; float pf;
                if (portalFind(bc, pc, ph, pax, pf) >= 0) {
                    portalA = vec4(pc, pf);
                    portalB = vec3(ph, float(pax));
                }
            }
        #endif
    #endif
    gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);

    #ifdef DIM_OVERWORLD
        fwdSunDir = worldSunDir();
        fwdLightDir = worldLightDir();
        fwdLightE = directLightIrradiance(fwdSunDir);
        fwdSky = skyAmbientFromLut();
    #else
        fwdSunDir = vec3(0.0, -1.0, 0.0);
        fwdLightDir = vec3(0.0, 1.0, 0.0);
        fwdLightE = vec3(0.0);
        fwdSky = otherDimAmbient();
    #endif
    // Sub-pixel jitter for temporal anti-aliasing.
    gl_Position.xy += taaJitter() * gl_Position.w;
}
#endif

// ===== fragment

#ifdef FSH
#ifdef PROGRAM_WATER
    #include "/lib/water.glsl"
    #include "/lib/shadows.glsl"
    #include "/lib/clouds.glsl"
    #include "/lib/lighting.glsl"
#endif

uniform sampler2D gtexture;

in vec2 uv;
in vec2 lm;
in vec4 vcol;
in vec3 normalW;
in vec3 playerPos;
flat in int cat;
flat in float emitLevel;
flat in vec3 fwdSky;
flat in vec3 fwdLightE;
flat in vec3 fwdLightDir;
flat in vec3 fwdSunDir;
#if PORTAL_STYLE != 0
flat in vec4 portalA;
flat in vec3 portalB;
#endif

/* RENDERTARGETS: 0,4,7,8,9,11 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outWater;
layout(location = 2) out vec4 outTint;
layout(location = 3) out vec4 outWaterDist;
layout(location = 4) out vec4 outGlass;
layout(location = 5) out vec4 outTrans;

void main() {
    vec4 tex = texture(gtexture, uv);
    vec4 albedo = tex * vcol;

    vec3 worldPos = playerPos + cameraPosition;
    float dist = length(playerPos);
    vec3 N = normalize(normalW);
    if (cat == CAT_WATER) {
        if (abs(N.y) > 0.5) {
            // The surface is one interface whichever side it is seen from:
            // use the wave normal, turned to face the camera.
            vec3 wn = waterNormal(worldPos, dist);
            #if RAIN_ON_WATER == 1
                // Rings from raindrops landing on the water.
                float rh = rainHere() * smoothstep(0.7, 0.95, lm.y);
                if (rh > 0.01 && N.y > 0.0) {
                    vec2 g = rainRipples(worldPos.xz * 1.7, frameTimeCounter) * rh * 2.0;
                    wn = normalize(wn + vec3(-g.x, 0.0, -g.y));
                }
            #endif
            // Your own ripples and wake.
            if (N.y > 0.0) wn = applyPlayerWake(wn, worldPos);
            #if WATER_FLOW == 1
                if (N.y < 0.995 && N.y > 0.0) {
                    // Sloped (flowing) water: gentle ripples drifting downhill.
                    vec2 fd = normalize(N.xz + 1e-5);
                    vec2 q = vec2(dot(worldPos.xz, fd), dot(worldPos.xz, vec2(-fd.y, fd.x)));
                    float tf = waterClock() * 2.4;
                    float h0 = vnoise(vec2(q.x * 1.8 - tf, q.y * 5.0));
                    float hx = vnoise(vec2(q.x * 1.8 - tf + 0.08, q.y * 5.0)) - h0;
                    float hy = vnoise(vec2(q.x * 1.8 - tf, q.y * 5.0 + 0.08)) - h0;
                    vec2 gq = vec2(hx, hy) / 0.08 * 0.09;
                    wn = normalize(wn - vec3(fd * gq.x + vec2(-fd.y, fd.x) * gq.y, 0.0).xzy);
                }
            #endif
            N = playerPos.y < 0.0 ? wn : -wn;
        } else {
            #if WATER_FLOW == 1
                // Falling water (the sides of a waterfall or fountain): soft streaks
                // sliding down, unhurried, so the sheet reads as clear running water.
                vec3 up = vec3(0.0, 1.0, 0.0);
                vec3 side = normalize(cross(N, up));
                float a = dot(worldPos, side);
                float tf = waterClock() * 2.5;
                float h0 = vnoise(vec2(a * 3.0, worldPos.y * 0.7 + tf));
                float ha = vnoise(vec2(a * 3.0 + 0.1, worldPos.y * 0.7 + tf)) - h0;
                float hb = vnoise(vec2(a * 3.0, worldPos.y * 0.7 + tf + 0.1)) - h0;
                N = normalize(N - side * ha * 0.9 - up * hb * 0.35);
            #endif
            if (dot(N, playerPos) > 0.0) N = -N;
        }
        outColor = vec4(0.0);
        // Top bit of the texture brightness byte marks flowing water (tilted or falling).
        bool flowingW = abs(normalize(normalW).y) < 0.995;
        float tlum = floor(saturate(luminance(tex.rgb)) * 127.0 + 0.5) + (flowingW ? 128.0 : 0.0);
        outWater = vec4(encodeNormal(N), pack2x8(vec2(lm.y, tlum / 255.0)), 1.0);
        outTint = vec4(vcol.rgb, 1.0);
        outWaterDist = vec4(dist, 0.0, 0.0, 1.0);
        outGlass = vec4(0.0);
        outTrans = vec4(1.0);
        return;
    }
    // Glass, ice, slime, honey, portals: lit here, reflections added in composite.
    vec3 alb = srgbToLinear(albedo.rgb);
    bool plainGlass = cat == CAT_GLASS;
    bool stained = cat == CAT_STAINED_GLASS;
    if (albedo.a < 0.02 && !plainGlass && !stained) discard;
    vec3 Vg = -normalize(playerPos);
    float far = smoothstep(3.0, 40.0, dist);
    float graze = 1.0 - abs(dot(N, Vg));
    vec3 trans = vec3(1.0);
    if (plainGlass) {
        // Clear glass has body: a cool blue-green tint and some darkening. Up close you
        // see straight through; further away and at an angle the inside goes dim and
        // the reflection of the world (added in composite) takes over.
        vec3 tintG = mix(vec3(1.0), vec3(0.52, 0.66, 0.70), saturate(0.55 * GLASS_TINT));
        trans = tintG * (1.0 - saturate(GLASS_TINT * (0.15 + 0.35 * far + 0.2 * graze)));
    } else if (stained) {
        // Coloured glass absorbs: each texel lets through its own colour, deeper where
        // the glass is denser (the frame, the streaks). Very clear resource-pack glass
        // still tints; black glass turns smoky rather than vanishing.
        vec3 c = alb;
        if (albedo.a < 0.1) {
            // Nearly clear texels (some resource packs leave the middle of the pane
            // empty, often black): take the pane's colour from its smallest mipmap.
            vec4 avg = textureLod(gtexture, uv, 4.0);
            c = avg.a > 0.02 ? srgbToLinear(saturate(avg.rgb / avg.a) * vcol.rgb) : vec3(1.0);
        }
        c = max(c, vec3(0.05));
        float dens = mix(0.45, 1.0, saturate(albedo.a)) * (0.55 + 0.45 * GLASS_TINT) * 0.95;
        trans = pow(c, vec3(dens)) * (1.0 - saturate(GLASS_TINT * (0.1 + 0.3 * far + 0.15 * graze)));
    }
    Material m;
    m.albedo = alb; m.smoothness = 0.92; m.f0 = 0.04; m.emission = 0.0; m.ao = 1.0; m.cat = cat;
    float dither = frameDither(gl_FragCoord.xy);
    vec3 V = -normalize(playerPos);
    vec2 lmL = lm;
    ShadowSample sh;
    float cs = 1.0;
    #ifdef DIM_OVERWORLD
        sh = sampleShadow(playerPos, N, dot(N, fwdLightDir), lm.y, dither);
        cs = cloudShadow(worldPos, fwdLightDir);
    #else
        sh.light = vec3(0.0); sh.waterDepth = 0.0; sh.waterFrac = 0.0;
        lmL.y = 1.0;   // the flat Nether/End ambient stands in for sky light
    #endif
    SceneLights L;
    L.lightDir = fwdLightDir; L.lightE = fwdLightE; L.skyAmbient = fwdSky; L.sunDir = fwdSunDir;
    vec3 col = shadeSurface(m, N, V, playerPos, worldPos, lmL, sh, cs, noLamps(), L);
    float a = albedo.a;
    bool portal = cat == CAT_PORTAL;
    if (portal) {
        #if PORTAL_STYLE == 0
            // Nether portal: a glowing, glassy sheet you can partly see through, with
            // the world reflected in it (reflection added in composite).
            float swirl = luminance(albedo.rgb);
            col = alb * (0.6 + 1.6 * swirl) * 1.8 * EMISSIVE_STRENGTH;
            a = mix(0.45, 0.8, swirl);
        #else
            // Nether portal: a swirling vortex centred on the whole portal, or, where its
            // middle isn't known (beyond the light grid), the same energy flowing across it.
            vec3 da = portalB.z > 0.5 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
            vec3 rdp = normalize(playerPos);
            float tp = frameTimeCounter * PORTAL_SWIRL;
            vec4 pv = vec4(0.0);
            if (portalA.w < 1.0) {
                vec3 rel = playerPos - portalA.xyz;
                vec3 vin = vec3(dot(rdp, da), rdp.y, abs(dot(rdp, cross(da, vec3(0.0, 1.0, 0.0)))));
                pv = portalVortex(vec2(dot(rel, da), rel.y), portalB.xy, vin, tp, dist);
            }
            if (portalA.w > 0.0) {
                vec3 wp = mod(worldPos, 4096.0);
                pv = mix(pv, portalFlow(vec2(dot(wp, da), wp.y), tp, dist), portalA.w);
            }
            col = pv.rgb * EMISSIVE_STRENGTH;
            a = pv.a;
        #endif
    } else if (isEmitterCat(cat) || emitLevel > 0.0) {
        col += alb * emitterLight(cat).rgb * 2.5 * EMISSIVE_STRENGTH * lightTypeStrength(cat);
        a = max(a, 0.6);
    }
    #ifdef PROGRAM_HAND_WATER
        // Held items glow like the block they are (ore specks, gem blocks, lamps).
        int ic = heldItemCat(currentRenderedItemId);
        if (ic >= 0) {
            float e = blockGlow(ic, albedo.rgb, isEmitterCat(ic) ? 0.8 : 0.0);
            vec4 el = emitterLight(ic);
            vec3 ea = isOre(ic) ? mix(alb, el.rgb / maxOf(el.rgb) * max(luminance(alb), 0.22), 0.7) : alb;
            col += ea * e * 3.2 * EMISSIVE_STRENGTH * min(el.a, 1.5) * min(lightTypeStrength(ic), 1.5);
        }
    #endif
    // Glass Opacity: from clear to a black pane that only reflects.
    trans *= 1.0 - GLASS_OPACITY;
    if (stained) {
        // Only a little of the glass's own lit colour shows on its face: pale glass
        // looks a touch milky, dark glass hardly at all. The rest is the filter above.
        a = saturate(albedo.a) * (0.06 + 0.22 * luminance(alb));
    }
    outColor = vec4(col, a);
    outWater = vec4(0.0);
    outTint = vec4(0.0);
    outWaterDist = vec4(0.0);
    // Kind: 0 ice, slime, honey; 0.25 stained glass; 0.5 clear glass; 1 portal.
    outGlass = vec4(encodeNormal(N), pack2x8(vec2(lmL.y, portal ? 1.0 : (plainGlass ? 0.5 : (stained ? 0.25 : 0.0)))), 1.0);
    outTrans = vec4(trans, 1.0);
    #ifdef PROGRAM_HAND_WATER
        // Whatever you hold (Minecraft draws most held items in this pass) is not glass:
        // no mirror of the world on it, nothing filtered behind it.
        outGlass = vec4(0.0);
        outTrans = vec4(1.0);
    #endif
}
#endif
