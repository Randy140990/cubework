/*
    Tempered Light - Voxy LOD terrain (patched into Voxy's own GLSL 4.60
    shader). Writes the same G-buffer as vanilla terrain: colortex1, 2, 3.
    Uniforms and samplers come from voxy.json, so none are declared here.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"

layout(location = 0) out vec4 lfAlbedo;
layout(location = 1) out vec4 lfNormal;
layout(location = 2) out vec4 lfMaterial;

vec3 voxyFaceNormal(uint face) {
    uint axis = face >> 1u;
    float s = (face & 1u) == 0u ? -1.0 : 1.0;
    if (axis == 0u) return vec3(0.0, s, 0.0);
    if (axis == 1u) return vec3(0.0, 0.0, s);
    return vec3(s, 0.0, 0.0);
}

void voxy_emitFragment(VoxyFragmentParameters parameters) {
    vec4 c = parameters.sampledColour * parameters.tinting;
    int cat = catFromId(float(parameters.customId));
    vec3 N = voxyFaceNormal(parameters.face);
    vec2 lm = clamp((parameters.lightMap - 1.0 / 32.0) * 16.0 / 15.0, 0.0, 1.0);
    float emission = emissionMask(cat, c.rgb, isEmitterCat(cat) ? 0.8 : 0.0);
    #if GEM_GLOW == 1
        if (isGem(cat)) emission = max(emission, GEM_GLOW_STRENGTH * 0.28);
    #endif
    lfAlbedo = vec4(c.rgb, 1.0);
    lfNormal = vec4(encodeNormal(N), pack2x8(lm), 1.0);
    lfMaterial = vec4(float(cat) / 255.0, 0.0, 0.0, emission);
}
