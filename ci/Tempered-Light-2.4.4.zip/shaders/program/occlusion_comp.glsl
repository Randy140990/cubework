/*
    Tempered Light - finds the blocks Minecraft never draws because they are
    buried (inside the ground, inside thick walls, under floors) and marks them
    solid in the light grid, so light cannot run through the ground beneath a
    floor lamp or a light hidden under carpet and come out somewhere else.

    A cell with nothing drawn in it is buried when a full cube next to it has no
    face drawn towards it: Minecraft only leaves out a full cube's face when the
    block on that side is opaque. It also finds End portals (drawn as block
    entities, so only their faces' corners are known) and makes them light
    sources. Runs before the light spreads.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#define FF_COMPUTE
uniform vec3 cameraPosition;

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#include "/lib/floodfill.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
// Iris reads this line as plain text: literals only.
#if FF_SIZE_XZ == 128
const ivec3 workGroups = ivec3(16, 16, 16);
#else
const ivec3 workGroups = ivec3(8, 8, 8);
#endif

#if USE_FLOODFILL == 1
layout(r32ui) uniform uimage3D lfVoxel;
layout(r32ui) uniform readonly uimage3D lfFaces;
#endif

void main() {
    #if USE_FLOODFILL == 1
        ivec3 v = ivec3(gl_GlobalInvocationID);
        if (!ffInside(v)) return;
        uint here = imageLoad(lfFaces, v).r;
        if ((here & FF_FACE_OCCUPIED) != 0u) return;   // something is drawn here
        #if END_PORTAL_LIST == 1
            // All four corners of an End portal face here: an End portal, giving light.
            if ((here & FF_END_CORNERS) == FF_END_CORNERS) {
                imageAtomicOr(lfVoxel, v, ffPack(15, CAT_END_PORTAL, false, false));
                return;
            }
        #endif
        const ivec3 dirs[6] = ivec3[6](ivec3(1, 0, 0), ivec3(-1, 0, 0), ivec3(0, 1, 0), ivec3(0, -1, 0), ivec3(0, 0, 1), ivec3(0, 0, -1));
        for (int i = 0; i < 6; i++) {
            ivec3 n = v + dirs[i];
            if (!ffInside(n)) continue;
            uint f = imageLoad(lfFaces, n).r;
            bool fullCube = (f & FF_FACE_FULL) != 0u && (f & FF_FACE_NONFULL) == 0u;
            // The neighbour's face that would look at this cell points back along -dir.
            if (fullCube && (f & ffFaceBitDir(-dirs[i])) == 0u) {
                imageAtomicOr(lfVoxel, v, 4096u);    // solid
                return;
            }
        }
    #endif
}
