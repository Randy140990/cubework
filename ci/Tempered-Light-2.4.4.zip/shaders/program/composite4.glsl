/*
    Tempered Light - motion blur from camera movement: each pixel is smeared
    along the path it moved across the screen since last frame. The held item
    and the sky near the cursor stay sharp when you stand still.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/space.glsl"
#include "/lib/taa.glsl"

#ifdef VSH
out vec2 texcoord;
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
}
#endif

#ifdef FSH
uniform sampler2D colortex0;
uniform sampler2D depthtex0;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    vec3 col = texelFetch(colortex0, px, 0).rgb;
    float depth = texelFetch(depthtex0, px, 0).r;
    if (depth < 0.56) { outColor = vec4(col, 1.0); return; }    // held item
    // Where this point was on screen last frame.
    vec3 viewPos = screenToView(texcoord, depth, gbufferProjectionInverse);
    vec3 playerPos = viewToPlayer(viewPos);
    bool sky = depth >= 1.0;
    vec3 prevPlayer = sky ? playerPos : playerPos + cameraPosition - previousCameraPosition;
    vec4 pc = gbufferPreviousProjection * (gbufferPreviousModelView * vec4(prevPlayer, 1.0));
    vec2 prevUV = pc.xy / pc.w * 0.5 + 0.5;
    vec2 vel = (texcoord - prevUV) * MOTION_BLUR_STRENGTH;
    // Per second rather than per frame, so high frame rates don't lose the effect,
    // capped so a fast spin doesn't smear the whole screen.
    vel *= clamp(1.0 / max(frameTime * 60.0, 0.25), 0.5, 2.0);
    float len = length(vel * vec2(viewWidth, viewHeight));
    if (!(len >= 0.5 && len < 1e5)) { outColor = vec4(col, 1.0); return; }   // still, or no valid history
    vel *= min(1.0, 72.0 / len);
    const int N = 14;
    float j = frameDither(gl_FragCoord.xy);
    vec3 sum = col;
    float w = 1.0;
    for (int i = 1; i <= N; i++) {
        vec2 suv = texcoord - vel * ((float(i) - 0.5 + j) / float(N) - 0.5);
        if (any(lessThan(suv, vec2(0.0))) || any(greaterThan(suv, vec2(1.0)))) continue;
        if (texture(depthtex0, suv).r < 0.56) continue;        // don't smear the hand in
        sum += texture(colortex0, suv).rgb;
        w += 1.0;
    }
    outColor = vec4(sum / w, 1.0);
}
#endif
