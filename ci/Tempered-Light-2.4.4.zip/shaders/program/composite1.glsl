/*
    Tempered Light - volumetric clouds over the scene, haze to the far edge,
    light shafts, underwater fog with light rays, Nether/End fog.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl"
#include "/lib/space.glsl"
#include "/lib/materials.glsl"
#include "/lib/wind.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/sky.glsl"

#if !defined DIM_NETHER && !defined DIM_END
    #define DIM_OVERWORLD
#endif

#ifdef VSH
out vec2 texcoord;
flat out vec3 sunDir;
flat out vec3 lightDir;
flat out vec3 lightE;
flat out vec3 skyAmb;
flat out float lodActive;     // 1 when Voxy or Distant Horizons land is on screen
#ifdef VOXY
uniform sampler2D vxDepthTexOpaque;
#endif
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
#endif
#ifdef IRIS_FEATURE_CUSTOM_IMAGES
    // Kept from frame to frame: texel 0 when far land was last seen on screen
    // (frameTimeCounter + 1; 0 = never); texels 1-6 the breathing clock (two copies,
    // read one, write the other, alternating frames).
    layout(rgba32f) uniform image2D lfLod;
    #if defined VOXY || defined DISTANT_HORIZONS
        #define LF_LOD_MEMORY
    #endif
#endif
#include "/lib/breath.glsl"
#if defined IRIS_FEATURE_CUSTOM_IMAGES && defined DIM_OVERWORLD
    // How wet the screen is from rain (read by the final pass, a frame later).
    #define HAS_RAIN_LENS_STATE
    #include "/lib/floodfill.glsl"
    // Rain reaches you: nothing over your head (leaves let a little through).
    float rainOpenAbove() {
        #if USE_FLOODFILL == 1
            ivec3 v = ffVoxelFromWorld(cameraPosition);
            for (int k = 1; k <= 40; k++) {
                ivec3 q = v + ivec3(0, k, 0);
                if (!ffInside(q)) break;
                uint w = texelFetch(lfVoxelSampler, q, 0).r;
                if (ffSolid(w)) return 0.0;
                if (ffPartial(w) && ffCat(w) == CAT_LEAVES) return 0.25;
            }
        #endif
        return 1.0;
    }
#endif
#ifdef HAS_BREATH
flat out vec4 breathB;       // start of the last breath, how visible, seed, how hard
flat out vec3 breathOrg;     // your mouth, relative to the camera
flat out vec3 breathDir;     // which way you breathed it out
#endif
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    // Look over a grid of the screen for far land drawn by Voxy or DH.
    lodActive = 0.0;
    #if defined VOXY || defined DISTANT_HORIZONS
        for (int y = 0; y < 24; y++) {
            for (int x = 0; x < 32; x++) {
                vec2 g = (vec2(x, y) + 0.5) / vec2(32.0, 24.0);
                #ifdef VOXY
                    if (texture(vxDepthTexOpaque, g).r < 1.0) lodActive = 1.0;
                #endif
                #ifdef DISTANT_HORIZONS
                    if (texture(dhDepthTex0, g).r < 1.0) lodActive = 1.0;
                #endif
            }
        }
        #ifdef LF_LOD_MEMORY
            // Far land can drop off screen for a moment (looking at the sky or the ground
            // nearby): keep treating it as there for a few seconds, so the edge of the
            // normal render distance doesn't flick in and out of the haze as you turn.
            float seen = imageLoad(lfLod, ivec2(0)).r;
            float nowT = frameTimeCounter + 1.0;
            if (lodActive > 0.5) {
                imageStore(lfLod, ivec2(0), vec4(nowT));
            } else if (seen > 0.0) {
                float since = nowT - seen;
                if (since < 0.0) since = nowT + 3600.0 - seen;   // Iris's hourly clock reset
                if (since < 6.0) lodActive = 1.0;
            }
        #endif
    #endif
    #ifdef HAS_BREATH
        // The breathing clock: a breath every 10 s or so, every 3-4 s after a sprint.
        int rp = frameCounter & 1, wp = 1 - rp;
        vec4 st = imageLoad(lfLod, ivec2(1 + rp, 0));   // x clock (0..1), y start, z visibility, w seed
        vec4 og = imageLoad(lfLod, ivec2(3 + rp, 0));   // xyz mouth (relative to the camera), w how hard
        vec4 dr = imageLoad(lfLod, ivec2(5 + rp, 0));   // xyz direction
        breathClock(st, og, dr, clamp(frameTime, 0.0, 0.25), saturate(lfExert));
        if (gl_VertexID == 0) {
            imageStore(lfLod, ivec2(1 + wp, 0), st);
            imageStore(lfLod, ivec2(3 + wp, 0), og);
            imageStore(lfLod, ivec2(5 + wp, 0), dr);
        }
        breathB = vec4(st.y, st.z, st.w, og.w);
        breathOrg = og.xyz;
        breathDir = dr.xyz;
    #endif
    #ifdef HAS_RAIN_LENS_STATE
    {
        int rq = frameCounter & 1, wq = 1 - rq;
        float wl = imageLoad(lfLod, ivec2(7 + rq, 0)).r;
        if (!(wl >= 0.0 && wl <= 1.0)) wl = 0.0;
        float target = 0.0;
        if (RAIN_ON_SCREEN > 0.0 && isEyeInWater == 0) {
            float open = rainOpenAbove() * smoothstep(0.7, 0.92, float(eyeBrightnessSmooth.y) / 240.0);
            // More of it lands on the lens looking up into the rain.
            float up = (mat3(gbufferModelViewInverse) * vec3(0.0, 0.0, -1.0)).y;
            target = lfRainHere * rainStrength * belowCloudDeck() * open * (0.55 + 0.45 * smoothstep(-0.3, 0.6, up));
        }
        // Wet within a second or two in the rain; dries over several seconds under cover.
        float hl = target > wl ? 1.2 : 6.0;
        wl += (target - wl) * (1.0 - exp2(-clamp(frameTime, 0.0, 0.25) / hl));
        if (gl_VertexID == 0) imageStore(lfLod, ivec2(7 + wq, 0), vec4(wl, 0.0, 0.0, 0.0));

        // Frost on the screen: creeps in from the edges in the cold (about 15 s), backs
        // off as you warm up near a fire or a lamp, or leave the cold (about 15 s).
        float fr = imageLoad(lfLod, ivec2(9 + rq, 0)).r;
        if (!(fr >= 0.0 && fr <= 1.0)) fr = 0.0;
        float ftarget = 0.0;
        if (SCREEN_FROST > 0.0 && isEyeInWater == 0) {
            float cold = saturate(max(lfCold, lfSnowHere));
            float night = 1.0 - smoothstep(-0.12, 0.15, normalize(mat3(gbufferModelViewInverse) * sunPosition).y);
            float heat = smoothstep(0.45, 0.8, float(eyeBrightnessSmooth.x) / 240.0);
            ftarget = saturate(cold * (0.75 + 0.15 * night + 0.25 * snowStormHere())) * (1.0 - heat) * smoothstep(0.6, 0.9, cold);
        }
        float fdt = clamp(frameTime, 0.0, 0.25);
        fr += clamp(ftarget - fr, -fdt / 15.0, fdt / 15.0);
        if (gl_VertexID == 0) imageStore(lfLod, ivec2(9 + wq, 0), vec4(fr, 0.0, 0.0, 0.0));
    }
    #endif
    #ifdef DIM_OVERWORLD
        sunDir = worldSunDir();
        lightDir = worldLightDir();
        lightE = directLightIrradiance(sunDir);
        skyAmb = skyAmbientFromLut();
    #else
        sunDir = vec3(0.0, -1.0, 0.0); lightDir = vec3(0.0, 1.0, 0.0); lightE = vec3(0.0); skyAmb = vec3(0.05);
        #ifdef DIM_END
            lightDir = normalize(END_HOLE_DIR);
            lightE = vec3(0.86, 0.66, 1.0) * 1.35 * END_GLOW * (1.0 + 0.7 * END_STORM);
        #endif
    #endif
}
#endif

#ifdef FSH
#include "/lib/water.glsl"
#include "/lib/shadows.glsl"
#include "/lib/clouds.glsl"
#include "/lib/floodfill.glsl"
#include "/lib/fog.glsl"
#include "/lib/particles.glsl"
#include "/lib/lightning.glsl"
#include "/lib/rainbow.glsl"
#define SMOKE_RENDER
#include "/lib/smokeplume.glsl"
#include "/lib/breath.glsl"
#include "/lib/portal.glsl"
#include "/lib/endportal.glsl"
#ifdef HAS_BREATH
flat in vec4 breathB;
flat in vec3 breathOrg;
flat in vec3 breathDir;
#endif

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
#ifdef VOXY
uniform sampler2D vxDepthTexOpaque;
uniform sampler2D vxDepthTexTrans;
#endif
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
#endif

in vec2 texcoord;
flat in vec3 sunDir;
flat in vec3 lightDir;
flat in vec3 lightE;
flat in vec3 skyAmb;
flat in float lodActive;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    vec2 uv = texcoord;
    vec3 col = texelFetch(colortex0, px, 0).rgb;
    float d0 = texelFetch(depthtex0, px, 0).r;
    float dither = frameDither(gl_FragCoord.xy);

    bool isSky = true;
    vec3 viewPos = screenToView(uv, 1.0, gbufferProjectionInverse);
    if (d0 < 1.0) { isSky = false; viewPos = screenToView(uv, d0, gbufferProjectionInverse); }
    #ifdef VOXY
        if (isSky) {
            float vd = min(texelFetch(vxDepthTexOpaque, px, 0).r, texelFetch(vxDepthTexTrans, px, 0).r);
            if (vd < 1.0) { isSky = false; viewPos = screenToView(uv, vd, vxProjInv); }
        }
    #endif
    #ifdef DISTANT_HORIZONS
        if (isSky) {
            float dd = texelFetch(dhDepthTex0, px, 0).r;
            if (dd < 1.0) { isSky = false; viewPos = screenToView(uv, dd, dhProjectionInverse); }
        }
    #endif
    vec3 playerPos = viewToPlayer(viewPos);
    vec3 rd = normalize(playerPos);
    float dist = isSky ? 1e6 : length(playerPos);

    if (isEyeInWater == 1) {
        col = applyWaterFog(col, rd, min(dist, 512.0), skyAmb, lightE, lightDir, dither);
    } else if (isEyeInWater == 2) {
        float T = exp(-dist * 1.2);
        col = col * T + vec3(1.0, 0.25, 0.03) * 1.5 * (1.0 - T);
    } else if (isEyeInWater == 3) {
        float T = exp(-dist * 0.9);
        col = col * T + vec3(0.6, 0.7, 0.8) * skyAmb * 3.0 * (1.0 - T);
    } else {
        #ifdef HAS_PORTAL_MIST
            // The glowing mist round Nether portals (under the fog, so far ones fade).
            col = applyPortalMists(col, rd, dist, dither);
        #endif
        #if END_PORTAL_LIST == 1
            // Vapour and sparks rising out of End portals.
            col = applyEndPortalBreath(col, rd, dist, dither);
        #endif
        #if defined DIM_OVERWORLD
            // Order matters: clouds behind the haze over the sky, in front of the
            // haze over far terrain, and the ground fog and light shafts over both.
            vec4 cl = vec4(0.0, 0.0, 0.0, 1.0);
            #if CLOUD_MODE == 1 || CLOUD_MODE == 2 || CLOUD_MODE == 5
                vec3 ambTop = skyAmb * 1.1;
                vec3 ambBottom = skyAmb * 0.32 + lightE * 0.02 * max(lightDir.y, 0.0);
                cl = renderClouds(cameraPosition, rd, dist, cloudLightDir(sunDir), cloudLightIrradiance(sunDir), ambTop, ambBottom, CLOUD_QUALITY, dither);
                if (isSky && rd.y >= 0.0) col = col * cl.a + cl.rgb;
            #endif
            // Where the drawn world ends: Voxy's or Distant Horizons' distance while they are
            // drawing land, otherwise Minecraft's own render distance (so the edge of the
            // world melts into the haze even with Voxy installed but switched off).
            float farEnd = lodActive > 0.5 ? farDistance() : far;
            if (!isSky) gSunVis = sunVisAlongRay(rd, dist, dither);
            col = applyAirFog(col, rd, dist, isSky, skyAmb, lightE, lightDir, farEnd);
            // Over land, and over the sky below the horizon (which the haze fills in
            // to hide the world's edge), clouds go in front of the haze.
            if (!isSky || rd.y < 0.0) col = col * cl.a + cl.rgb;
            col = applyGroundFog(col, rd, dist, skyAmb, lightE, lightDir, dither);
            #if RAINBOW == 1
                // After rain, a rainbow stands in front of the clouds and far hills
                // opposite the sun, but only while the sun is out and shining on you.
                if (sunDir.y > 0.0 && (isSky || dist > 80.0)) {
                    float sunOut = cloudShadow(cameraPosition, sunDir) * smoothstep(0.35, 0.8, eyeSkyLight());
                    if (sunOut > 0.01) col += rainbow(rd, sunDir, lightE / SUN_ILLUMINANCE) * sunOut * (isSky ? 1.0 : smoothstep(80.0, 220.0, dist));
                }
            #endif
            col += airVolumetricLight(rd, isSky ? 96.0 : dist, lightE, lightDir, dither);
            col += cloudGodRays(rd, dist, lightDir, lightE, dither);
            col = applyBlizzard(col, rd, dist, skyAmb, lightE);
            #ifdef HAS_SMOKE_PLUMES
                col = applySmokePlumes(col, rd, dist, skyAmb, lightE, lightDir, dither);
            #endif
            #ifdef HAS_BREATH
                col = applyBreath(col, rd, dist, breathB, breathOrg, breathDir, skyAmb, lightE, lightDir, dither);
            #endif
            #ifdef HAS_REAL_LIGHTNING
                col += lightningBolt(rd, isSky ? 1e6 : dist);
            #endif
        #elif defined DIM_NETHER
            if (!isSky) col = netherFog(col, dist, rd);
            col = netherMist(col, rd, dist, dither);
            col = applyNetherParticles(col, rd, dist);
            #ifdef HAS_SMOKE_PLUMES
                col = applySmokePlumes(col, rd, dist, otherDimAmbient() * 1.5 + netherGlow(cameraPosition.y) * 0.6, vec3(0.0), vec3(0.0, 1.0, 0.0), dither);
            #endif
        #else
            if (!isSky) col = endFog(col, dist);
            col = endMist(col, rd, dist, dither, lightDir, lightE);
            col = endStorm(col, rd, dist, dither, lightDir, lightE);
            col += endStormRays(rd, dist, dither, lightDir, lightE);
            #ifdef HAS_SMOKE_PLUMES
                col = applySmokePlumes(col, rd, dist, otherDimAmbient(), lightE, lightDir, dither);
            #endif
            #ifdef HAS_BREATH
                col = applyBreath(col, rd, dist, breathB, breathOrg, breathDir, otherDimAmbient() * 2.0, lightE, lightDir, dither);
            #endif
        #endif
    }

    // Blindness and the Darkness effect.
    float dark = max(blindness, darknessFactor);
    if (dark > 0.0) col *= mix(1.0, exp(-min(dist, 64.0) * 0.4), dark);

    outColor = vec4(col, 1.0);
}
#endif
