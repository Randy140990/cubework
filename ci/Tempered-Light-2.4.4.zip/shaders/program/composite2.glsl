/*
    Tempered Light - temporal anti-aliasing. Blends each pixel with where it
    was last frame, clamped to what is around it now, so edges are smooth and
    the per-frame noise in shadows, reflections, fog and clouds averages out.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/space.glsl"
#include "/lib/materials.glsl"

#ifdef VSH
out vec2 texcoord;
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
}
#endif

#ifdef FSH
uniform sampler2D colortex0;
uniform sampler2D colortex3;
uniform sampler2D colortex10;
uniform sampler2D depthtex0;
#ifdef VOXY
uniform sampler2D vxDepthTexOpaque;
uniform sampler2D vxDepthTexTrans;
#endif
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
#endif

in vec2 texcoord;

/* RENDERTARGETS: 0,10 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outHistory;

vec3 toYCoCg(vec3 c) {
    return vec3(0.25 * c.r + 0.5 * c.g + 0.25 * c.b, 0.5 * c.r - 0.5 * c.b, -0.25 * c.r + 0.5 * c.g - 0.25 * c.b);
}
vec3 fromYCoCg(vec3 c) {
    return vec3(c.x + c.y - c.z, c.x + c.z, c.x - c.y - c.z);
}
// Compress bright values so a few hot pixels don't dominate the blend.
vec3 tmap(vec3 c) { return c / (1.0 + luminance(c)); }
vec3 itmap(vec3 c) { return c / max(1.0 - luminance(c), 1e-3); }

// A broken value (not a number, or infinite) would stick in the history and show
// as a black speck that crawls around: drop it.
vec3 safeColor(vec3 c) {
    return (any(isnan(c)) || any(isinf(c))) ? vec3(0.0) : max(c, 0.0);
}

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    vec3 cur = safeColor(texelFetch(colortex0, px, 0).rgb);
    #if TAA >= 1
        // Neighbourhood of the current frame (in compressed YCoCg).
        vec3 mn = vec3(1e9), mx = vec3(-1e9), m1 = vec3(0.0), m2 = vec3(0.0);
        for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) {
            vec3 c = toYCoCg(tmap(safeColor(texelFetch(colortex0, clamp(px + ivec2(x, y), ivec2(0), ivec2(viewWidth, viewHeight) - 1), 0).rgb)));
            mn = min(mn, c); mx = max(mx, c); m1 += c; m2 += c * c;
        }
        m1 /= 9.0;
        vec3 sd = sqrt(max(m2 / 9.0 - m1 * m1, 0.0));
        #if TAA == 2
            const float clampK = 1.7;     // Strong: smoother, a little more smudging
        #else
            const float clampK = 1.25;
        #endif
        vec3 bmn = mn, bmx = mx;                 // the whole neighbourhood
        mn = max(mn, m1 - sd * clampK); mx = min(mx, m1 + sd * clampK);

        // Where was this pixel last frame?
        float depth = texelFetch(depthtex0, px, 0).r;
        int cat = int(texelFetch(colortex3, px, 0).r * 255.0 + 0.5);
        bool hand = depth < 0.56 || cat == CAT_HAND;
        vec2 prevUV = texcoord;
        if (!hand) {
            vec3 viewPos = screenToView(texcoord, depth, gbufferProjectionInverse);
            // Distant Horizons / Voxy terrain is real geometry too: reproject it with
            // the camera's movement, not like the sky.
            bool farPx = depth >= 1.0;
            #ifdef DISTANT_HORIZONS
                if (farPx) { float dd = texelFetch(dhDepthTex0, px, 0).r; if (dd < 1.0) { viewPos = screenToView(texcoord, dd, dhProjectionInverse); farPx = false; } }
            #endif
            #ifdef VOXY
                if (farPx) {
                    float vd = min(texelFetch(vxDepthTexOpaque, px, 0).r, texelFetch(vxDepthTexTrans, px, 0).r);
                    if (vd < 1.0) { viewPos = screenToView(texcoord, vd, vxProjInv); farPx = false; }
                }
            #endif
            vec3 playerPos = viewToPlayer(viewPos);
            vec3 prevPlayer = farPx ? playerPos : playerPos + cameraPosition - previousCameraPosition;
            vec4 pc = gbufferPreviousProjection * (gbufferPreviousModelView * vec4(prevPlayer, 1.0));
            prevUV = pc.xy / pc.w * 0.5 + 0.5;
        }
        bool onScreen = all(greaterThanEqual(prevUV, vec2(0.0))) && all(lessThanEqual(prevUV, vec2(1.0)));
        vec3 hist = toYCoCg(tmap(safeColor(texture(colortex10, prevUV).rgb)));
        float speed = length((prevUV - texcoord) * vec2(viewWidth, viewHeight));
        // Still, or nearly: let the history keep detail finer than a pixel (far shadows,
        // thin edges seen from high up) that this frame's jittered samples may have
        // missed nearby, instead of clamping it away and letting it flicker on and off.
        float still = 1.0 - smoothstep(0.2, 1.2, speed);
        vec3 ext = (bmx - bmn) * 0.1;
        mn = mix(mn, bmn - ext, still); mx = mix(mx, bmx + ext, still);
        hist = clamp(hist, mn, mx);
        #if TAA == 2
            float wMax = 0.94;
        #else
            float wMax = 0.9;
        #endif
        float w = onScreen ? (hand ? 0.6 : wMax + 0.035 * still - min(speed * 0.015, 0.25)) : 0.0;
        vec3 res = itmap(fromYCoCg(mix(toYCoCg(tmap(cur)), hist, w)));
        res = max(res, 0.0);
        outColor = vec4(res, 1.0);
        outHistory = vec4(res, 1.0);
    #else
        outColor = vec4(cur, 1.0);
        outHistory = vec4(cur, 1.0);
    #endif
}
#endif
