/*
    Tempered Light - finds the fires that smoke (Smoke Style: Realistic).
    SMOKE_PASS_SCAN: one thread per column of the light grid notes the topmost lit
    campfire or fire with air above it, how far a chimney walls it in and how much
    room there is under a roof, keeping one fire per 4x4-block cell.
    SMOKE_PASS_LIST: lists the 16 nearest of those cells for the composite pass.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#define FF_COMPUTE
uniform vec3 cameraPosition;

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#include "/lib/floodfill.glsl"
#include "/lib/smokeplume.glsl"

#ifdef SMOKE_PASS_SCAN
layout(local_size_x = 8, local_size_y = 8, local_size_z = 1) in;
// Iris reads this line as plain text: literals only.
#if FF_SIZE_XZ == 128
const ivec3 workGroups = ivec3(16, 16, 1);
#else
const ivec3 workGroups = ivec3(8, 8, 1);
#endif
#else
layout(local_size_x = 256, local_size_y = 1, local_size_z = 1) in;
const ivec3 workGroups = ivec3(1, 1, 1);
#endif

#ifdef HAS_SMOKE_PLUMES
layout(r32ui) uniform uimage2D lfSmoke;
#ifdef SMOKE_PASS_SCAN
layout(r32ui) uniform readonly uimage3D lfVoxel;

bool solidAt(ivec3 v) {
    if (!ffInside(v)) return false;
    return ffSolid(imageLoad(lfVoxel, v).r);
}
#else
shared uint listCount;
#endif
#endif

void main() {
    #ifdef HAS_SMOKE_PLUMES
    #ifdef SMOKE_PASS_SCAN
        ivec2 c = ivec2(gl_GlobalInvocationID.xy);
        if (any(greaterThanEqual(c, FF_SIZE.xz))) return;
        int roof = FF_SIZE.y + 31;          // nothing above the grid: open sky
        for (int y = FF_SIZE.y - 1; y >= 0; y--) {
            uint w = imageLoad(lfVoxel, ivec3(c.x, y, c.y)).r;
            if (w == 0u) continue;
            int kind = smokeKind(ffCat(w));
            if (ffLevel(w) > 0 && kind >= 0) {
                int air = roof - y - 1;
                if (air < 1) return;
                // A chimney: blocks above the fire walled in on at least three sides.
                int chimney = 0;
                for (int k = 1; k <= 15; k++) {
                    if (y + k >= roof) break;
                    ivec3 a = ivec3(c.x, y + k, c.y);
                    int walls = int(solidAt(a + ivec3(1, 0, 0))) + int(solidAt(a - ivec3(1, 0, 0))) +
                                int(solidAt(a + ivec3(0, 0, 1))) + int(solidAt(a - ivec3(0, 0, 1)));
                    if (walls < 3) break;
                    chimney = k;
                }
                imageAtomicMax(lfSmoke, c / 4, smokePack(kind, ivec3(c.x, y, c.y), air, chimney));
                return;
            }
            if (ffSolid(w)) roof = y;
        }
    #else
        uint lid = gl_LocalInvocationID.x;
        if (lid == 0u) listCount = 0u;
        memoryBarrierShared();
        barrier();
        const int CELLS = SMOKE_NC * SMOKE_NC;
        vec2 mid = vec2(FF_SIZE.xz / 2) + 0.5;
        // Nearest first: four rings by distance from you.
        for (int ring = 0; ring < 4; ring++) {
            float r0 = ring == 0 ? 0.0 : ring == 1 ? 12.0 : ring == 2 ? 24.0 : 40.0;
            float r1 = ring == 0 ? 12.0 : ring == 1 ? 24.0 : ring == 2 ? 40.0 : 1e9;
            for (int i = int(lid); i < CELLS; i += 256) {
                ivec2 cc = ivec2(i % SMOKE_NC, i / SMOKE_NC);
                uint w = imageLoad(lfSmoke, cc).r;
                if (w == 0u) continue;
                float d = length(vec2(smokeCell(w).xz) + 0.5 - mid);
                if (d < r0 || d >= r1) continue;
                uint idx = atomicAdd(listCount, 1u);
                if (idx < uint(SMOKE_MAX)) imageStore(lfSmoke, ivec2(int(idx), SMOKE_NC), uvec4(w));
            }
            memoryBarrierShared();
            barrier();
        }
    #endif
    #endif
}
