/*
    Tempered Light - finds the portals near you. One thread per column of the light
    grid looks for:
    - Nether portals (Portal Style Vortex or Rift): the bottom corner of each (the
      portal block with no portal below it and none on its low side); it measures
      how wide and tall the portal is and lists it in a spare row of the smoke
      image, for the portal's vortex and its mist. Portals running out of the light
      grid are left out (their middle is unknown).
    - End portals (End Portal Style Void): the first cell of each pool (none before
      it in its row or the rows in front); it lists the pool's outline in the next
      row, for the vapour and sparks rising out of it.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#define FF_COMPUTE
uniform vec3 cameraPosition;

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#include "/lib/floodfill.glsl"
#include "/lib/portal.glsl"
#include "/lib/endportal.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 1) in;
// Iris reads this line as plain text: literals only.
#if FF_SIZE_XZ == 128
const ivec3 workGroups = ivec3(16, 16, 1);
#else
const ivec3 workGroups = ivec3(8, 8, 1);
#endif

#if PORTAL_LIST == 1 || END_PORTAL_LIST == 1
layout(r32ui) uniform uimage2D lfSmoke;
layout(r32ui) uniform readonly uimage3D lfVoxel;

bool portalAt(ivec3 v) {
    return ffInside(v) && ffCat(imageLoad(lfVoxel, v).r) == CAT_PORTAL;
}
bool endAt(ivec3 v) {
    return ffInside(v) && ffCat(imageLoad(lfVoxel, v).r) == CAT_END_PORTAL;
}
#endif

void main() {
    #if PORTAL_LIST == 1
    {
        ivec2 c = ivec2(gl_GlobalInvocationID.xy);
        if (any(greaterThanEqual(c, FF_SIZE.xz))) return;
        for (int y = 1; y < FF_SIZE.y - 1; y++) {
            ivec3 v = ivec3(c.x, y, c.y);
            if (ffCat(imageLoad(lfVoxel, v).r) != CAT_PORTAL) continue;
            if (portalAt(v - ivec3(0, 1, 0))) continue;
            // Which way it runs: along x unless its neighbours are along z.
            bool alongX = portalAt(v + ivec3(1, 0, 0)) || portalAt(v - ivec3(1, 0, 0));
            bool alongZ = portalAt(v + ivec3(0, 0, 1)) || portalAt(v - ivec3(0, 0, 1));
            int axis = (!alongX && alongZ) ? 1 : 0;
            ivec3 a = axis == 0 ? ivec3(1, 0, 0) : ivec3(0, 0, 1);
            // Only its low corner, and only if the grid holds the whole portal.
            if (!ffInside(v - a) || portalAt(v - a)) continue;
            int w = 1;
            while (w < 32 && portalAt(v + a * w)) w++;
            int h = 1;
            while (h < 32 && portalAt(v + ivec3(0, h, 0))) h++;
            if (ffInside(v + a * w) && ffInside(v + ivec3(0, h, 0))) {
                uint i = imageAtomicAdd(lfSmoke, ivec2(0, PORTAL_ROW), 1u);
                if (i < uint(PORTAL_MAX)) imageStore(lfSmoke, ivec2(1 + int(i), PORTAL_ROW), uvec4(portalPack(v, axis, w, h), 0u, 0u, 0u));
            }
            y += h - 1;      // the rest of this portal's column has no corner
        }
    }
    #endif
    #if END_PORTAL_LIST == 1
        ivec2 ce = ivec2(gl_GlobalInvocationID.xy);
        if (any(greaterThanEqual(ce, FF_SIZE.xz))) return;
        for (int y = 0; y < FF_SIZE.y; y++) {
            ivec3 v = ivec3(ce.x, y, ce.y);
            if (ffCat(imageLoad(lfVoxel, v).r) != CAT_END_PORTAL) continue;
            // The pool's first cell: no End portal before it in its row, nor in the rows
            // in front (within reach of the biggest pools).
            bool first = true;
            for (int dz = -END_POOL_REACH; dz <= 0 && first; dz++)
                for (int dx = -END_POOL_REACH; dx <= (dz < 0 ? END_POOL_REACH : -1) && first; dx++)
                    if (endAt(v + ivec3(dx, 0, dz))) first = false;
            if (!first) continue;
            // Its outline: every End portal cell around it at the same height.
            ivec2 lo = v.xz, hi = v.xz;
            for (int dz = 0; dz <= 2 * END_POOL_REACH; dz++)
                for (int dx = -END_POOL_REACH; dx <= 2 * END_POOL_REACH; dx++)
                    if (endAt(v + ivec3(dx, 0, dz))) { lo = min(lo, v.xz + ivec2(dx, dz)); hi = max(hi, v.xz + ivec2(dx, dz)); }
            uint i = imageAtomicAdd(lfSmoke, ivec2(0, END_ROW), 1u);
            if (i < uint(END_POOL_MAX)) imageStore(lfSmoke, ivec2(1 + int(i), END_ROW), uvec4(endPoolPack(ivec3(lo.x, y, lo.y), hi - lo + 1), 0u, 0u, 0u));
        }
    #endif
}
