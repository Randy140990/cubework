/*
    Tempered Light - Distant Horizons terrain: writes the same G-buffer as vanilla terrain so
    far land is lit and fogged the same way.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/program/dh_common.glsl"

#ifdef FSH
/* RENDERTARGETS: 1,2,3 */
layout(location = 0) out vec4 outAlbedo;
layout(location = 1) out vec4 outNormal;
layout(location = 2) out vec4 outMaterial;

void main() {
    dhNearDiscard();
    vec3 N = normalize(normalW);
    vec3 worldPos = playerPos + cameraPosition;
    // A little block-scale variation so far land isn't flat colour.
    float v = hash13(floor(worldPos + N * 0.5)) * 0.12 - 0.06;
    vec3 albedo = saturate(vcol.rgb * (1.0 + v));
    float emission = cat == CAT_EMITTER || cat == CAT_LAVA ? 0.6 : 0.0;
    outAlbedo = vec4(albedo, 1.0);
    outNormal = vec4(encodeNormal(N), pack2x8(lm), 1.0);
    outMaterial = vec4(float(cat) / 255.0, 0.0, 0.0, emission);
}
#endif
