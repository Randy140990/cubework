/*
    Tempered Light - water (refraction, depth colour, foam, reflections and
    the sun's glitter path), glass reflections and wet-surface reflections.
    Water and glass data come from separate targets (see gbuffers_water.glsl),
    so water behind a window or under ice is still shaded as water.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl"
#include "/lib/space.glsl"
#include "/lib/materials.glsl"
#include "/lib/wind.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/sky.glsl"

#if !defined DIM_NETHER && !defined DIM_END
    #define DIM_OVERWORLD
#endif

#ifdef VSH
out vec2 texcoord;
flat out vec3 sunDir;
flat out vec3 lightDir;
flat out vec3 lightE;
flat out vec3 skyAmb;
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    #ifdef DIM_OVERWORLD
        sunDir = worldSunDir();
        lightDir = worldLightDir();
        lightE = directLightIrradiance(sunDir);
        skyAmb = skyAmbientFromLut();
    #else
        sunDir = vec3(0.0, -1.0, 0.0); lightDir = vec3(0.0, 1.0, 0.0); lightE = vec3(0.0);
        skyAmb = otherDimAmbient();
    #endif
}
#endif

#ifdef FSH
#include "/lib/water.glsl"
#include "/lib/shadows.glsl"
#include "/lib/clouds.glsl"
#include "/lib/lighting.glsl"
#include "/lib/ssr.glsl"
#include "/lib/fog.glsl"
#ifdef DIM_OVERWORLD
    #include "/lib/floodfill.glsl"
    #include "/lib/leaves.glsl"
#endif

uniform sampler2D colortex0;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex7;
uniform sampler2D colortex8;
uniform sampler2D colortex9;
uniform sampler2D colortex11;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
#ifdef VOXY
uniform sampler2D vxDepthTexOpaque;
uniform sampler2D vxDepthTexTrans;
#endif
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
uniform sampler2D dhDepthTex1;
#endif

in vec2 texcoord;
flat in vec3 sunDir;
flat in vec3 lightDir;
flat in vec3 lightE;
flat in vec3 skyAmb;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

int reflectionSteps() {
    return WATER_REFLECTIONS <= 1 ? 16 : WATER_REFLECTIONS == 2 ? 24 : 40;
}

// What a reflected ray sees when it leaves the screen.
vec3 skyReflection(vec3 R, float skyLight) {
    #ifdef DIM_OVERWORLD
        vec3 r = normalize(vec3(R.x, max(R.y, 0.02), R.z));
        vec3 s = skyPanoramaClouds(r);
        float occl = pow(skyLight, 3.0);
        return mix(skyAmb * 0.08, s, occl);
    #else
        return skyAmb * 0.5;
    #endif
}

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    vec2 uv = texcoord;
    vec3 col = texelFetch(colortex0, px, 0).rgb;
    vec4 wdata = texelFetch(colortex4, px, 0);
    vec4 gdata = texelFetch(colortex9, px, 0);
    bool hasWater = wdata.a > 0.5;
    bool hasGlass = gdata.a > 0.5;
    float d0 = texelFetch(depthtex0, px, 0).r;
    float d1 = texelFetch(depthtex1, px, 0).r;
    float dither = frameDither(gl_FragCoord.xy);
    // Minecraft's own water and glass always sit in front of what is behind them
    // (d0 < d1). Where the nearest thing is solid (the item in your hand, land), any
    // water or glass data here was left by the Voxy LODs far behind it: ignore it, or
    // far-off seas and rivers show through what you're holding.
    // (Held items sit at depth < 0.56; see-through ones are only in depthtex0.)
    if (d0 < 0.56 || (d0 < 1.0 && d0 >= d1)) { hasWater = false; hasGlass = false; }

    // ------------------------------------------------ surface position ----
    // viewPos0: nearest translucent surface (or LOD surface); viewPos1: what is behind it.
    bool lod = false;
    vec3 viewPos0 = screenToView(uv, d0, gbufferProjectionInverse);
    vec3 viewPos1 = screenToView(uv, d1, gbufferProjectionInverse);
    if ((hasWater || hasGlass) && d0 >= 1.0) {
        lod = true;
        #ifdef VOXY
            float vt = texelFetch(vxDepthTexTrans, px, 0).r, vo = texelFetch(vxDepthTexOpaque, px, 0).r;
            if (vt < 1.0) { viewPos0 = screenToView(uv, vt, vxProjInv); viewPos1 = screenToView(uv, vo, vxProjInv); }
        #endif
        #ifdef DISTANT_HORIZONS
            float dt = texelFetch(dhDepthTex0, px, 0).r, dop = texelFetch(dhDepthTex1, px, 0).r;
            if (dt < 1.0) { viewPos0 = screenToView(uv, dt, dhProjectionInverse); viewPos1 = screenToView(uv, dop, dhProjectionInverse); }
        #endif
    }
    vec3 playerPos0 = viewToPlayer(viewPos0);
    float dist0 = length(playerPos0);
    vec3 rd = normalize(playerPos0);
    vec3 V = -rd;

    // Glass, ice or a particle drawn in front of the water: place the water surface
    // from its stored distance instead of the nearest depth.
    float wDist = texelFetch(colortex8, px, 0).r;
    bool waterBehind = hasWater && !lod && wDist > 0.0 && wDist > dist0 + max(0.2, dist0 * 0.02);
    #if PORTAL_STYLE != 0
        // A vortex portal hides whatever is behind it: no water shading through it.
        if (waterBehind && hasGlass && unpack2x8(gdata.b).y > 0.75) { hasWater = false; waterBehind = false; }
    #endif

    if (hasWater) {
        // ------------------------------------------------------- water ----
        vec3 playerPosW = waterBehind ? rd * wDist : playerPos0;
        vec3 viewPosW = waterBehind ? playerToView(playerPosW) : viewPos0;
        vec3 worldPosW = playerPosW + cameraPosition;
        float distW = waterBehind ? wDist : dist0;

        vec3 N = decodeNormal(wdata.rg);            // already faces the camera
        if (lod) {
            N = waterNormal(worldPosW, distW);
            if (worldPosW.y > cameraPosition.y) N = -N;
        }
        vec2 skyTex = unpack2x8(wdata.b);
        #ifdef DIM_OVERWORLD
            float skyLight = skyTex.x;
        #else
            float skyLight = 1.0;
        #endif
        // texLum carries a "flowing water" flag in its top bit (set in gbuffers_water).
        float tl8 = floor(skyTex.y * 255.0 + 0.5);
        bool flowing = tl8 >= 128.0;
        float texLum = mod(tl8, 128.0) / 127.0;
        bool below = isEyeInWater == 1;
        vec3 Nv = mat3(gbufferModelView) * N;
        float waterDepth = (d1 >= 1.0 && !lod) ? 64.0 : distance(viewPosW, viewPos1);
        if (lod && viewPos1.z <= -1e5) waterDepth = 64.0;

        // Refraction: bend the view a little, never onto things in front of the water.
        vec2 refrUV = uv;
        if (!lod && !waterBehind) {
            // From below the surface bends the world above much more strongly.
            float refr = below ? 0.09 : 0.035 * saturate(waterDepth / 3.0);
            refrUV = uv + Nv.xy * refr / max(distW * 0.06, 1.0);
            float dR0 = texture(depthtex0, refrUV).r;
            if (dR0 < d0 - 1e-5) refrUV = uv;
        }
        vec3 behind = texture(colortex0, refrUV).rgb;
        // Glass beyond the water surface (an aquarium wall, a window under the sea)
        // filters what is behind it.
        if (hasGlass && !waterBehind) behind *= texture(colortex11, refrUV).rgb;
        if (below) {
            // The world above, seen through a moving surface, is never quite sharp.
            float br = (1.5 + 0.35 * distW) / viewHeight;
            vec2 asp = vec2(viewHeight / viewWidth, 1.0);
            for (int k = 0; k < 6; k++) {
                float a = float(k) * 1.0472 + dither * 6.2832;
                behind += texture(colortex0, refrUV + vec2(cos(a), sin(a)) * br * asp).rgb;
            }
            behind /= 7.0;
        }
        if (!lod && !below && !waterBehind) {
            float dR1 = texture(depthtex1, refrUV).r;
            if (dR1 < 1.0) waterDepth = mix(waterDepth, distance(viewPosW, screenToView(refrUV, dR1, gbufferProjectionInverse)), 0.7);
        }

        vec3 tint = texelFetch(colortex7, px, 0).rgb;
        // From below, the sky and the world above squeeze into Snell's window and
        // look brighter (radiance gains n squared entering the water).
        vec3 body = below ? behind * 1.78 : behind;
        vec3 uwFog = vec3(0.0);
        float falling = 0.0;      // sides of waterfalls and fountains
        // Seen from below, the surface overhead is Snell's window; the side of a column
        // of water next to air (or a waterfall's edge) is just a thin, clear layer.
        float overhead = below ? smoothstep(0.3, 0.7, -N.y) : 0.0;
        if (below) {
            // ...but it reaches the eye through the water above you, so it takes on the
            // water's colour and a haze that thickens with depth and towards the window's edge.
            uwFog = underwaterFogColor(skyAmb, lightE, lightDir);
            vec3 ext = (waterAbsorption() + waterScatter()) * (0.42 / UNDERWATER_VIEW);
            vec3 Tw = exp(-ext * distW);
            float edge = 1.0 - saturate(dot(N, V));
            // The bright window is mostly sky-blue glow: what is above shows only as soft,
            // blue-tinted shapes, fading out completely towards the window's edge.
            vec3 glowW = uwFog * 2.4 + skyAmb * skyLight * 0.12 * vec3(0.55, 0.85, 1.0);
            float film = (0.42 + 0.45 * edge) / UNDERWATER_VIEW;
            vec3 tintW = mix(vec3(1.0), glowW / max(maxOf(glowW), 1e-4), 0.8);
            vec3 window = mix(body * tintW * Tw, glowW, saturate(film + (1.0 - luminance(Tw)) * 0.5));
            vec3 sideView = behind * mix(vec3(1.0), uwFog / max(maxOf(uwFog), 1e-4), 0.2);
            body = mix(sideView, window, overhead);
        }
        if (!below) {
            vec3 absorb = waterAbsorption();
            vec3 scat = waterScatter();
            // Biome water colour nudges the scattered light.
            vec3 biome = srgbToLinear(tint);
            biome = mix(vec3(1.0), biome / max(luminance(biome), 0.05), 0.35);
            vec3 T = exp(-(absorb + scat) * waterDepth);
            // Light reaching into the water: sky plus the sun's irradiance below the surface.
            float csWater = cloudShadow(worldPosW, lightDir);
            vec3 lightIn = skyAmb * skyLight * skyLight + lightE * RCP_PI * saturate(lightDir.y) * smoothstep(0.8, 0.97, skyLight) * csWater;
            vec3 inscatter = lightIn * scat / (absorb + scat) * (1.0 - T) * 0.3 * biome;
            body = behind * T + inscatter;
            body *= mix(1.0, 0.65 + texLum * 0.9, WATER_TEXTURE);
            #if WATER_FOAM == 1
                float t = frameTimeCounter;
                // Straight-down depth to the bottom (stable as the camera moves); the
                // along-the-view depth still catches water lapping against walls.
                float vDepth = (d1 >= 1.0 || lod) ? 64.0 : clamp(worldPosW.y - (viewToPlayer(viewPos1).y + cameraPosition.y), 0.0, 7.0);
                float shoreDepth = min(vDepth, waterDepth);
                float n1 = vnoise(worldPosW.xz * 1.7 + windDirection() * t * 0.25);
                float n2 = vnoise(worldPosW.xz * 4.3 - vec2(t * 0.3, -t * 0.2));
                // Lace wherever the water meets something (the along-the-view depth runs
                // smoothly to zero against walls and shores), always there, broken up.
                float lace = smoothstep(0.55, 0.0, waterDepth) * (0.45 + 0.55 * smoothstep(0.3, 0.7, n1 * 0.6 + n2 * 0.4));
                float foam = lace * 0.75;
                #if SHORE_WAVES == 1
                    // Smooth out the block steps of the sea bed (about a block around) so wave
                    // lines follow the shore instead of the block grid.
                    if (!lod && d1 < 1.0) {
                        float ppb = viewHeight * gbufferProjection[1][1] / (2.0 * max(distW, 0.5));   // pixels per block
                        float rr = clamp(ppb * 0.7, 2.0, 60.0);
                        float acc = vDepth; float wsum = 1.0;
                        for (int k = 0; k < 6; k++) {
                            float a = float(k) * 1.0472 + 0.5;
                            vec2 suv = uv + vec2(cos(a), sin(a)) * rr / vec2(viewWidth, viewHeight);
                            float sd = texture(depthtex1, suv).r;
                            if (sd >= 1.0) continue;
                            float y = viewToPlayer(screenToView(suv, sd, gbufferProjectionInverse)).y + cameraPosition.y;
                            acc += clamp(worldPosW.y - y, 0.0, 7.0); wsum += 1.0;
                        }
                        vDepth = acc / wsum;
                    }
                    vDepth += (n1 - 0.5) * 0.6;
                    // Waves roll in from deeper water (about ten blocks out on a sloping beach),
                    // steepen in the shallows and break into foam: thin, broken crests that
                    // grow stronger as they near the shore.
                    float slow = vnoise(worldPosW.xz * 0.045) * 6.2832;
                    float ph = vDepth * 1.45 + t * 0.75 + slow;
                    float crest = pow(0.5 + 0.5 * sin(ph), 22.0);
                    float trail = pow(0.5 + 0.5 * sin(ph - 0.5), 6.0) * 0.35;      // foam left behind a crest
                    float shoal = smoothstep(5.2, 0.7, vDepth) * smoothstep(0.03, 0.3, vDepth) * mix(0.55, 1.0, smoothstep(3.5, 1.0, vDepth));
                    float broken = smoothstep(0.35, 0.75, vnoise(worldPosW.xz * 2.1 + vec2(t * 0.2, -t * 0.15)) * 0.7 + n2 * 0.3);
                    foam = max(foam, (crest + trail * broken) * shoal * broken * 0.8);
                #endif
                // Foam is white: lit by whatever light there is, never tinted cyan.
                vec3 foamCol = vec3(luminance(lightIn + lightE * 0.15 * saturate(lightDir.y))) * vec3(0.96, 0.99, 1.0);
                body = mix(body, foamCol, foam);
            #endif
            #if WATER_FLOW == 1
                // Falling water: clear, with only a few faint pale streaks of air in it
                // sliding down, and a less mirror-like surface.
                falling = 1.0 - smoothstep(0.35, 0.75, abs(N.y));
                if (falling > 0.0) {
                    vec3 side = normalize(cross(N, vec3(0.0, 1.0, 0.0)));
                    float sa = dot(worldPosW, side);
                    float tf = waterClock() * 2.5;
                    float s1 = vnoise(vec2(sa * 5.0, worldPosW.y * 0.6 + tf));
                    float s2 = vnoise(vec2(sa * 13.0 + 3.0, worldPosW.y * 1.2 + tf * 1.3));
                    float streak = smoothstep(0.55, 0.9, s1 * 0.6 + s2 * 0.4);
                    vec3 whiteWater = vec3(luminance(lightIn + lightE * 0.15 * saturate(lightDir.y))) * vec3(0.95, 0.98, 1.0);
                    body = mix(body, whiteWater, falling * (0.01 + 0.07 * streak));
                }
                if (flowing && falling < 0.5) {
                    // Running water (streams, the pool under a waterfall): churned and frothy.
                    float tw = waterClock() * 2.5;
                    float churn = smoothstep(0.45, 0.85, vnoise(worldPosW.xz * 3.0 + vec2(tw * 0.9, -tw * 0.7)) * 0.6 + vnoise(worldPosW.xz * 7.0 - tw) * 0.4);
                    vec3 froth = vec3(luminance(lightIn + lightE * 0.15 * saturate(lightDir.y))) * vec3(0.95, 0.98, 1.0);
                    body = mix(body, froth, churn * 0.22);
                }
            #endif
        }

        // Reflection
        vec3 Rv = reflect(normalize(viewPosW), Nv);
        vec3 Rw = mat3(gbufferModelViewInverse) * Rv;
        vec3 refl;
        if (below) {
            // Past the window the surface mirrors the water below: its colour, plus the
            // sea bed and anything else on screen, fading with distance.
            refl = uwFog;
            #if WATER_REFLECTIONS >= 1
                if (!lod) {
                    vec4 ssr = traceSSR(viewPosW, Rv, depthtex1, colortex0, colortex3, reflectionSteps() / 2 + 8, dither);
                    refl = mix(refl * 0.85, ssr.rgb * 0.4 + uwFog * 0.6, ssr.a * 0.5);
                }
            #endif
        } else {
            refl = skyReflection(Rw, skyLight);
            #if WATER_REFLECTIONS >= 1
                if (!lod && !waterBehind) {
                    vec4 ssr = traceSSR(viewPosW, Rv, depthtex1, colortex0, colortex3, reflectionSteps(), dither);
                    refl = mix(refl, ssr.rgb, ssr.a);
                }
            #endif
        }
        float NdotV = saturate(dot(N, V));
        float F;
        if (below) {
            // Past the critical angle the surface overhead becomes a mirror (Snell's window).
            float sinT = 1.333 * sqrt(1.0 - NdotV * NdotV);
            float Fw = sinT >= 1.0 ? 1.0 : 0.02 + 0.98 * pow5(1.0 - NdotV);
            Fw = mix(Fw, 1.0, smoothstep(0.95, 1.0, sinT));
            F = mix((0.02 + 0.98 * pow5(1.0 - NdotV)) * 0.3, Fw, overhead);
        } else {
            F = 0.02 + 0.98 * pow5(1.0 - NdotV);
            F *= 1.0 - 0.8 * falling;
        }
        col = mix(body, refl, F);

        // Sun and moon glitter: rough far away so the path stays wide.
        #ifdef DIM_OVERWORLD
            if (!below) {
                float rough = 0.06 + 0.12 * (1.0 - exp(-distW / 160.0));
                ShadowSample sh = sampleShadow(playerPosW, N, dot(N, lightDir), skyLight, dither);
                float cs = cloudShadow(worldPosW, lightDir);
                vec3 spec = specularGGX(N, V, lightDir, 1.0 - sqrt(rough), vec3(0.02));
                col += lightE * spec * sh.light * cs * 1.4;
            }
        #endif
    }

    if (hasGlass && (!hasWater || waterBehind)) {
        // --------------------------------------------------- glass/ice ----
        // Only when the glass is the nearest surface (glass under water stays under it).
        vec3 N = decodeNormal(gdata.rg);
        vec2 gInfo = unpack2x8(gdata.b);          // sky light, kind (0 ice etc., 0.25 stained, 0.5 clear glass, 1 portal)
        bool portal = gInfo.y > 0.75;
        if (portal) {
            // A slow shimmer across the portal's surface.
            vec3 wp = playerPos0 + cameraPosition;
            vec2 g = vec2(vnoise(wp.xy * 1.3 + wp.zz + frameTimeCounter * 0.5), vnoise(wp.zy * 1.3 + wp.xx - frameTimeCounter * 0.4)) - 0.5;
            N = normalize(N + vec3(g.x, g.y, -g.x) * 0.12);
        }
        vec3 Nv = mat3(gbufferModelView) * N;
        vec3 Rv = reflect(normalize(viewPos0), Nv);
        vec3 refl = skyReflection(mat3(gbufferModelViewInverse) * Rv, gInfo.x);
        #if WATER_REFLECTIONS >= 2
            if (!lod) {
                vec4 ssr = traceSSR(viewPos0, Rv, depthtex1, colortex0, colortex3, reflectionSteps(), dither);
                refl = mix(refl, ssr.rgb, ssr.a);
            }
        #endif
        float f0g = portal ? 0.14 : 0.04;
        float NdotVg = saturate(dot(N, V));
        float F = f0g + (1.0 - f0g) * pow5(1.0 - NdotVg);
        bool filterGlass = gInfo.y > 0.15 && !portal;     // clear or stained glass
        if (filterGlass) {
            // Glass is a filter: what is behind is tinted and darkened by every pane in
            // the way (gbuffers_water multiplies them together), and the reflection of the
            // world takes over further away and at an angle.
            float far = smoothstep(3.0, 40.0, dist0);
            vec3 trans = texelFetch(colortex11, px, 0).rgb;
            if (GLASS_FROST > 0.0) {
                // Frosted: what is behind the glass is softened, so you can't stare into a
                // lit room through a window at night (or by day). Only things behind the
                // pane are gathered, never the frame in front of it.
                {
                    float fr = GLASS_FROST * 11.0 * viewHeight / 1080.0;
                    vec3 acc = col; float wsum = 1.0;
                    for (int k = 0; k < 10; k++) {
                        float a = (float(k) + dither) * 2.39996;
                        float r = sqrt((float(k) + 0.5) / 10.0) * fr;
                        vec2 suv = uv + vec2(cos(a), sin(a)) * r / vec2(viewWidth, viewHeight);
                        if (texture(depthtex1, suv).r < d0) continue;
                        acc += texture(colortex0, suv).rgb; wsum += 1.0;
                    }
                    col = acc / wsum;
                }
            }
            // The reflection is the same whatever the tint: Glass Tint only changes what
            // comes through the pane (that lives in trans), never how much it mirrors.
            F = saturate(F + (1.0 - F) * (0.06 + 0.3 * far));
            col = col * trans * (1.0 - F) + refl * F;
        } else {
            // (A vortex portal only glints: its light is far brighter than the reflection.)
            col = mix(col, refl, F * (portal ? (PORTAL_STYLE == 0 ? 0.9 : 0.3) : 0.85));
        }
    }

    if (!hasWater && !hasGlass && d0 < 1.0) {
        // ----------------------------------- wet, polished and metal ----
        #if WATER_REFLECTIONS >= 1 && defined DIM_OVERWORLD
            vec4 g2 = texelFetch(colortex2, px, 0);
            vec4 g3 = texelFetch(colortex3, px, 0);
            int cat = int(g3.r * 255.0 + 0.5);
            if (cat < CAT_ENTITY) {
                vec3 worldPos0 = playerPos0 + cameraPosition;
                vec3 N = decodeNormal(g2.rg);
                vec2 lm = unpack2x8(g2.b);
                float puddle;
                float w = surfaceWetness(worldPos0, N, lm.y, cat, puddle);
                float smoothness = mix(g3.g, 0.88, w * (1.0 - 0.55 * porosity(cat)));
                smoothness = mix(smoothness, 0.975, puddle);
                N = wetRippleNormal(N, worldPos0, w);
                #if WALL_DRIPS == 1
                    if (abs(N.y) < 0.35) {
                        float spill = puddleSpill(worldPos0, N);
                        smoothness = mix(smoothness, 0.95, wallStreaks(worldPos0, N, frameTimeCounter, spill) * w * max(0.25 + 0.75 * rainHere(), spill));
                    }
                #endif
                if (puddle > 0.0) N = normalize(mix(N, puddleNormal(worldPos0), puddle));
                if (smoothness > 0.55) {
                    vec3 Nv = mat3(gbufferModelView) * N;
                    vec3 Rv = reflect(normalize(viewPos0), Nv);
                    // Where a reflected ray finds nothing on screen: the sky outdoors, and
                    // indoors roughly the room itself (never a dark hole that flickers).
                    vec3 refl = mix(col, skyReflection(mat3(gbufferModelViewInverse) * Rv, 1.0), pow(lm.y, 3.0));
                    #if WATER_REFLECTIONS >= 2
                        vec4 ssr = traceSSR(viewPos0, Rv, depthtex1, colortex0, colortex3, reflectionSteps() / 2 + 8, dither);
                        refl = mix(refl, ssr.rgb, ssr.a);
                    #endif
                    bool metal = g3.b >= 0.9;
                    float f0 = metal ? 0.7 : max(g3.b, 0.03);
                    float F = f0 + (1.0 - f0) * pow5(1.0 - saturate(dot(N, V)));
                    float k = F * smoothstep(0.55, 0.95, smoothness) * mix(SPECULAR_STRENGTH, 1.0, puddle);
                    // Puddles read as standing water: a clear mirror over dark ground.
                    k = max(k, puddle * (0.3 + 0.7 * F));
                    col = mix(col, refl * (metal ? col / max(luminance(col), 1e-3) * 0.5 + 0.5 : vec3(1.0)), k);
                }
            }
        #endif
    }
    #ifdef HAS_FALLING_LEAVES
        // ---------------------------------------------------- falling leaves ----
        if (isEyeInWater == 0) {
            float tL; vec3 nL;
            float behindDist = (d0 >= 1.0 && !lod) ? 1e9 : dist0;
            vec4 lf = fallingLeaves(rd, behindDist, tL, nL);
            if (lf.a > 0.0) {
                vec3 pL = rd * tL;
                ShadowSample shL = sampleShadow(pL, nL, abs(dot(nL, lightDir)), 1.0, dither);
                float csL = cloudShadow(pL + cameraPosition, lightDir);
                // Lit on both faces (they are thin), glowing when the sun is behind them.
                float through = pow(saturate(dot(rd, lightDir)), 4.0);
                vec3 direct = lightE * shL.light * csL * RCP_PI * (0.25 + 0.75 * abs(dot(nL, lightDir)) + 1.2 * through);
                float skyEye = saturate(float(eyeBrightnessSmooth.y) / 240.0);
                vec3 leaf = lf.rgb * (direct + skyAmb * (0.25 + 0.45 * skyEye) + 0.004);
                col = mix(col, leaf, lf.a);
            }
        }
    #endif
    #ifdef HAS_CANOPY_DRIPS
        // ------------------------------------- drips from trees and overhangs ----
        if (isEyeInWater == 0) {
            float behindD = (d0 >= 1.0 && !lod) ? 1e9 : dist0;
            col += canopyDrips(rd, behindD, skyAmb, lightE);
        }
    #endif
    outColor = vec4(col, 1.0);
}
#endif
