/*
    Tempered Light - opaque geometry: writes the G-buffer that the deferred
    pass lights. Programs that may draw after deferred (particles, hand, lines,
    eyes) also write a forward-lit colour so they look right either way.
    The RENDERTARGETS directive lives in the wrapper that includes this file
    (gbuffers_opaque.glsl or gbuffers_particles.glsl).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl"
#include "/lib/materials.glsl"
#include "/lib/wind.glsl"

#if !defined DIM_NETHER && !defined DIM_END
    #define DIM_OVERWORLD
#endif

// The beacon beam glows like eyes do.
#ifdef PROGRAM_BEACON
    #define PROGRAM_EYES
#endif

#if defined PROGRAM_BASIC || defined PROGRAM_TEXTURED || defined PROGRAM_HAND || defined PROGRAM_EYES || defined PROGRAM_LIGHTNING
    #define FORWARD
#endif

#ifdef FORWARD
    #include "/lib/atmosphere.glsl"
    #include "/lib/sky.glsl"
#endif

// =========================================================== vertex ======
#ifdef VSH

#ifdef PROGRAM_TERRAIN
in vec4 mc_Entity;
in vec4 at_midBlock;
in vec2 mc_midTexCoord;
#include "/lib/waving.glsl"
#endif
#ifdef PROGRAM_TEXTURED
#include "/lib/floodfill.glsl"
#include "/lib/smoke.glsl"
#include "/lib/smokeplume.glsl"
#endif
in vec4 at_tangent;

out vec2 uv;
out vec2 lm;
out vec4 vcol;
out vec3 normalW;
out vec4 tangentW;
flat out int cat;
flat out float emitLevel;
#ifdef PROGRAM_TEXTURED
out vec2 quadUV;         // 0..1 across a particle's quad (for round droplets)
#if SMOKE_REAL == 1 || END_PORTAL_LIST == 1
flat out float smokeHide; // Minecraft's smoke puff over a fire with a realistic plume, or an End portal
#endif
#endif
#ifdef FORWARD
flat out vec3 fwdSky;
flat out vec3 fwdLightE;
flat out vec3 fwdLightDir;
#endif
#ifdef PROGRAM_TERRAIN
out vec2 tileLocal;      // 0..1 across this face's texture tile (for parallax)
flat out vec4 tileRect;  // atlas origin and size of the tile
out vec3 playerPosV;
#endif

void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lm = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lm = saturate((lm - 1.0 / 32.0) * 16.0 / 15.0);
    vcol = gl_Color;
    normalW = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
    tangentW = vec4(mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * at_tangent.xyz), at_tangent.w);
    emitLevel = 0.0;

    vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;

    #if defined PROGRAM_TERRAIN
        cat = catFromId(mc_Entity.x);
        #ifdef IRIS_FEATURE_BLOCK_EMISSION_ATTRIBUTE
            emitLevel = saturate(at_midBlock.w / 15.0);
        #else
            emitLevel = 0.0;  // older Iris: rely on the block list
        #endif
        vec3 playerPos = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
        bool top = gl_MultiTexCoord0.y < mc_midTexCoord.y;
        playerPos += wavingOffset(cat, playerPos + cameraPosition, playerPos, top, lm.y, 0.5 - at_midBlock.y / 64.0);
        #if LAVA_WAVES == 1
            // Slow, heavy swell on the surface of lava.
            if (cat == CAT_LAVA && normalW.y > 0.5) {
                vec3 wp = playerPos + cameraPosition;
                playerPos.y += sin(wp.x * 0.7 + frameTimeCounter * 0.9) * cos(wp.z * 0.6 + frameTimeCounter * 0.7) * 0.045;
            }
        #endif
        gl_Position = gl_ProjectionMatrix * (gbufferModelView * vec4(playerPos, 1.0));
        vec2 halfTile = abs(uv - mc_midTexCoord);
        tileRect = vec4(mc_midTexCoord - halfTile, halfTile * 2.0);
        tileLocal = (uv - tileRect.xy) / max(tileRect.zw, vec2(1e-6));
        playerPosV = playerPos;
    #else
        #if defined PROGRAM_HAND
            cat = CAT_HAND;
        #elif defined PROGRAM_ENTITIES
            cat = entityId == ENTITY_LIGHTNING ? CAT_EMISSIVE_ENTITY : CAT_ENTITY;
        #elif defined PROGRAM_LIGHTNING
            cat = CAT_EMISSIVE_ENTITY;
        #elif defined PROGRAM_BASIC
            cat = CAT_UNLIT;
        #elif defined PROGRAM_EYES
            cat = CAT_EMISSIVE_ENTITY;
        #elif defined PROGRAM_TEXTURED
            cat = CAT_PARTICLE;
            int qc = gl_VertexID & 3;
            quadUV = vec2(qc == 1 || qc == 2 ? 1.0 : 0.0, qc >= 2 ? 1.0 : 0.0);
            #if SMOKE_REAL == 1 || END_PORTAL_LIST == 1
                smokeHide = 0.0;
            #endif
            #ifdef HAS_SMOKE_PLUMES
                vec3 ppS = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
                smokeHide = smokeParticleCovered(ppS + cameraPosition) ? 1.0 : 0.0;
            #endif
            #if END_PORTAL_LIST == 1
            {
                // Minecraft's black smoke over an End portal: the portal's own mist replaces it.
                vec3 ppE = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz + cameraPosition;
                for (int k = 0; k <= 3; k++) {
                    ivec3 v = ffVoxelFromWorld(ppE - vec3(0.0, float(k), 0.0));
                    if (ffInside(v) && ffCat(texelFetch(lfVoxelSampler, v, 0).r) == CAT_END_PORTAL) { smokeHide = 1.0; break; }
                }
            }
            #endif
            #ifdef HAS_SMOKE_DRIFT
                // Smoke and embers rising from a fire drift away with the wind.
                vec3 pp = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
                viewPos += mat3(gbufferModelView) * smokeDrift(pp + cameraPosition, lm.y);
            #endif
        #elif defined PROGRAM_BLOCK
            // Block entities (end portal, end gateway, conduit...) use block.properties IDs.
            cat = catFromId(float(blockEntityId));
        #else
            cat = CAT_DEFAULT;
        #endif
        gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);
    #endif

    #ifdef FORWARD
        #ifdef DIM_OVERWORLD
            vec3 sd = worldSunDir();
            fwdLightDir = worldLightDir();
            fwdLightE = directLightIrradiance(sd);
            fwdSky = skyAmbientFromLut();
        #else
            fwdLightDir = vec3(0.0, 1.0, 0.0);
            fwdLightE = vec3(0.0);
            fwdSky = otherDimAmbient();
        #endif
    #endif
    // Sub-pixel jitter for temporal anti-aliasing.
    gl_Position.xy += taaJitter() * gl_Position.w;
}
#endif

// ========================================================= fragment ======
#ifdef FSH

uniform sampler2D gtexture;
uniform sampler2D normals;
uniform sampler2D specular;

in vec2 uv;
in vec2 lm;
in vec4 vcol;
in vec3 normalW;
in vec4 tangentW;
flat in int cat;
flat in float emitLevel;
#ifdef PROGRAM_TEXTURED
in vec2 quadUV;
#if SMOKE_REAL == 1 || END_PORTAL_LIST == 1
flat in float smokeHide;
#endif
#endif
#ifdef FORWARD
flat in vec3 fwdSky;
flat in vec3 fwdLightE;
flat in vec3 fwdLightDir;
#endif
#ifdef PROGRAM_TERRAIN
in vec2 tileLocal;
flat in vec4 tileRect;
in vec3 playerPosV;
#endif

// Parallax occlusion: march the PBR height map (normal texture alpha) so bumps
// and bricks look raised. Returns the texture coordinate to shade.
vec2 parallaxUV(vec2 dx, vec2 dy) {
    vec2 tuv = uv;
    #if MATERIALS == 1 && PARALLAX == 1 && defined PROGRAM_TERRAIN
        float pdist = length(playerPosV);
        if (pdist > 28.0 || length(tangentW.xyz) < 0.5) return tuv;
        vec4 n0 = textureGrad(normals, uv, dx, dy);
        if (dot(n0.rgb, n0.rgb) < 0.01) return tuv;           // no normal map
        vec3 Ng = normalize(normalW);
        vec3 T = normalize(tangentW.xyz);
        vec3 B = cross(T, Ng) * (tangentW.w < 0.0 ? -1.0 : 1.0);   // Iris: cross(T, N) * w points along +v
        vec3 Vw = -normalize(playerPosV);
        vec3 vt = vec3(dot(Vw, T), dot(Vw, B), dot(Vw, Ng));
        if (vt.z < 0.08) return tuv;
        float fade = 1.0 - smoothstep(18.0, 28.0, pdist);
        vec2 stepTile = -vt.xy / vt.z * (PARALLAX_DEPTH * fade / float(PARALLAX_SAMPLES));
        float dl = 1.0 / float(PARALLAX_SAMPLES);
        float layer = 1.0;
        vec2 lc = tileLocal;
        float h = n0.a;
        for (int i = 0; i < PARALLAX_SAMPLES; i++) {
            if (h >= layer) break;
            layer -= dl;
            lc += stepTile;
            h = textureGrad(normals, tileRect.xy + fract(lc) * tileRect.zw, dx, dy).a;
        }
        tuv = tileRect.xy + fract(lc) * tileRect.zw;
    #endif
    return tuv;
}

// Texture brightness as a height, sampled inside this face's own tile.
float texHeight(vec2 lc, vec2 dx, vec2 dy) {
    #ifdef PROGRAM_TERRAIN
        return luminance(textureGrad(gtexture, tileRect.xy + fract(lc) * tileRect.zw, dx, dy).rgb);
    #else
        return 0.0;
    #endif
}
bool generatedNormalsFor(int c) {
    return !(isFoliage(c) || isLeaves(c) || c == CAT_WATER || c == CAT_LAVA || isGlass(c) || isEmitterCat(c) ||
             c == CAT_ICE || c == CAT_TRANSLUCENT || c == CAT_PORTAL || c == CAT_SNOW);
}

// Average speck-ness of the texels around this one (within about 3 texels of a
// 16x texture), wrapping inside the block's own tile.
float oreHalo(vec2 tuv) {
    #ifdef PROGRAM_TERRAIN
        vec2 lc = (tuv - tileRect.xy) / max(tileRect.zw, vec2(1e-6));
        float acc = 0.0;
        for (int i = 0; i < 12; i++) {
            float a = float(i) * 2.39996;
            float r = (1.2 + 2.0 * fract(float(i) * 0.618034)) / 16.0;
            vec2 o = lc + vec2(cos(a), sin(a)) * r;
            vec3 t = textureLod(gtexture, tileRect.xy + fract(o) * tileRect.zw, 0.0).rgb * vcol.rgb;
            acc += oreSpeck(t);
        }
        return smoothstep(0.0, 0.5, acc / 12.0) * (1.0 - oreSpeck(textureLod(gtexture, tuv, 0.0).rgb * vcol.rgb));
    #else
        return 0.0;
    #endif
}

layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outAlbedo;
layout(location = 2) out vec4 outNormal;
layout(location = 3) out vec4 outMaterial;
#ifdef WRITES_WATER_MASK
// Solid particle texels in front of water: tell composite not to shade them as water.
layout(location = 4) out vec4 outWaterMask;
#endif

void main() {
    vec2 dx = dFdx(uv), dy = dFdy(uv);
    vec2 tuv = parallaxUV(dx, dy);
    vec4 tex = textureGrad(gtexture, tuv, dx, dy);
    vec4 albedo = tex * vec4(vcol.rgb, 1.0);
    float ao = 1.0;
    #ifdef PROGRAM_TERRAIN
        ao = vcol.a;
    #else
        albedo.a *= vcol.a;
    #endif

    // Lightning has no texture and faint vertex colours: draw it as a solid bright bolt.
    #if defined PROGRAM_LIGHTNING
        bool lightning = true;
    #elif defined PROGRAM_ENTITIES
        bool lightning = entityId == ENTITY_LIGHTNING;
    #else
        bool lightning = false;
    #endif
    if (lightning) albedo = vec4(0.80, 0.85, 1.0, 1.0);
    #if LIGHTNING_REAL == 1 && !defined DIM_NETHER && !defined DIM_END
        // Realistic Lightning draws the bolt itself (composite1); Minecraft's blocky one
        // is hidden while Iris says where the bolt is.
        if (lightning && lightningBoltPosition.w > 0.5) discard;
    #endif

    #if defined PROGRAM_BLOCK && END_PORTAL_STYLE == 1
        // End portals are drawn in deferred, as a window into the End (lib/endportal.glsl).
        if (cat == CAT_END_PORTAL) albedo = vec4(0.0, 0.0, 0.0, 1.0);
    #endif
    if (albedo.a < 0.1) discard;
    #if defined PROGRAM_TEXTURED && (SMOKE_REAL == 1 || END_PORTAL_LIST == 1)
        // Realistic smoke draws its own plume over this fire (and End portals their own
        // mist): hide Minecraft's grey puffs (sparks, embers and portal sparkles, which
        // are coloured, stay).
        if (smokeHide > 0.5) {
            float mx = max(tex.r, max(tex.g, tex.b)), mn = min(tex.r, min(tex.g, tex.b));
            if (mx - mn < 0.14 * mx + 0.02) discard;
        }
    #endif
    // Rain splashes, drips and bubbles: vanilla draws them as saturated blue
    // sprites. Make them faint, bright droplets that pick up the sky instead.
    bool watery = false;
    #if defined PROGRAM_TEXTURED && SPLASH_STYLE == 1
        watery = tex.b > tex.r * 1.35 && tex.b > tex.g * 1.12;
        if (watery) {
            // A small round droplet instead of a square of blue pixels.
            float r = length(quadUV - 0.5);
            if (r > 0.32) discard;
            albedo.rgb = mix(vec3(0.84, 0.90, 0.97), albedo.rgb, 0.25);
            albedo.a *= 0.42 * smoothstep(0.32, 0.18, r);
        }
    #endif
    #ifdef PROGRAM_BEACON
        // The beam's faint outer glow would overwrite the G-buffer of whatever is behind it.
        if (albedo.a < 0.5) discard;
    #endif

    #if defined PROGRAM_ENTITIES || defined PROGRAM_HAND
        albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);
    #endif

    int c = cat;
    vec3 N = normalize(normalW);
    float smoothness = 0.0, f0 = 0.0, emission = 0.0;

    #if MATERIALS == 1
        // labPBR: normal map RG = normal, B = ambient occlusion, A = height;
        // specular R = smoothness, G = F0 / metal, A = emission (255 = none).
        vec4 nt = textureGrad(normals, tuv, dx, dy);
        bool hasNormalMap = dot(nt.rgb, nt.rgb) > 0.01;
        #if GENERATED_NORMALS == 1 && defined PROGRAM_TERRAIN
            // Iris binds a flat stand-in when the resource pack has no normal maps (and fills
            // gaps in a partial pack with flat texels): treat those as having none.
            if (textureSize(normals, 0).x <= 1) hasNormalMap = false;
            else if (all(lessThan(abs(nt.rg - 0.5), vec2(0.004))) && nt.a > 0.99) {
                vec4 ntc = textureLod(normals, tileRect.xy + tileRect.zw * 0.37, 0.0);
                if (all(lessThan(abs(ntc.rg - 0.5), vec2(0.004))) && ntc.a > 0.99) hasNormalMap = false;
            }
        #endif
        if (hasNormalMap && length(tangentW.xyz) > 0.5) {
            vec2 xy = (nt.rg * 2.0 - 1.0) * NORMAL_STRENGTH;
            vec3 tn = normalize(vec3(xy, sqrt(saturate(1.0 - dot(xy, xy))) + 0.05));
            vec3 T = normalize(tangentW.xyz);
            vec3 B = cross(T, N) * (tangentW.w < 0.0 ? -1.0 : 1.0);   // +v, matching labPBR's green channel
            N = normalize(mat3(T, B, N) * tn);
            #if PBR_AO == 1
                ao *= mix(1.0, nt.b, 0.85);
            #endif
        }
        #if GENERATED_NORMALS == 1 && defined PROGRAM_TERRAIN
            // No normal map: raise the bright parts of the texture and sink the dark
            // ones, so bricks, cobbles and planks catch the light at their edges.
            else if (generatedNormalsFor(c) && length(tangentW.xyz) > 0.5) {
                float fade = 1.0 - smoothstep(24.0, 48.0, length(playerPosV));
                if (fade > 0.0) {
                    vec2 lc = (tuv - tileRect.xy) / max(tileRect.zw, vec2(1e-6));
                    float st = 1.0 / 16.0;
                    float hL = texHeight(lc - vec2(st, 0.0), dx, dy), hR = texHeight(lc + vec2(st, 0.0), dx, dy);
                    float hD = texHeight(lc - vec2(0.0, st), dx, dy), hU = texHeight(lc + vec2(0.0, st), dx, dy);
                    vec3 T = normalize(tangentW.xyz);
                    vec3 B = cross(T, N) * (tangentW.w < 0.0 ? -1.0 : 1.0);
                    vec2 g = vec2(hR - hL, hU - hD) * 1.3 * GENERATED_NORMAL_STRENGTH * fade;
                    vec3 Np = N - T * g.x - B * g.y;
                    if (dot(Np, Np) > 1e-4) N = normalize(Np);
                }
            }
        #endif
        vec4 sp = textureGrad(specular, tuv, dx, dy);
        smoothness = sp.r;
        f0 = sp.g;
        #if PBR_EMISSION == 1
            emission = sp.a < 0.999 ? sp.a : 0.0;
        #endif
    #endif

    #if defined PROGRAM_TERRAIN && DEFAULT_SHINE > 0
        // Blocks with no specular map still get a sensible shine for their material.
        if (smoothness < 0.01) {
            smoothness = defaultShine(c) * (DEFAULT_SHINE == 2 ? 1.15 : 1.0);
            // Brighter, smoother-looking texels shine more than the dull cracks between them.
            float avgL = luminance(textureLod(gtexture, tuv, 4.0).rgb) + 0.02;
            smoothness *= clamp(0.55 + 0.5 * luminance(tex.rgb) / avgL, 0.5, 1.2);
            if (c == CAT_METAL) f0 = 0.3;    // bright, but not a full mirror without a PBR pack
        }
    #endif
    #ifdef PROGRAM_TERRAIN
        float level = max(emitLevel, isEmitterCat(c) ? 0.8 : 0.0);
        emission = max(emission, emissionMask(c, albedo.rgb, level));
        #if GEM_GLOW == 1
            // An even inner glow that keeps the texture readable; the light it casts
            // and the bloom around it do the rest.
            if (isGem(c)) emission = max(emission, GEM_GLOW_STRENGTH * (0.10 + 0.16 * smoothstep(0.3, 0.9, maxOf(albedo.rgb))));
        #endif
        #if ORE_GLOW == 1
            // The coloured specks of an ore glow, and spill a soft halo of their colour onto
            // the rock just around them (like a glow round a lit button).
            if (isOre(c)) {
                emission = max(emission, ORE_GLOW_STRENGTH * 0.42 * oreSpeck(albedo.rgb));
                emission = max(emission, ORE_GLOW_STRENGTH * 0.2 * oreHalo(tuv));
            }
        #endif
        if (isEmitterCat(c) == false && emitLevel > 0.0 && c == CAT_DEFAULT) c = CAT_EMITTER;
    #endif
    #ifdef PROGRAM_BLOCK
        if (isEmitterCat(c)) emission = max(emission, emissionMask(c, albedo.rgb, 0.8));
    #endif
    #if defined PROGRAM_HAND || defined PROGRAM_ENTITIES
        // Held items (and items in frames or dropped) glow like the block they are:
        // a lapis ore in your hand shows its glowing specks, a sea lantern glows.
        int ic = heldItemCat(currentRenderedItemId);
        if (ic >= 0) emission = max(emission, blockGlow(ic, albedo.rgb, isEmitterCat(ic) ? 0.8 : 0.0));
    #endif
    #ifdef PROGRAM_EYES
        emission = 1.0;
    #endif
    if (lightning) { emission = 1.0; N = vec3(0.0, 1.0, 0.0); }

    vec3 fwd = vec3(0.0);
    #ifdef FORWARD
        vec3 alb = srgbToLinear(albedo.rgb);
        #if defined PROGRAM_BASIC
            fwd = alb;
        #else
            #ifdef DIM_OVERWORLD
                float skyL = lm.y;
            #else
                float skyL = 1.0;   // no sky light in the Nether or End: use the flat ambient
            #endif
            float NdotL = saturate(dot(N, fwdLightDir)) * 0.7 + 0.3;
            fwd = alb * (fwdSky * skyL * skyL + fwdLightE * NdotL * RCP_PI * smoothstep(0.8, 0.97, skyL)
                        + defaultBlockLightColor() * blockLightCurve(lm.x) + 0.004);
            // Droplets mostly reflect the bright sky around them.
            if (watery) fwd = alb * (fwdSky * 1.8 * skyL + fwdLightE * 0.12 + defaultBlockLightColor() * blockLightCurve(lm.x) + 0.01);
            fwd += alb * emission * 3.0 * EMISSIVE_STRENGTH * (lightning ? 4.0 : 1.0);
        #endif
    #endif

    outColor = vec4(fwd, albedo.a);
    outAlbedo = vec4(albedo.rgb, 1.0);
    outNormal = vec4(encodeNormal(N), pack2x8(lm), ao);
    outMaterial = vec4(float(c) / 255.0, smoothness, f0, saturate(emission));
    #ifdef WRITES_WATER_MASK
        // Particles draw after lighting: their alpha only says whether they replace
        // the data underneath (faint droplets must not hide puddle reflections).
        outNormal.a = watery ? 0.0 : 1.0;
        outMaterial.a = watery ? 0.0 : 1.0;
    #endif
    #ifdef WRITES_WATER_MASK
        outWaterMask = vec4(0.0, 0.0, 0.0, albedo.a > 0.6 ? 1.0 : 0.0);
    #endif
}
#endif
