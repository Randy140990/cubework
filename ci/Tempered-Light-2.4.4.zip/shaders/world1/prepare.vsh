#version 330 compatibility
// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define VSH
#define PROGRAM_PREPARE
#define DIM_END
#include "/program/prepare.glsl"
