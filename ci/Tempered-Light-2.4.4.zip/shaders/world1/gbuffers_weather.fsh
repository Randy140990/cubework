#version 330 compatibility
// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define FSH
#define PROGRAM_WEATHER
#define DIM_END
#include "/program/gbuffers_weather.glsl"
