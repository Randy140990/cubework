// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define DIM_END
#include "/program/voxy_opaque_impl.glsl"
