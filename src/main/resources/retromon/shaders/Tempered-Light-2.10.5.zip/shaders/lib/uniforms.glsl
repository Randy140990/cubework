/*
    Tempered Light - uniforms shared by the Iris programs.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_UNIFORMS
#define LF_UNIFORMS

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowProjectionInverse;

uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 shadowLightPosition;
uniform vec3 upPosition;
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform vec4 entityColor;
uniform vec4 lightningBoltPosition;
uniform ivec2 eyeBrightnessSmooth;

uniform float near;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;
uniform float aspectRatio;
uniform float frameTimeCounter;
// From Lightreel (0.13.1+) in its replays: seconds a sped-up day has pushed the sky on. 0 otherwise.
uniform float lightreelSkySeconds;
// Lightreel 0.13.2+: the replay's clock in days plus 1, exact every frame (wrapped at 840 days); 0 otherwise.
uniform float lightreelDays;
uniform float frameTime;
uniform float sunAngle;
uniform float rainStrength;
uniform float wetness;
uniform float thunderStrength;
uniform float nightVision;
uniform float blindness;
uniform float darknessFactor;
uniform float screenBrightness;
uniform float eyeAltitude;

uniform int frameCounter;
uniform int worldTime;
uniform int worldDay;
uniform int moonPhase;
uniform int isEyeInWater;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;
uniform int renderStage;
uniform int bedrockLevel;
uniform int heightLimit;
uniform int entityId;
uniform int blockEntityId;
uniform int currentRenderedItemId;   // item.properties id of the item being drawn (held items, item frames)

// Custom uniforms (shaders.properties): weather smoothed over time, and where it rains.
uniform float lfRain;      // rain, eased slowly so clouds and sky change smoothly
uniform float lfThunder;
uniform float lfWet;       // surface wetness in rainy biomes (dries slowly)
uniform float lfPuddle;    // puddle amount (builds up in rain, shrinks after)
uniform float lfSoak;      // long rain: puddles keep spreading over several minutes
uniform float lfDrip;      // drips from trees and eaves: 1 in rain, easing off over a minute after
uniform float lfVelX;      // your speed along x and z (blocks per second), eased
uniform float lfVelZ;
uniform float lfEyeWet;    // 1 with your head under water, drying off after
uniform vec3 relativeEyePosition;   // camera minus your eyes (third person)
uniform vec3 playerLookVector;      // the way you face (also in third person)
uniform bool isSpectator;
uniform float lfRainHere;  // 1 where the current biome gets rain
uniform float lfSnowHere;  // 1 where it snows
uniform float lfExert;     // 1 after sprinting a while, easing back over 10-15 s
uniform float lfCold;      // 1 in snowy and cold biomes
uniform float lfWarm;      // 1 in deserts, savannas, badlands
uniform float lfSnowCover; // how much snow would have settled (any biome; see snowCoverHere)
uniform float lfSnowStorm; // how hard the weather is (storms 1; see snowStormHere)
// Only in cold biomes, following the biome you are in within a few seconds.
float snowCoverHere() { return lfSnowCover * lfSnowHere; }
float snowStormHere() { return lfSnowStorm * lfSnowHere; }

#ifdef DISTANT_HORIZONS
uniform mat4 dhProjection;
uniform mat4 dhProjectionInverse;
uniform float dhNearPlane;
uniform float dhFarPlane;
uniform int dhRenderDistance;
#endif

#ifdef VOXY
uniform mat4 vxProj;
uniform mat4 vxProjInv;
uniform mat4 vxModelView;
uniform mat4 vxModelViewInv;
uniform int vxRenderDistance;
#endif


// Up above the clouds it is not raining: the sky is clear, the sun is out and no rain or
// snow falls. 1 below the cloud deck, fading to 0 as you climb through it.
float belowCloudDeck() {
    #if CLOUD_MODE == 2
        float base = float(REALISTIC_CLOUD_ALTITUDE) + 30.0;
        float top = base + 150.0 * pow(float(CLOUD_SIZE), 0.75);
    #elif CLOUD_MODE == 5
        float base = float(REALISTIC_CLOUD_ALTITUDE) - 10.0;
        float top = base + 110.0 * pow(float(CLOUD_SIZE), 0.75);
    #elif CLOUD_MODE == 1
        float base = float(BLOCKY_CLOUD_ALTITUDE) + float(BLOCKY_CLOUD_THICKNESS);
        float top = base + 30.0 + float(CLOUD_HEIGHT_VARIATION);
    #else
        float base = 196.0;
        float top = 230.0;
    #endif
    return 1.0 - smoothstep(base, top, cameraPosition.y);
}
// Rain as the sky, the sun and the air see it from where you are.
float skyRain() { return lfRain * belowCloudDeck(); }
// How much darker rain and above all thunderstorms make the world (Storm Darkness):
// about a fifth in rain, well over half in a thunderstorm.
// Lightning in the clouds: where in the world a flash is lighting them up right now
// (xyz) and how brightly (w, 0 = none). A bolt striking lights the clouds above where
// it starts; in a thunderstorm the clouds also flash now and then with no bolt.
vec4 cloudFlash() {
    #if CLOUD_MODE == 1
        float alt = float(BLOCKY_CLOUD_ALTITUDE) + 8.0;
    #else
        float alt = float(REALISTIC_CLOUD_ALTITUDE) + 50.0;
    #endif
    float t = frameTimeCounter;
    if (LIGHTNING_FLASH <= 0.0) return vec4(0.0);
    if (lightningBoltPosition.w > 0.5) {
        // Bolts flicker as they strike.
        float fl = 0.5 + 0.5 * hash12(vec2(floor(t * 22.0), 1.7));
        return vec4(cameraPosition.x + lightningBoltPosition.x, alt, cameraPosition.z + lightningBoltPosition.z, fl * 1.4 * LIGHTNING_FLASH);
    }
    if (lfThunder < 0.2) return vec4(0.0);
    // Sheet lightning: every few seconds a chance of a flash somewhere in the clouds
    // round you, a quick flicker that dies away.
    const float rate = 0.4;
    float cell = floor(t * rate);
    if (hash12(vec2(cell, 9.1)) < 0.45) return vec4(0.0);
    float age = fract(t * rate) / rate;
    float pulse = exp(-age * 4.0) * (0.4 + 0.6 * step(0.35, hash12(vec2(floor(t * 18.0), cell))));
    vec2 off = (hash22(vec2(cell, 4.3)) - 0.5) * 1100.0;
    return vec4(cameraPosition.x + off.x, alt + 40.0 * hash12(vec2(cell, 2.2)), cameraPosition.z + off.y, pulse * smoothstep(0.2, 0.7, lfThunder) * LIGHTNING_FLASH);
}
// How much a flash brightens the world round you.
float flashAmbient() {
    #if !defined DIM_NETHER && !defined DIM_END
        vec4 f = cloudFlash();
        if (f.w <= 0.0) return 0.0;
        return f.w * exp(-length(f.xz - cameraPosition.xz) / 500.0) * belowCloudDeck();
    #else
        return 0.0;
    #endif
}
// Days since the world began (counted from 06:00 on day 0), wrapped to a period of days. It runs smoothly
// through the night and the change of day, and on through a Lightreel time-lapse: there Lightreel gives the
// clock exactly every frame, since Iris only updates worldDay and worldTime once a tick, which at 100 days
// in 30 seconds would make the slow stars and the moon step. Every period used divides 840.
float skyDays(int period) {
    if (lightreelDays > 0.5) return mod(lightreelDays - 1.0, float(period));
    return float(worldDay % period) + float(worldTime) / 24000.0;
}

// The moon's phase as an angle: 0 full, PI new. With Moon Cycle the shader keeps its own month: new moon
// at midnight on day 0, full at midnight half way through, waxing and waning smoothly in between. The
// vanilla moon texture keeps the game's own eight-night phases.
float moonPhaseAngle() {
    #if MOON_PHASES == 0
        return 0.0;
    #elif MOON_CYCLE > 0 && MOON_SHAPE != 3
        // u: where the moon is in its month, -0.5 to 0.5, with new moon at 0 (midnight on day 0).
        // The whole night of the new moon stays dark, dusk to dawn (6.5 hours either side of
        // midnight), so the old crescent has gone before the new one shows, on the other side.
        // The first and last crescents grow and shrink a little faster, so they're easy to see.
        float n = float(MOON_CYCLE);
        float u = fract((skyDays(MOON_CYCLE) - 0.75) / n + 0.5) - 0.5;
        float p = 0.27 / n;
        float s = max(abs(u) - p, 0.0) / (0.5 - p);
        return PI + PI * sign(u) * pow(s, 0.75);
    #else
        return float(moonPhase) * 0.785398;
    #endif
}

// How much of the moon's face is lit (0 at new moon, 1 at full), for its halo and flare.
float moonLitFraction() {
    #if MOON_PHASES == 0
        return 1.0;
    #else
        return 0.5 + 0.5 * cos(moonPhaseAngle());
    #endif
}

float stormDark() {
    return saturate(STORM_DARKNESS * (0.18 * skyRain() + 0.42 * lfThunder * belowCloudDeck()));
}

#endif
