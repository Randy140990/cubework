/*
    Tempered Light - coloured light that spreads block by block.
    The shadow pass writes light sources, solid blocks and partial occluders
    (plants, leaves, fences) into a voxel grid around the camera; a compute pass
    spreads light one block per frame and remembers which source each block's
    light comes from, so surfaces can trace a shadow ray back to it.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_FLOODFILL
#define LF_FLOODFILL

const ivec3 FF_SIZE = ivec3(FF_SIZE_XZ, FF_SIZE_Y, FF_SIZE_XZ);

// Voxel word: bits 0-3 light level, 4-11 category, 12 solid, 13 partial occluder,
// 14 a mob, player or block entity is here (only blocks shadow rays, not the spread).
uint ffPack(int level, int cat, bool solid, bool partial) {
    return uint(clamp(level, 0, 15)) | (uint(clamp(cat, 0, 255)) << 4u) | (solid ? 4096u : 0u) | (partial ? 8192u : 0u);
}
int ffLevel(uint v) { return int(v & 15u); }
int ffCat(uint v) { return int((v >> 4u) & 255u); }
bool ffSolid(uint v) { return (v & 4096u) != 0u; }
bool ffPartial(uint v) { return (v & 8192u) != 0u; }
bool ffEntity(uint v) { return (v & 16384u) != 0u; }
const uint FF_ENTITY_BIT = 16384u;
// Face record (lfFaces), written for every block the shadow pass draws:
// bit 6 something is drawn in this cell, bit 7 a corner of a full cube, bit 8 geometry
// inside the cube (so not a full cube), bits 0-5 which of its faces were drawn
// (+x, -x, +y, -y, +z, -z). Minecraft skips a full cube's face only when the block next
// to it is opaque, so a missing face tells us that neighbour is a solid block even
// though it is buried and never drawn itself.
const uint FF_FACE_OCCUPIED = 64u;
const uint FF_FACE_FULL = 128u;
const uint FF_FACE_NONFULL = 256u;
uint ffFaceBit(vec3 n) {
    vec3 a = abs(n);
    if (a.x >= a.y && a.x >= a.z) return n.x > 0.0 ? 1u : 2u;
    if (a.y >= a.z) return n.y > 0.0 ? 4u : 8u;
    return n.z > 0.0 ? 16u : 32u;
}
uint ffFaceBitDir(ivec3 d) {
    if (d.x != 0) return d.x > 0 ? 1u : 2u;
    if (d.y != 0) return d.y > 0 ? 4u : 8u;
    return d.z > 0 ? 16u : 32u;
}

// End portals are drawn as block entities, so the shadow pass sees only the corners of
// their faces, which sit on block edges. Each corner is marked in the four cells that
// share it (lfFaces bits 9-12: which corner of that cell it is); a cell with all four
// corners marked and nothing else drawn in it is End portal (see occlusion_comp.glsl).
const uint FF_END_CORNERS = 7680u;   // bits 9-12
// The cell a vertex at a block corner marks for corner k (0-3: x then z), and the bit.
ivec3 ffEndCornerCell(vec3 worldPos, int k, out uint bit) {
    ivec2 s = ivec2(k & 1, k >> 1);
    bit = 512u << uint(k);
    return ivec3(int(floor(worldPos.x + 0.5)) - s.x, int(floor(worldPos.y)), int(floor(worldPos.z + 0.5)) - s.y);
}

// Bit 15: stained glass here; bits 16-30: the colour it lets through (5 bits each).
const uint FF_TINT_BIT = 32768u;
uint ffPackTint(vec3 t) {
    uvec3 q = uvec3(clamp(t, 0.0, 1.0) * 31.0 + 0.5);
    return FF_TINT_BIT | (q.r << 16u) | (q.g << 21u) | (q.b << 26u);
}
bool ffTinted(uint v) { return (v & FF_TINT_BIT) != 0u; }
vec3 ffTint(uint v) {
    return vec3(float((v >> 16u) & 31u), float((v >> 21u) & 31u), float((v >> 26u) & 31u)) / 31.0;
}

ivec3 ffVoxelFromWorld(vec3 worldPos) {
    return ivec3(floor(worldPos) - floor(cameraPosition)) + FF_SIZE / 2;
}
bool ffInside(ivec3 v) {
    return all(greaterThanEqual(v, ivec3(0))) && all(lessThan(v, FF_SIZE));
}

// ------------------------------------------------- distant light colour ---
// A coarse grid of 4-block cells out to the shadow distance: each cell keeps the
// colour of the strongest light source in it (shadow pass), then two compute passes
// spread those colours over the cells around, as far as their light reaches. Beyond
// the light grid this gives a lamp's surroundings its colour instead of the default
// warm light.
const ivec3 FAR_SIZE = ivec3(FAR_SIZE_XZ, FAR_SIZE_Y, FAR_SIZE_XZ);
// Grid coordinate (in cells) of a position given relative to the camera. Cells are
// fixed in the world, so they don't shift as you walk.
vec3 farCoord(vec3 playerPos) {
    return (playerPos + mod(cameraPosition, FAR_CELL)) / FAR_CELL + vec3(FAR_SIZE / 2);
}
bool farInside(ivec3 c) {
    return all(greaterThanEqual(c, ivec3(0))) && all(lessThan(c, FAR_SIZE));
}
// Colour (as the light spread uses it, 0..4) in the low 24 bits, light level on top,
// so the brightest source in a cell wins.
uint farPack(vec3 col, int level) {
    uvec3 q = uvec3(clamp(col * 0.25, 0.0, 1.0) * 255.0 + 0.5);
    return (uint(clamp(level, 0, 15)) << 24u) | (q.r << 16u) | (q.g << 8u) | q.b;
}
int farLevel(uint u) { return int(u >> 24u); }
vec3 farColor(uint u) {
    return vec3(float((u >> 16u) & 255u), float((u >> 8u) & 255u), float(u & 255u)) * (4.0 / 255.0);
}

#if USE_FAR_LIGHT == 1 && !defined SHADOW_PASS && !defined FF_COMPUTE
uniform sampler3D lfFarSamplerB;
// rgb = colour of the light around here, a = how sure (0 = no lamps near).
vec4 sampleFarLight(vec3 playerPos, vec3 normal) {
    vec3 uvw = farCoord(playerPos + normal * 0.6) / vec3(FAR_SIZE);
    if (any(lessThan(uvw, vec3(0.0))) || any(greaterThan(uvw, vec3(1.0)))) return vec4(0.0);
    vec4 s = texture(lfFarSamplerB, uvw);
    if (s.a <= 1e-4) return vec4(0.0);
    float edge = saturate(minOf(min(uvw, 1.0 - uvw)) * 12.0);
    return vec4(s.rgb / s.a, saturate(s.a * 3.0) * edge);
}
#endif

#if USE_FLOODFILL == 1 && !defined SHADOW_PASS && !defined FF_COMPUTE
uniform sampler3D lfLightSamplerA;
uniform sampler3D lfLightSamplerB;
uniform sampler3D lfSrcSamplerA;
uniform sampler3D lfSrcSamplerB;
uniform sampler3D lfSrc2SamplerA;
uniform sampler3D lfSrc2SamplerB;
uniform usampler3D lfVoxelSampler;

// rgb = normalised light colour, a = spread light level (0..1)
vec4 sampleSpreadLight(vec3 playerPos, vec3 normal) {
    vec3 p = playerPos + cameraPosition + normal * 0.55 - floor(cameraPosition) + vec3(FF_SIZE / 2);
    vec3 uvw = p / vec3(FF_SIZE);
    if (any(lessThan(uvw, vec3(0.0))) || any(greaterThan(uvw, vec3(1.0)))) return vec4(0.0);
    vec4 s = (frameCounter & 1) == 0 ? texture(lfLightSamplerA, uvw) : texture(lfLightSamplerB, uvw);
    float edge = minOf(min(uvw, 1.0 - uvw)) * 10.0;
    float level = s.a * saturate(edge);
    return vec4(s.rgb / max(s.a, 1e-3), level);
}

// Coloured light in the air at a point (for glowing mist): colour times strength.
vec3 spreadLightAt(vec3 playerPos) {
    vec3 p = playerPos + cameraPosition - floor(cameraPosition) + vec3(FF_SIZE / 2);
    vec3 uvw = p / vec3(FF_SIZE);
    if (any(lessThan(uvw, vec3(0.0))) || any(greaterThan(uvw, vec3(1.0)))) return vec3(0.0);
    vec4 s = (frameCounter & 1) == 0 ? texture(lfLightSamplerA, uvw) : texture(lfLightSamplerB, uvw);
    if (s.a <= 1e-3) return vec3(0.0);
    float edge = saturate(minOf(min(uvw, 1.0 - uvw)) * 10.0);
    return s.rgb / s.a * blockLightCurve(s.a) * edge;
}

// Where the light reaching this surface comes from: xyz = world position of the
// strongest source's block centre, w = that source's own light level (0..1), or
// w = 0 when there is none.
vec4 spreadSource(vec3 worldPos, vec3 normal) {
    vec3 front = worldPos + normal * 0.5;
    ivec3 v = ffVoxelFromWorld(front);
    if (!ffInside(v)) return vec4(0.0);
    vec4 s = (frameCounter & 1) == 0 ? texelFetch(lfSrcSamplerA, v, 0) : texelFetch(lfSrcSamplerB, v, 0);
    if (s.w <= 0.0) return vec4(0.0);
    return vec4(floor(front) + 0.5 + s.xyz, s.w);
}
// The second strongest source reaching this surface (w = 0 when there is none).
vec4 spreadSource2(vec3 worldPos, vec3 normal) {
    vec3 front = worldPos + normal * 0.5;
    ivec3 v = ffVoxelFromWorld(front);
    if (!ffInside(v)) return vec4(0.0);
    vec4 s = (frameCounter & 1) == 0 ? texelFetch(lfSrc2SamplerA, v, 0) : texelFetch(lfSrc2SamplerB, v, 0);
    if (s.w <= 0.0) return vec4(0.0);
    return vec4(floor(front) + 0.5 + s.xyz, s.w);
}
// Colour and strength of the light the source block at this world position gives
// off (as the light spread uses it); vec3(-1) if no light source is there now.
vec3 sourceColor(vec3 srcPos) {
    ivec3 v = ffVoxelFromWorld(srcPos);
    if (!ffInside(v)) return vec3(-1.0);
    uint w = texelFetch(lfVoxelSampler, v, 0).r;
    if (ffLevel(w) == 0) return vec3(-1.0);
    vec4 eL = emitterLight(ffCat(w));
    return eL.rgb / max(maxOf(eL.rgb), 1e-3) * lightTypeStrength(ffCat(w)) * eL.a;
}

// The kind of light source at this world position (-1 if none is there now).
int sourceCat(vec3 srcPos) {
    ivec3 v = ffVoxelFromWorld(srcPos);
    if (!ffInside(v)) return -1;
    uint w = texelFetch(lfVoxelSampler, v, 0).r;
    return ffLevel(w) == 0 ? -1 : ffCat(w);
}

// How much of the source's light reaches the surface, per colour: a voxel ray through
// the grid. Solid blocks stop it; plants, leaves, fences and mobs let some past;
// stained glass lets its own colour through.
// skipLo/skipHi: a box (world) whose mobs are ignored (your own body, for the light
// in your hand; an empty box otherwise).
vec3 voxelRayVisibility(vec3 worldPos, vec3 normal, vec3 srcPos, vec3 skipLo, vec3 skipHi) {
    vec3 ro = worldPos + normal * 0.04;
    vec3 dv = srcPos - ro;
    float len = length(dv);
    if (len < 0.75) return vec3(1.0);
    vec3 rd = dv / len;
    vec3 cell = floor(ro);
    vec3 stp = vec3(rd.x >= 0.0 ? 1.0 : -1.0, rd.y >= 0.0 ? 1.0 : -1.0, rd.z >= 0.0 ? 1.0 : -1.0);
    vec3 tDelta = 1.0 / max(abs(rd), vec3(1e-5));
    vec3 tMax = (stp * (cell - ro) + max(stp, 0.0)) * tDelta;
    ivec3 target = ivec3(floor(srcPos));
    ivec3 camCell = ivec3(floor(cameraPosition));
    vec3 vis = vec3(1.0);
    for (int i = 0; i < 24; i++) {
        float t;
        if (tMax.x < tMax.y && tMax.x < tMax.z) { t = tMax.x; cell.x += stp.x; tMax.x += tDelta.x; }
        else if (tMax.y < tMax.z) { t = tMax.y; cell.y += stp.y; tMax.y += tDelta.y; }
        else { t = tMax.z; cell.z += stp.z; tMax.z += tDelta.z; }
        if (t >= len) break;
        ivec3 c = ivec3(cell);
        if (c == target) break;
        ivec3 v = c - camCell + FF_SIZE / 2;
        if (!ffInside(v)) break;
        uint w = texelFetch(lfVoxelSampler, v, 0).r;
        if (ffSolid(w)) return vec3(0.0);
        if (ffTinted(w)) vis *= ffTint(w);
        bool ent = ffEntity(w) && !all(lessThan(abs(vec3(c) + 0.5 - (skipLo + skipHi) * 0.5), (skipHi - skipLo) * 0.5));
        if (ffPartial(w) || ent) {
            // Plants, fences and mobs are not cubes: block the ray only near the middle
            // of the block, so their shadows come out rounded and soft-edged.
            vec3 oc = vec3(c) + 0.5 - ro;
            float dd = length(oc - rd * dot(oc, rd));
            float occ = ent ? 0.8 * smoothstep(0.62, 0.22, dd) : 0.65 * smoothstep(0.55, 0.12, dd);
            vis *= 1.0 - occ;
        }
        if (maxOf(vis) < 0.03) return vec3(0.0);
    }
    return vis;
}
vec3 spreadVisibility(vec3 worldPos, vec3 normal, vec3 srcPos) {
    return voxelRayVisibility(worldPos, normal, srcPos, vec3(1e9), vec3(-1e9));
}

// Shortest distance between the segments p0-p1 and q0-q1.
float segmentDistance(vec3 p0, vec3 p1, vec3 q0, vec3 q1) {
    vec3 d1 = p1 - p0, d2 = q1 - q0, r = p0 - q0;
    float a = dot(d1, d1), e = dot(d2, d2), f = dot(d2, r);
    float c = dot(d1, r), b = dot(d1, d2);
    float den = a * e - b * b;
    float s = den > 1e-6 ? clamp((b * f - c * e) / den, 0.0, 1.0) : 0.0;
    float t = (b * s + f) / max(e, 1e-6);
    if (t < 0.0) { t = 0.0; s = clamp(-c / max(a, 1e-6), 0.0, 1.0); }
    else if (t > 1.0) { t = 1.0; s = clamp((b - c) / max(a, 1e-6), 0.0, 1.0); }
    return length((p0 + d1 * s) - (q0 + d2 * t));
}

// A lamp's light reaching a surface. Your own body throws a smooth, rounded shadow
// (a capsule from your feet to the top of your head) instead of the block-sized
// steps the light grid would give it, so it glides as you move (in F5 too).
vec3 lampVisibility(vec3 worldPos, vec3 normal, vec3 srcPos) {
    vec3 eyeW = cameraPosition - relativeEyePosition;
    vec3 vis = voxelRayVisibility(worldPos, normal, srcPos, eyeW + vec3(-0.9, -2.2, -0.9), eyeW + vec3(0.9, 0.7, 0.9));
    if (!isSpectator && maxOf(vis) > 0.0) {
        vec3 p = worldPos + normal * 0.04 - cameraPosition;
        vec3 eye = -relativeEyePosition;
        float d = segmentDistance(p, srcPos - cameraPosition, eye - vec3(0.0, 1.38, 0.0), eye + vec3(0.0, 0.08, 0.0));
        vis *= 1.0 - 0.85 * smoothstep(0.36, 0.16, d);
    }
    return vis;
}

// Where the light in your hand is (player space): at your hand, below and beside your
// eyes and a little in front (the left hand for a light in the offhand).
vec3 heldLightPos() {
    vec3 look = playerLookVector;
    if (dot(look, look) < 0.01) look = mat3(gbufferModelViewInverse) * vec3(0.0, 0.0, -1.0);
    vec3 fwd = normalize(vec3(look.x, 0.0, look.z) + vec3(1e-4, 0.0, 0.0));
    vec3 right = vec3(-fwd.z, 0.0, fwd.x);
    float side = heldBlockLightValue >= heldBlockLightValue2 ? 1.0 : -1.0;
    return -relativeEyePosition + fwd * 0.35 + right * side * 0.38 + vec3(0.0, -0.45, 0.0);
}

// How much of the light in your hand reaches a surface: blocks and mobs between them
// (through the light grid) and your own body (a capsule from your feet to your head).
// lightPos: where the light is (world, jittered for soft edges); hand: player space.
float heldLightVisibility(vec3 worldPos, vec3 normal, vec3 lightPos, vec3 hand) {
    vec3 eyeW = cameraPosition - relativeEyePosition;
    vec3 vis = voxelRayVisibility(worldPos, normal, lightPos, eyeW + vec3(-0.9, -2.2, -0.9), eyeW + vec3(0.9, 0.7, 0.9));
    float v = maxOf(vis);
    if (!isSpectator && v > 0.0) {
        vec3 p = worldPos + normal * 0.04 - cameraPosition;
        vec3 eye = -relativeEyePosition;
        float d = segmentDistance(p, hand, eye - vec3(0.0, 1.32, 0.0), eye - vec3(0.0, 0.1, 0.0));
        v *= 1.0 - 0.9 * smoothstep(0.34, 0.18, d);
    }
    return v;
}
#endif

#endif
