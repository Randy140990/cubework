/*
    Tempered Light - reading the sky panorama (prepare pass output) and the
    per-frame light colours every pass shares.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_SKY
#define LF_SKY

uniform sampler2D colortex6;

// The panorama is two halves side by side: sky only, then sky with clouds.
vec3 skyPanorama(vec3 dir) {
    vec2 uv = skyLutUV(dir);
    return texture(colortex6, vec2(clamp(uv.x * 0.5, 0.002, 0.498), uv.y)).rgb;
}
vec3 skyPanoramaClouds(vec3 dir) {
    vec2 uv = skyLutUV(dir);
    return texture(colortex6, vec2(0.5 + clamp(uv.x * 0.5, 0.002, 0.498), uv.y)).rgb;
}

// Direction for haze/fog colour: never below the horizon.
vec3 hazeColor(vec3 dir) {
    vec3 d = normalize(vec3(dir.x, clamp(dir.y, 0.015, 0.35), dir.z));
    return skyPanorama(d);
}

// Average sky radiance seen by an upward-facing surface.
vec3 skyAmbientFromLut() {
    vec3 s = vec3(0.0);
    s += skyPanoramaClouds(vec3(0.0, 1.0, 0.0)) * 2.0;
    for (int i = 0; i < 6; i++) {
        float a = float(i) * 1.0472;
        s += skyPanoramaClouds(normalize(vec3(cos(a), 0.55, sin(a))));
        s += skyPanoramaClouds(normalize(vec3(cos(a + 0.5), 0.12, sin(a + 0.5)))) * 0.5;
    }
    // A lightning flash lights everything up for a moment, blue-white.
    return s / 11.0 * (1.0 - 0.8 * stormDark()) + vec3(0.55, 0.6, 0.75) * flashAmbient() * 0.02;
}

// Nether and End: no sun, no sky light; a flat ambient instead (deferred and
// the forward-lit programs must agree).
vec3 otherDimAmbient() {
    #ifdef DIM_NETHER
        return srgbToLinear(fogColor) * 0.18 + 0.02;
    #elif defined DIM_ARENA
        // The Orbit Arena: a cool, dim light from the stars; its own lamps do the rest.
        return vec3(0.050, 0.056, 0.078);
    #else
        #if END_SHADOWS == 1 && END_SKY == 1 && SHADOWS == 1
            // With the black hole casting shadows, shade is deeper so they read clearly.
            return vec3(0.040, 0.028, 0.066) * (1.0 - 0.5 * saturate(END_STORM));   // darker under a storm
        #else
            return vec3(0.060, 0.040, 0.090) * (1.0 - 0.5 * saturate(END_STORM));
        #endif
    #endif
}

// Warm light thrown up by the Nether's lava sea (y 31): strongest near it,
// fading with height. Scaled by the Lava light strength.
vec3 netherGlow(float y) {
    // The lava sea's light swells and fades slowly, like something breathing below.
    float pulse = 1.0 + 0.12 * FIRE_FLICKER * (vnoise(vec2(frameTimeCounter * 0.45, 3.7)) * 2.0 - 1.0);
    return vec3(1.0, 0.34, 0.09) * (0.05 * NETHER_GLOW * LIGHT_LAVA * pulse) * exp(-max(y - 31.0, 0.0) / 26.0);
}

vec3 worldSunDir() { return normalize(mat3(gbufferModelViewInverse) * sunPosition); }
vec3 worldLightDir() { return normalize(mat3(gbufferModelViewInverse) * shadowLightPosition); }

// Clouds sit high: they keep the sun a little after the ground loses it.
vec3 cloudLightDir(vec3 sunDir) { return sunDir.y > -0.05 ? sunDir : -sunDir; }
vec3 cloudLightIrradiance(vec3 sunDir) {
    bool day = sunDir.y > -0.05;
    vec3 dir = day ? sunDir : -sunDir;
    vec3 E = day ? SUN_ILLUMINANCE * vec3(1.0, 0.985, 0.96)
                 : MOON_ILLUMINANCE * moonPhaseLight() * vec3(0.78, 0.88, 1.12);
    E *= atmTransmittance(ATM_H0 + 1200.0, dir, 8);   // low enough for golden and pink sunset clouds
    // Fade through the sun/moon hand-over just below the horizon.
    E *= smoothstep(0.0, 0.04, abs(sunDir.y + 0.05));
    return E * (1.0 - 0.6 * skyRain()) * (1.0 - 0.6 * stormDark());
}

// Direct light of whichever body casts shadows right now, dimmed by storms.
vec3 directLightIrradiance(vec3 sunDir) {
    vec3 e = sunDir.y > 0.0 ? sunIrradiance(sunDir) : moonIrradiance(sunDir);
    // Switch-over at the horizon fades through zero.
    e *= smoothstep(0.0, 0.06, abs(sunDir.y));
    return e * (1.0 - 0.75 * skyRain()) * (1.0 - stormDark());
}

#endif
