/*
    Tempered Light - physically based sky (Rayleigh, Mie and ozone single
    scattering with an ambient multiple-scattering term).
    Units: sunlit white surface at noon ~ 1.0 after the Lambert 1/pi.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_ATMOSPHERE
#define LF_ATMOSPHERE

const float ATM_RG = 6360e3;
const float ATM_RT = 6420e3;
const float ATM_H0 = 250.0;                 // viewer altitude (m)
const vec3  ATM_BETA_R = vec3(5.802e-6, 13.558e-6, 33.1e-6);
const float ATM_HR = 8000.0;
const float ATM_BETA_MS = 3.996e-6;
const float ATM_HM = 1200.0;
const vec3  ATM_BETA_O = vec3(0.650e-6, 1.881e-6, 0.085e-6);

// Daylight and moonlight strength. Sun Brightness only changes the disc and its glow;
// Moon Brightness also sets how bright a moonlit night is (0.5 = default).
#define SUN_ILLUMINANCE 3.6
#define MOON_ILLUMINANCE (0.036 * NIGHT_BRIGHTNESS * (0.5 + MOON_BRIGHTNESS))

// How much of the moon is lit, with a floor so new-moon nights stay playable (lower with Moon Cycle, so
// the dark of the moon really is darker than full moon).
float moonPhaseLight() {
    #if MOON_PHASES == 1
        #if MOON_CYCLE > 0 && MOON_SHAPE != 3
            return mix(0.12, 1.0, 0.5 + 0.5 * cos(moonPhaseAngle()));
        #else
            return mix(0.18, 1.0, 0.5 + 0.5 * cos(moonPhaseAngle()));
        #endif
    #else
        return 1.0;
    #endif
}

float atmHaze() {
    return 1.0 + 7.0 * skyRain() * RAIN_GLOOM;
}

vec2 raySphere(vec3 ro, vec3 rd, float r) {
    float b = dot(ro, rd);
    float c = dot(ro, ro) - r * r;
    float d = b * b - c;
    if (d < 0.0) return vec2(-1.0);
    d = sqrt(d);
    return vec2(-b - d, -b + d);
}

vec3 atmDensity(float h) {
    float o = max(0.0, 1.0 - abs(h - 25000.0) / 15000.0);
    return vec3(exp(-h / ATM_HR), exp(-h / ATM_HM), o);
}

vec3 atmExtinction(vec3 d) {
    float haze = atmHaze();
    return ATM_BETA_R * d.x + vec3(ATM_BETA_MS * 1.11 * haze) * d.y + ATM_BETA_O * d.z;
}

float phaseRayleigh(float mu) { return 0.0596831 * (1.0 + mu * mu); }
float phaseMie(float mu, float g) {
    float g2 = g * g;
    return 0.1193662 * (1.0 - g2) * (1.0 + mu * mu) / ((2.0 + g2) * pow(max(1.0 + g2 - 2.0 * g * mu, 1e-4), 1.5));
}
float phaseHG(float mu, float g) {
    float g2 = g * g;
    return 0.0795775 * (1.0 - g2) / pow(max(1.0 + g2 - 2.0 * g * mu, 1e-4), 1.5);
}

// Transmittance from a point at height h (m) towards direction dir, through the whole atmosphere.
vec3 atmTransmittance(float h, vec3 dir, int steps) {
    vec3 ro = vec3(0.0, ATM_RG + h, 0.0);
    vec2 g = raySphere(ro, dir, ATM_RG);
    // Soft terminator instead of a hard cut when the ray grazes the planet.
    float horizon = -sqrt(max(0.0, 1.0 - sqr(ATM_RG / (ATM_RG + h))));
    float sunVis = smoothstep(horizon - 0.035, horizon + 0.01, dir.y);
    if (sunVis <= 0.0) return vec3(0.0);
    vec2 t = raySphere(ro, dir, ATM_RT);
    float len = max(t.y, 0.0);
    float ds = len / float(steps);
    vec3 od = vec3(0.0);
    for (int i = 0; i < steps; i++) {
        vec3 p = ro + dir * (ds * (float(i) + 0.5));
        od += atmDensity(length(p) - ATM_RG) * ds;
    }
    vec3 tau = ATM_BETA_R * od.x + vec3(ATM_BETA_MS * 1.11 * atmHaze()) * od.y + ATM_BETA_O * od.z;
    return exp(-tau) * sunVis;
}

// Sky radiance along dir (world space, y up), lit by sun and moon.
vec3 atmSkyRadiance(vec3 dir, vec3 sunDir, vec3 sunE, vec3 moonE, int steps, int lightSteps) {
    vec3 ro = vec3(0.0, ATM_RG + ATM_H0, 0.0);
    vec2 tTop = raySphere(ro, dir, ATM_RT);
    vec2 tGround = raySphere(ro, dir, ATM_RG);
    bool hitsGround = tGround.x > 0.0;
    float tMax = hitsGround ? tGround.x : tTop.y;
    // The view never needs more than ~ 300 km.
    tMax = min(tMax, 3.0e5);
    vec3 moonDir = -sunDir;
    float muS = dot(dir, sunDir), muM = dot(dir, moonDir);
    float haze = atmHaze();
    // A moderate Mie lobe here; the tight glow round the sun and moon is drawn
    // per pixel (celestialGlow) so Sun Glow / Moon Glow can set it.
    float gM = mix(0.68, 0.62, skyRain());
    // Sun Brightness and Sun Glow also tone down the bright haze round the sun.
    float aureole = mix(1.0, (0.35 + 0.65 * saturate(SUN_BRIGHTNESS * 1.4)) * (0.5 + 0.5 * saturate(SUN_GLOW * 1.6)),
                        smoothstep(0.55, 0.995, muS));
    // Mostly on the sun's side of the sky: the opposite side keeps its blue and pink.
    float sunsetBoost = 1.0 + (SUNSET_STRENGTH - 1.0) * smoothstep(0.45, 0.0, abs(sunDir.y)) * (0.3 + 0.7 * smoothstep(-0.2, 0.8, dot(dir, sunDir)));
    float betaM = ATM_BETA_MS * haze * sunsetBoost;
    vec3 sum = vec3(0.0), ms = vec3(0.0);
    vec3 tauV = vec3(0.0);
    float prevT = 0.0;
    for (int i = 0; i < steps; i++) {
        float f = (float(i) + 1.0) / float(steps);
        float tNext = tMax * f * f;
        float ds = tNext - prevT;
        float tMid = prevT + ds * 0.5;
        prevT = tNext;
        vec3 p = ro + dir * tMid;
        float h = length(p) - ATM_RG;
        vec3 d = atmDensity(h);
        vec3 ext = ATM_BETA_R * d.x + vec3(betaM * 1.11) * d.y + ATM_BETA_O * d.z;
        vec3 Tv = exp(-(tauV + ext * ds * 0.5));
        tauV += ext * ds;
        vec3 Ts = atmTransmittance(h, sunDir, lightSteps);
        vec3 Tm = atmTransmittance(h, moonDir, lightSteps);
        vec3 scR = ATM_BETA_R * d.x;
        vec3 scM = vec3(betaM) * d.y;
        sum += Tv * ds * (sunE * Ts * (scR * phaseRayleigh(muS) + scM * phaseMie(muS, gM) * 0.8 * aureole)
                       + moonE * Tm * (scR * phaseRayleigh(muM) + scM * phaseMie(muM, gM) * 0.5));
        ms += Tv * ds * (scR + scM) * (sunE * Ts + moonE * Tm);
    }
    vec3 L = sum + ms * 0.05;
    if (hitsGround) {
        // Dark sea/ground beyond the world, lit by sun and sky.
        vec3 pg = ro + dir * tMax;
        vec3 n = normalize(pg);
        vec3 Tg = exp(-tauV);
        vec3 E = sunE * atmTransmittance(0.0, sunDir, lightSteps) * max(dot(n, sunDir), 0.0)
               + moonE * atmTransmittance(0.0, moonDir, lightSteps) * max(dot(n, moonDir), 0.0);
        L += Tg * vec3(0.05, 0.07, 0.09) * (E * RCP_PI + ms * 0.02);
    }
    // Airglow keeps moonless nights from going pitch black.
    L += vec3(0.0006, 0.0008, 0.0016) * NIGHT_BRIGHTNESS * (1.0 - smoothstep(-0.05, 0.1, sunDir.y));
    // Twilight: the side of the sky away from the sun turns dusky blue, not red.
    float twAway = smoothstep(0.2, -0.05, sunDir.y) * smoothstep(0.0, -0.7, muS);
    L = mix(L, vec3(luminance(L)) * vec3(0.78, 0.86, 1.14), twAway * 0.5);
    // Overcast skies lose their colour.
    float grey = skyRain() * 0.65 * RAIN_GLOOM;
    L = mix(L, vec3(luminance(L)) * vec3(0.95, 0.98, 1.05), saturate(grey));
    // A touch more blue than plain single scattering gives, as in photos.
    L = mix(vec3(luminance(L)), L, SKY_SATURATION * 1.12);
    return max(L, 0.0);
}

// ------------------------------------------------------- panorama LUT -----
// Elevation is squeezed so the horizon gets most of the texels.
vec2 skyLutUV(vec3 dir) {
    float az = atan(dir.z, dir.x);
    float el = asin(clamp(dir.y, -1.0, 1.0));
    float v = 0.5 + 0.5 * sign(el) * sqrt(abs(el) / HALF_PI);
    return vec2(az / TAU + 0.5, v);
}
vec3 skyLutDir(vec2 uv) {
    float az = (uv.x - 0.5) * TAU;
    float s = uv.y * 2.0 - 1.0;
    float el = sign(s) * s * s * HALF_PI;
    return vec3(cos(el) * cos(az), sin(el), cos(el) * sin(az));
}

// Light colours at the viewer. Sun and moon: direct irradiance (before the 1/pi).
vec3 sunIrradiance(vec3 sunDir) {
    return SUN_ILLUMINANCE * vec3(1.0, 0.985, 0.96) * atmTransmittance(ATM_H0, sunDir, 8);
}
vec3 moonIrradiance(vec3 sunDir) {
    // A little stronger than the sky glow it causes, so moonlit shadows read clearly.
    // Moonlight keeps most of its cool colour near the horizon (no deep red moonrise).
    vec3 T = atmTransmittance(ATM_H0, -sunDir, 8);
    return 1.35 * MOON_ILLUMINANCE * moonPhaseLight() * vec3(0.78, 0.88, 1.12) * mix(vec3(luminance(T)), T, 0.4);
}

#endif
