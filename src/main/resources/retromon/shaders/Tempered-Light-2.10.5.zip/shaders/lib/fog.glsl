/*
    Tempered Light - haze to the far edge of the world, low mist, rain gloom,
    caves, underwater fog with light rays, Nether and End fog.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#ifndef LF_FOG
#define LF_FOG

#ifdef DIM_END
#include "/lib/endstorm.glsl"
#endif

float eyeSkyLight() { return saturate(float(eyeBrightnessSmooth.y) / 240.0); }

// Optical depth of air haze + mist along a ray of length d.
// farEnd: where the drawn world ends in this frame (see composite1).
float airOpticalDepth(vec3 rd, float d, float camY, float farEnd) {
    // Aerial haze: distant land fades softly into the sky, so you never see where the
    // world ends. Thickest low down, thinning with height (a few hundred blocks up).
    const float Hh = 240.0;
    float a0 = HAZE_K * 0.0011 * exp(-max(camY - 63.0, -40.0) / Hh);
    float kh = rd.y * d / Hh;
    float tau = abs(kh) > 1e-3 ? a0 * d * (1.0 - exp(-kh)) / kh : a0 * d;
    tau = max(tau, 0.0);
    #if BORDER_FOG == 1
        // (Border Fog's own fade towards the edge, there with the Haze off too.)
        tau += max(HAZE_K, 1.0) * 0.8 * pow(saturate(d / farEnd), 3.0);
    #else
        tau += HAZE_K * 2.3 * pow(saturate(d / farEnd), 3.0);
    #endif
    // Mist hugging the ground near sea level, stronger at dawn and in rain.
    float H = 14.0;
    float dawn = 1.0 - smoothstep(0.0, 0.35, abs(worldSunDir().y));
    float a = MIST_K * (0.004 + 0.012 * dawn + 0.02 * skyRain()) * exp(-max(camY - 63.0, -20.0) / H);
    float k = rd.y * d / H;
    float mist = abs(k) > 1e-3 ? a * d * (1.0 - exp(-k)) / k : a * d;
    tau += max(mist, 0.0);
    tau += skyRain() * RAIN_GLOOM * 0.0035 * d;
    // Falling snow closes the view in; a snowstorm is a white-out a hundred blocks out.
    tau += snowStormHere() * SNOWSTORMS * belowCloudDeck() * smoothstep(0.35, 0.8, eyeSkyLight()) * 0.028 * min(d, 800.0);
    return tau;
}

// farEnd: where the drawn world ends in this frame (see composite1).
// How much of the air between you and a surface is in sunlight (1 = all of it),
// from the shadow map: the haze in a building's shadow mustn't glow with the sun
// behind it. Beyond the shadow map's reach the air counts as sunlit.
float gSunVis = 1.0;
float sunVisAlongRay(vec3 rd, float d, float dither) {
    #if USE_SHADOWS == 1
        float Ls = min(d, shadowDistance * 0.9);
        if (Ls < 1.0) return 1.0;
        const int N = 8;
        float v = 0.0, wsum = 0.0;
        for (int i = 0; i < N; i++) {
            float u = (float(i) + dither) / float(N);
            float w = 2.0 * u;
            float wd;
            v += shadowTap(rd * (Ls * u * u), wd) * w;
            wsum += w;
        }
        v /= max(wsum, 1e-4);
        return (v * Ls + max(d - Ls, 0.0)) / max(d, 1e-3);
    #else
        return 1.0;
    #endif
}

vec3 applyAirFog(vec3 color, vec3 rd, float d, bool isSky, vec3 skyAmbient, vec3 lightE, vec3 lightDir, float farEnd) {
    float camY = cameraPosition.y;
    float snowFog = snowStormHere() * SNOWSTORMS * belowCloudDeck() * smoothstep(0.35, 0.8, eyeSkyLight());
    // (The sky takes as much snow haze as land at the far edge, so hills don't stand out pale.)
    float tau = isSky ? skyRain() * RAIN_GLOOM * 0.6 + snowFog * 0.028 * min(farEnd, 800.0) : airOpticalDepth(rd, d, camY, farEnd);
    // Storm Mist: rain and thunder draw a curtain of mist in round you. Near land stays
    // clear; it thickens from about 4 chunks out and hides all but outlines past 16 to 18.
    float stormMist = skyRain() * (0.65 + 0.35 * lfThunder) * STORM_MIST * smoothstep(0.35, 0.8, eyeSkyLight());
    if (stormMist > 0.0) tau += stormMist * 0.0105 * max((isSky ? 2000.0 : d) - 64.0, 0.0) * (isSky ? smoothstep(0.5, 0.0, abs(rd.y)) : 1.0);
    // Underground the haze takes the cave's darkness instead of the sky.
    float sky = eyeSkyLight();
    tau *= mix(0.35, 1.0, sky);
    float T = exp(-tau);
    #if BORDER_FOG == 1
        // Border fog: the last stretch before the edge of the world melts into the sky.
        if (!isSky) T *= 1.0 - smoothstep(0.6, 0.98, d / farEnd) * smoothstep(0.05, 0.6, eyeSkyLight());
    #endif
    // Below the horizon there is no sky to see, only land too far away to be drawn:
    // fill it with the haze, so from up high the edge of the world never shows.
    if (isSky && rd.y < 0.0) {
        float below = smoothstep(-0.002, 0.008, -rd.y) * smoothstep(0.05, 0.6, sky);
        #if BORDER_FOG == 0
            below *= saturate(HAZE_K);
        #endif
        T *= 1.0 - below;
    }
    // Storms darken the sky and the haze itself (Storm Darkness).
    float sd = stormDark() * smoothstep(0.05, 0.6, sky);
    if (isSky) color *= 1.0 - 0.8 * sd;
    vec3 hz = hazeColor(rd);
    // Haze in shade (in front of a building with the sun behind it) takes the colour
    // of the haze away from the sun, without the sun's bright glow.
    if (gSunVis < 0.999) hz = mix(hazeColor(vec3(-rd.x, rd.y, -rd.z)), hz, gSunVis);
    vec3 fogCol = hz * (1.0 - 0.7 * sd);
    float mu = dot(rd, lightDir);
    // The sun's glow in the haze; in rain and storms it still shows through the grey
    // as a warm, diffuse brightening where the sun is trying to break through.
    fogCol += lightE * (1.0 + 2.0 * skyRain()) * phaseHG(mu, 0.75 + 0.1 * skyRain()) * 0.08 * gSunVis;
    // Snow in the air turns the haze a soft white-grey.
    fogCol = mix(fogCol, vec3(luminance(fogCol)) * 1.35 + vec3(0.9, 0.95, 1.0) * luminance(skyAmbient) * 0.5, saturate(snowFog) * 0.8);
    vec3 caveCol = vec3(0.010, 0.011, 0.014) * (0.3 + CAVE_BRIGHTNESS);
    fogCol = mix(caveCol, fogCol, smoothstep(0.05, 0.6, sky));
    return color * T + fogCol * (1.0 - T);
}

// Ground fog: a low, drifting layer that settles in hollows and over water,
// thickest at night and dawn, thinning out by midday.
vec3 applyGroundFog(vec3 color, vec3 rd, float d, vec3 skyAmbient, vec3 lightE, vec3 lightDir, float dither) {
    #if GROUND_FOG == 1
        float H = float(GROUND_FOG_HEIGHT);
        float base = 62.0;
        float top = base + H * 3.0;
        float camY = cameraPosition.y;
        float tA = 0.0, tB = min(d, 200.0);
        if (camY > top) {
            if (rd.y >= -1e-4) return color;
            tA = (top - camY) / rd.y;
        } else if (rd.y > 1e-4) {
            tB = min(tB, (top - camY) / rd.y);
        }
        if (tB <= tA) return color;
        float sunY = worldSunDir().y;
        float timeK = mix(1.0, 0.3, smoothstep(0.08, 0.45, sunY)) * (1.0 + 0.6 * skyRain());
        const int N = 8;
        float ds = (tB - tA) / float(N);
        // The fog travels with the wind (the set heading: the wandering one, multiplied
        // by the time, would send it racing as the heading slowly turns).
        float wa = radians(float(WIND_DIRECTION));
        vec2 drift = -vec2(cos(wa), sin(wa)) * frameTimeCounter * 0.6;
        float od = 0.0;
        for (int i = 0; i < N; i++) {
            vec3 p = cameraPosition + rd * (tA + ds * (float(i) + dither));
            float h = max(p.y - base, 0.0);
            vec3 q = vec3(p.x + drift.x, p.y * 1.8, p.z + drift.y) * 0.035;
            float n = vnoise3(q) * 0.65 + vnoise3(q * 2.7 + 5.0) * 0.35;
            od += exp(-h / H) * smoothstep(0.25, 0.75, n) * ds;
        }
        od *= 0.035 * GROUND_FOG_DENSITY * timeK * eyeSkyLight();
        float T = exp(-od);
        float mu = dot(rd, lightDir);
        vec3 fogCol = skyAmbient * 1.15 + lightE * phaseHG(mu, 0.6) * 0.35 * saturate(lightDir.y * 4.0);
        return color * T + fogCol * (1.0 - T);
    #else
        return color;
    #endif
}

// Light shafts through the haze, marched against the shadow map.
// How the air scatters sunlight towards you: a broad glow, plus a tight, bright
// lobe right round the sun that Sun Glow sets (0 leaves the sun's disc clear).
float sunAirPhase(float mu) {
    return phaseHG(mu, 0.55) * 0.8 + phaseHG(mu, 0.85) * 0.2 * saturate(SUN_GLOW * 2.0);
}

vec3 airVolumetricLight(vec3 rd, float d, vec3 lightE, vec3 lightDir, float dither) {
    #if VOLUMETRIC_LIGHT == 1 && USE_SHADOWS == 1
        float len = min(d, 96.0);
        const int steps = 10;
        float ds = len / float(steps);
        float lit = 0.0;
        for (int i = 0; i < steps; i++) {
            vec3 p = rd * ds * (float(i) + dither);
            float wd;
            lit += shadowTap(p, wd) * (wd > 0.0 ? 0.0 : 1.0);
        }
        lit /= float(steps);
        float mu = dot(rd, lightDir);
        float density = (0.0045 + 0.012 * skyRain() + 0.01 * MIST_K * (1.0 - smoothstep(0.0, 0.4, worldSunDir().y))) * VOLUMETRIC_STRENGTH;
        return lightE * lit * sunAirPhase(mu) * density * len * eyeSkyLight();
    #else
        return vec3(0.0);
    #endif
}

// God rays: sunlight streaming through the gaps between clouds, seen in the air
// below them - shafts fanning out from the sun when you look towards it, beams
// breaking through a stormy sky. The ray walks the air out to the cloud base and
// asks at each step how much sun gets through the clouds overhead.
vec3 cloudGodRays(vec3 rd, float d, vec3 lightDir, vec3 lightE, float dither) {
    #if defined LF_CLOUDS && (CLOUD_MODE == 1 || CLOUD_MODE == 2 || CLOUD_MODE == 5) && VOLUMETRIC_LIGHT == 1
        if (CLOUD_RAYS <= 0.0 || lightDir.y < 0.03) return vec3(0.0);
        float out_ = smoothstep(0.35, 0.8, eyeSkyLight());
        if (out_ <= 0.0) return vec3(0.0);
        #if CLOUD_MODE == 1
            float baseY = float(BLOCKY_CLOUD_ALTITUDE);
        #else
            float baseY = VOL_Y0 + 40.0;
        #endif
        float len = min(d, 520.0);
        if (rd.y > 1e-3) len = min(len, max((baseY - cameraPosition.y) / rd.y, 0.0));
        if (len < 4.0) return vec3(0.0);
        // More samples on the higher cloud qualities: crisper edges to each beam.
        #if CLOUD_QUALITY >= 2
            const int N = 20;
        #else
            const int N = 12;
        #endif
        float lit = 0.0, wsum = 0.0;
        for (int i = 0; i < N; i++) {
            // Closer samples are denser: near shafts are the sharp ones.
            float u = (float(i) + dither) / float(N);
            float t = len * u * u;
            float w = 2.0 * u;                           // ds for u^2 spacing
            vec3 p = cameraPosition + rd * t;
            float vis = cloudShadowK(p, lightDir, 1.0, true);
            #if USE_SHADOWS == 1
                // No beams inside the shadow of a hill or a build.
                float wd;
                if (vis > 0.01) vis *= shadowTap(rd * t, wd);
            #endif
            lit += vis * w;
            wsum += w;
        }
        lit /= max(wsum, 1e-4);
        float mu = dot(rd, lightDir);
        // More air to light up in rain and mist; the sun shines harder through a gap
        // than the dimmed light of the whole overcast sky suggests.
        // (Clear sky: only a little, or the sky round the sun whites out; the beams
        // belong to cloudy, rainy and stormy skies.)
        // A cloudy day (not just rain) gives beams too: they need gaps and shade to show.
        float cloudy = saturate(cloudCoverage() * 1.2);
        float dens = (0.0008 + 0.0011 * cloudy + 0.006 * skyRain() + 0.0012 * MIST_K) * CLOUD_RAYS;
        vec3 E = lightE * (1.0 + 1.5 * skyRain());
        // Beams stand out against the shaded air between them: lift the contrast a little
        // (the darker stretches of a ray count for less than the lit ones).
        lit = saturate(lit * (1.0 + 0.35 * cloudy) - 0.12 * cloudy);
        float ph = sunAirPhase(mu) * 0.8 + phaseHG(mu, 0.2) * 0.12 + phaseHG(mu, 0.85) * 0.08;
        return E * lit * ph * dens * len * out_;
    #else
        return vec3(0.0);
    #endif
}

// Camera under water: absorption, scattering and caustic light rays.
// The colour water fades to when seen from inside it (light scattered towards the eye).
vec3 underwaterFogColor(vec3 skyAmbient, vec3 lightE, vec3 lightDir) {
    vec3 absorb = waterAbsorption(), scat = waterScatter();
    float sky = eyeSkyLight();
    float sunVis = smoothstep(0.05, 0.6, sky);
    vec3 ambientIn = (skyAmbient * sky + lightE * RCP_PI * saturate(lightDir.y) * sunVis) * exp(-absorb * 2.0);
    return ambientIn * scat / (absorb + scat) * 0.28;
}

vec3 applyWaterFog(vec3 color, vec3 rd, float d, vec3 skyAmbient, vec3 lightE, vec3 lightDir, float dither) {
    // Seen from inside, water is clearer than its colour suggests: you can see the
    // surface, the sky through it and the sea bed well beyond arm's reach.
    float clarity = 0.42 / UNDERWATER_VIEW;
    vec3 absorb = waterAbsorption() * clarity;
    vec3 scat = waterScatter() * clarity;
    vec3 ext = absorb + scat;
    float sky = eyeSkyLight();
    vec3 T = exp(-ext * d);
    // No sunlight in a cave lake: the sun term follows how open the sky is.
    float sunVis = smoothstep(0.05, 0.6, sky);
    vec3 ambientIn = (skyAmbient * sky + lightE * RCP_PI * saturate(lightDir.y) * sunVis) * exp(-absorb * 2.0);
    vec3 inscatter = ambientIn * scat / ext * (1.0 - T) * 0.28;
    vec3 rays = vec3(0.0);
    #if UNDERWATER_RAYS == 1 && USE_SHADOWS == 1
        float len = min(d, 40.0);
        const int steps = 12;
        float ds = len / float(steps);
        float mu = dot(rd, lightDir);
        // Direction towards the light inside the water (bent towards straight up).
        vec3 lightW = -refract(-lightDir, vec3(0.0, 1.0, 0.0), 1.0 / 1.333);
        for (int i = 0; i < steps; i++) {
            float t = ds * (float(i) + dither);
            vec3 p = rd * t;
            float wd;
            float vis = shadowTap(p, wd);
            vec3 Tl = exp(-waterAbsorption() * wd * 1.1);   // rays still fade with depth
            vec3 Tv = exp(-ext * t);
            // The shafts are the caustic pattern carried down along the (refracted) sunlight,
            // so they point at the sun you see through the surface.
            vec3 entry = p + cameraPosition + lightW * wd;
            rays += vis * Tl * Tv * caustics(entry) * ds;
        }
        rays *= lightE * scat * phaseHG(mu, 0.55) * 1.5;
    #endif
    return color * T + inscatter + rays;
}

// ------------------------------------------------------------ Nether mist ---
// Smoke and haze rising from the lava sea, drifting in slow curtains: lit orange from
// the lava below and, through the light grid, by every lamp, fire and lava fall
// nearby, so lights glow and shimmer through it.
vec3 netherMist(vec3 color, vec3 rd, float d, float dither) {
    #if defined DIM_NETHER && NETHER_MIST == 1
        float len = min(d, 128.0);
        const int N = 14;
        float ds = len / float(N);
        vec3 fc = srgbToLinear(fogColor);
        float t = frameTimeCounter;
        vec3 scat = vec3(0.0);
        float T = 1.0;
        for (int i = 0; i < N; i++) {
            vec3 pp = rd * ds * (float(i) + dither);
            vec3 p = pp + cameraPosition;
            vec3 q = p * 0.032 + vec3(t * 0.012, -t * 0.045, t * 0.008);    // rising, drifting
            float n = vnoise3(q) * 0.6 + vnoise3(q * 2.3 + 4.1) * 0.3 + vnoise3(q * 5.3 + 9.7) * 0.1;
            float low = exp(-max(p.y - 31.0, 0.0) / 46.0);                 // thicker over the lava sea
            float dens = (0.25 + 1.4 * smoothstep(0.38, 0.82, n)) * (0.45 + 0.9 * low) * 0.0128 * NETHER_MIST_STRENGTH;
            vec3 L = fc * 0.22 + netherGlow(p.y) * 7.0;
            #if USE_FLOODFILL == 1 && defined LF_FLOODFILL
                // Fire- and lava-lit mist flickers, shifting from place to place.
                float fl = 1.0 + (vnoise3(vec3(p.xz * 0.35, frameTimeCounter * 3.0) + p.y * 0.21) * 2.0 - 1.0) * 0.22 * FIRE_FLICKER;
                L += spreadLightAt(pp) * 1.6 * fl;
            #endif
            float a = 1.0 - exp(-dens * ds);
            scat += T * L * a;
            T *= 1.0 - a;
        }
        return color * T + scat;
    #else
        return color;
    #endif
}

// ---------------------------------------------------------------- End mist ---
// A low, glowing haze round the main island, lit by the black hole: where the
// pillars and the dragon block its light, darker shafts reach through the mist.
vec3 endMist(vec3 color, vec3 rd, float d, float dither, vec3 lightDir, vec3 lightE) {
    #if defined DIM_END && END_MIST == 1
        // Under the End Storm the mist rises round the island's edges into a dark wall
        // of cloud (the storm closing in), so it reaches further out.
        float storm = saturate(END_STORM);
        float len = min(d, mix(192.0, 320.0, storm));
        const int N = 18;
        float ds = len / float(N);
        float t = frameTimeCounter;
        float mu = dot(rd, lightDir);
        // Under the storm the mist scatters the hole's light less straight at you, so
        // it no longer piles up into a glare round the hole.
        float ph = mix(phaseHG(mu, 0.55) * 0.8 + 0.08, phaseHG(mu, 0.4) * 0.55 + 0.08, storm);
        vec3 amb = mix(vec3(0.060, 0.040, 0.095), vec3(0.016, 0.016, 0.042), storm);
        vec3 scat = vec3(0.0);
        float T = 1.0;
        // A second stretch, through the mist piled round the main island, when you're
        // too far out for the first to reach it (it stays in view from the far islands).
        float tC = len, tD = len;
        {
            vec2 o2 = cameraPosition.xz, v2 = rd.xz;
            float a2 = dot(v2, v2), b2 = dot(o2, v2), c2 = dot(o2, o2) - 330.0 * 330.0;
            float disc2 = b2 * b2 - a2 * c2;
            if (a2 > 1e-6 && disc2 > 0.0 && storm > 0.0) {
                float s2 = sqrt(disc2);
                tC = max((-b2 - s2) / a2, len);
                tD = min((-b2 + s2) / a2, min(d, len + 1400.0));
            }
        }
        int NS = tD > tC + 1.0 ? N + 12 : N;
        vec4 fl = endFlash();
        for (int i = 0; i < N + 12; i++) {
            if (i >= NS) break;
            bool far2 = i >= N;
            float segT = far2 ? tC + (tD - tC) * (float(i - N) + dither) / 12.0 : ds * (float(i) + dither);
            float segDs = far2 ? (tD - tC) / 12.0 : ds;
            vec3 pp = rd * segT;
            vec3 p = pp + cameraPosition;
            // Round the island's sides and out over the void, thinning fast above its
            // top so the ground (and the pillars' shadows on it) stay clear.
            float band = exp(-max(p.y - 54.0, 0.0) / 9.0 - max(54.0 - p.y, 0.0) / 18.0);
            float rr = length(p.xz);
            float island = 1.0 - smoothstep(90.0, 200.0, rr);        // round the main island
            // The storm's wall of mist: from the island's edge outwards, piled high.
            float wallM = storm * smoothstep(70.0, 140.0, rr) * (1.0 - smoothstep(240.0, 330.0, rr))
                        * exp(-max(p.y - 60.0, 0.0) / 34.0 - max(40.0 - p.y, 0.0) / 30.0);
            // The mist turns about the island with the storm (a little faster, being
            // nearer in), drawn into two spiral arms that sweep across it.
            vec3 sm = endSwirlTurn(p, endSwirlAngle(t) * 1.4);
            vec3 q = sm * 0.028 + vec3(t * 0.004, 0.0, -t * 0.003);
            float n = vnoise3(q) * 0.65 + vnoise3(q * 2.6 + 3.3) * 0.35;
            float shape = max(band * (0.25 + 0.75 * island), wallM * 1.4);
            float dens = shape * (0.4 + 1.1 * smoothstep(0.3, 0.8, n)) * 0.0035 * END_MIST_STRENGTH * (1.0 + 0.3 * END_STORM);
            if (END_SWIRL > 0.0) {
                float arms = endSpiralArms(sm, length(p.xz), 2.0, 4.0, n * 2.5);
                dens *= mix(1.0, 0.3 + 1.4 * arms, 0.8 * min(END_SWIRL, 1.0));
            }
            if (dens < 1e-5) continue;
            float vis = 1.0;
            #if defined END_HOLE_SHADOWS && USE_SHADOWS == 1
                float wd;
                vis = shadowTap(pp, wd);
            #endif
            if (END_STORM > 0.0) vis *= endStormShadow(p, 3);
            vec3 L = amb + lightE * vis * ph * mix(0.8, 0.42, storm);
            if (fl.w > 0.0) L += END_FLASH_COL * fl.w * 1.2 * exp(-length(p - fl.xyz) / 140.0);
            #if USE_FLOODFILL == 1 && defined LF_FLOODFILL
                L += spreadLightAt(pp) * 1.2;
            #endif
            float a = 1.0 - exp(-dens * segDs);
            scat += T * L * a;
            T *= 1.0 - a;
        }
        return color * T + scat;
    #else
        return color;
    #endif
}

vec3 netherFog(vec3 color, float d, vec3 rd) {
    vec3 fc = srgbToLinear(fogColor) * 0.35;
    // The haze glows orange low down, over the lava sea.
    float hy = cameraPosition.y + rd.y * min(d, 96.0) * 0.5;
    fc += netherGlow(hy) * 1.6;
    #if NETHER_ROOF_SKY == 1
        // On the roof the haze takes on the burnt orange of the open sky.
        fc = mix(fc, vec3(0.11, 0.035, 0.014), smoothstep(122.0, 130.0, cameraPosition.y));
    #endif
    float T = exp(-d * 0.0115 - pow(saturate(d / far), 3.0) * 2.3);
    return color * T + fc * (1.0 - T);
}
vec3 endStorm(vec3 color, vec3 rd, float d, float dither, vec3 lightDir, vec3 lightE) {
    #if defined DIM_END
        if (END_STORM <= 0.0) return color;
        vec3 ro = cameraPosition;
        // March only through the shell: from where the ray leaves the clear middle.
        vec3 oc = ro - vec3(0.0, 70.0, 0.0);
        vec3 sc = vec3(1.0, 1.25, 1.0);
        vec3 o = oc * sc, v = rd * sc;
        float a = dot(v, v), b = dot(o, v);
        // Through the shell only, from wherever you are (out on the far islands too).
        float c1 = dot(o, o) - 800.0 * 800.0;
        float disc1 = b * b - a * c1;
        if (disc1 <= 0.0) return color;
        float tA = max((-b - sqrt(disc1)) / a, 0.0);
        float c0 = dot(o, o) - 115.0 * 115.0;
        if (c0 < 0.0) tA = (-b + sqrt(max(b * b - a * c0, 0.0))) / a;   // inside: start at the wall
        float tB = min(d, (-b + sqrt(disc1)) / a);
        if (tB <= tA) return color;
        vec4 fl = endFlash();
        int N = 16 + 8 * CLOUD_QUALITY;
        float ds = (tB - tA) / float(N);
        float t = frameTimeCounter;
        float mu = dot(rd, lightDir);
        // (A gentler forward lobe: the cloud in front of the hole glows at its edges
        // without flaring into one white blaze round it.)
        float ph = mix(phaseHG(mu, 0.45), phaseHG(mu, -0.2), 0.35);
        float sigma = 0.024 * END_STORM;
        vec3 deep = vec3(0.006, 0.007, 0.024);           // in the folds: deep indigo
        vec3 scat = vec3(0.0);
        float T = 1.0;
        for (int i = 0; i < 40; i++) {
            if (i >= N) break;
            vec3 p = ro + rd * (tA + ds * (float(i) + dither));
            float den = endStormDensity(p, t, 2);
            if (den <= 0.001) continue;
            // How much of the hole's light gets through the cloud towards it.
            float od = endStormDensity(p + lightDir * 18.0, t, 1) * 18.0 + endStormDensity(p + lightDir * 55.0, t, 1) * 37.0;
            float Tl = exp(-od * sigma * 5.0);
            // Thin, sunlit edges glow; the thick insides of the billows stay dark.
            float powder = 1.0 - exp(-den * 3.0);
            vec3 L = lightE * Tl * (ph * 1.1 + 0.025) * mix(1.0, powder, 0.5) + deep * (1.0 + 0.6 * END_GLOW);
            if (fl.w > 0.0) L += END_FLASH_COL * fl.w * 2.4 * exp(-length(p - fl.xyz) / 75.0);
            float al = 1.0 - exp(-den * sigma * ds);
            scat += T * L * al;
            T *= 1.0 - al;
            if (T < 0.02) break;
        }
        return color * T + scat;
    #else
        return color;
    #endif
}

// End Storm god rays: the black hole's light breaking through the storm in beams,
// lighting the air round the island. Streamers crossing the gap and the pillars cut
// dark shafts through them. Strongest looking towards the hole. Cloud God Rays sets
// the strength; needs Light Shafts, like the Overworld's.
vec3 endStormRays(vec3 rd, float d, float dither, vec3 lightDir, vec3 lightE) {
    #if defined DIM_END && VOLUMETRIC_LIGHT == 1
        if (END_STORM <= 0.0 || CLOUD_RAYS <= 0.0) return vec3(0.0);
        float len = min(d, 300.0);
        const int N = 14;
        float lit = 0.0, wsum = 0.0;
        float t = frameTimeCounter;
        for (int i = 0; i < N; i++) {
            // Closer samples are denser: near shafts are the sharp ones.
            float u = (float(i) + dither) / float(N);
            float tt = len * u * u;
            vec3 pp = rd * tt;
            vec3 p = pp + cameraPosition;
            // The air inside the storm's eye, thinning with height.
            vec3 c = p - vec3(0.0, 70.0, 0.0);
            float inside = 1.0 - smoothstep(140.0, 240.0, length(vec3(c.x, c.y * 1.25, c.z)));
            float w = 2.0 * u * inside * exp(-max(p.y - 80.0, 0.0) / 120.0);
            if (w <= 0.0) { wsum += 2.0 * u; continue; }
            float beam = endBeams(p, t);
            float vis = endStormShadow(p, 3) * (0.08 + 0.92 * beam);
            #if defined END_HOLE_SHADOWS && USE_SHADOWS == 1
                float wd;
                vis *= shadowTap(pp, wd);
            #endif
            lit += vis * w;
            wsum += 2.0 * u;
        }
        lit /= max(wsum, 1e-4);
        float mu = dot(rd, lightDir);
        // Spread round the hole rather than piled onto it: beams around a light you
        // can barely see through the cloud.
        float ph = phaseHG(mu, 0.6) * 0.65 + phaseHG(mu, 0.2) * 0.35;
        float dens = 0.0012 * min(END_STORM, 1.5) * CLOUD_RAYS;
        return lightE * lit * ph * dens * len;
    #else
        return vec3(0.0);
    #endif
}

vec3 endFog(vec3 color, float d) {
    vec3 fc = vec3(0.030, 0.016, 0.055) * (1.0 - 0.55 * saturate(END_STORM));   // the End sky's violet, darker in a storm
    float T = exp(-d * 0.004 - pow(saturate(d / farDistance()), 3.0) * 2.3);
    return color * T + fc * (1.0 - T);
}

#endif
