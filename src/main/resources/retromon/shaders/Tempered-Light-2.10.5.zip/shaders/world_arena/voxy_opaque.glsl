// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define DIM_END
#define DIM_ARENA
#include "/program/voxy_opaque_impl.glsl"
