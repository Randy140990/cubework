#version 330 compatibility
// Tempered Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define FSH
#define PROGRAM_DH_WATER
#define DIM_END
#define DIM_ARENA
#include "/program/dh_water.glsl"
