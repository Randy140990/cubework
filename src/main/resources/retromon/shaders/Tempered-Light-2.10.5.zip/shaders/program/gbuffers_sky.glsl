/*
    Tempered Light - vanilla sky draws. The sky itself is drawn in the deferred
    pass; only the vanilla sun/moon textures are kept (Vanilla texture style).
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"

#ifdef VSH
out vec2 uv;
out vec4 vcol;
void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vcol = gl_Color;
    gl_Position = ftransform();
}
#endif

#ifdef FSH
uniform sampler2D gtexture;
in vec2 uv;
in vec4 vcol;

/* RENDERTARGETS: 5 */
layout(location = 0) out vec4 outSky;

void main() {
    #ifdef PROGRAM_SKYTEXTURED
        bool keep = false;
        #if SUN_SHAPE == 3
            if (renderStage == MC_RENDER_STAGE_SUN) keep = true;
        #endif
        #if MOON_SHAPE == 3
            if (renderStage == MC_RENDER_STAGE_MOON) keep = true;
        #endif
        #ifdef DIM_ARENA
            // The Orbit Arena draws its own sky (a panorama of space) as the End's sky box: keep all of it.
            keep = true;
        #endif
        if (!keep) discard;
        vec4 c = texture(gtexture, uv) * vcol;
        #ifdef DIM_ARENA
            // Faint stars lifted, the bright planet and its rings held back (so they keep their colour).
            vec3 lin = srgbToLinear(c.rgb);
            outSky = vec4(lin * 1.35 / (1.0 + lin * 0.45), c.a);
            return;
        #endif
        float boost = renderStage == MC_RENDER_STAGE_SUN ? 24.0 * SUN_BRIGHTNESS : 2.4 * MOON_BRIGHTNESS;
        outSky = vec4(srgbToLinear(c.rgb) * boost, c.a);
    #else
        discard;
    #endif
}
#endif
