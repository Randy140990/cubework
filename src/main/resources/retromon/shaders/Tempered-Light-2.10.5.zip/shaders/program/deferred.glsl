/*
    Tempered Light - lights every opaque pixel (vanilla, Voxy and Distant
    Horizons alike) and draws the sky, sun, moon, stars and Milky Way.
    Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
*/
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/taa.glsl"
#include "/lib/space.glsl"
#include "/lib/materials.glsl"
#include "/lib/wind.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/sky.glsl"

#if !defined DIM_NETHER && !defined DIM_END
    #define DIM_OVERWORLD
#endif

#ifdef VSH
#ifdef DIM_END
#include "/lib/endstorm.glsl"
#endif
out vec2 texcoord;
flat out vec3 sunDir;
flat out vec3 lightDir;
flat out vec3 lightE;
flat out vec3 skyAmb;
flat out vec3 sunT;
flat out vec3 moonT;
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    #ifdef DIM_OVERWORLD
        sunDir = worldSunDir();
        lightDir = worldLightDir();
        lightE = directLightIrradiance(sunDir);
        skyAmb = skyAmbientFromLut();
        sunT = atmTransmittance(ATM_H0, sunDir, 8);
        moonT = atmTransmittance(ATM_H0, -sunDir, 8);
    #else
        sunDir = vec3(0.0, -1.0, 0.0);
        lightDir = vec3(0.0, 1.0, 0.0);
        lightE = vec3(0.0);
        #ifdef END_WORLD
            // The black hole's disc lights the islands from its side of the sky. With its
            // shadows on, it is the island's sun: stronger, so the shadows read.
            lightDir = normalize(END_HOLE_DIR);
            #if END_SHADOWS == 1 && END_SKY == 1 && SHADOWS == 1
                // (In an End Storm it shines harder through the gap, for deep contrast.)
                lightE = vec3(0.86, 0.66, 1.0) * 1.35 * END_GLOW * (1.0 + 0.7 * END_STORM);
            #else
                lightE = vec3(0.80, 0.55, 1.0) * 0.55 * END_GLOW;
            #endif
        #endif
        skyAmb = otherDimAmbient();
        #ifdef END_WORLD
            // The End Storm's lightning lights the island faintly blue for a moment.
            skyAmb += END_FLASH_COL * endFlash().w * 0.012;
        #endif
        sunT = vec3(1.0);
        moonT = vec3(1.0);
    #endif
}
#endif

#ifdef FSH
#include "/lib/water.glsl"
#include "/lib/shadows.glsl"
#include "/lib/clouds.glsl"
#include "/lib/floodfill.glsl"
#include "/lib/lighting.glsl"
#include "/lib/portal.glsl"
#include "/lib/celestial.glsl"
#include "/lib/othersky.glsl"
#include "/lib/endportal.glsl"
#ifdef DIM_END
#include "/lib/endstorm.glsl"
#endif

uniform sampler2D depthtex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex5;
#ifdef VOXY
uniform sampler2D vxDepthTexOpaque;
#endif
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
#endif

in vec2 texcoord;
flat in vec3 sunDir;
flat in vec3 lightDir;
flat in vec3 lightE;
flat in vec3 skyAmb;
flat in vec3 sunT;
flat in vec3 moonT;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

// Rough extinction toward a sky direction, for stars near the horizon.
vec3 skyExtinction(vec3 rd) {
    float z = acos(clamp(rd.y, 0.0, 1.0));
    float airmass = 1.0 / (max(rd.y, 0.0) + 0.50572 * pow(max(96.07995 - degrees(z), 0.5), -1.6364));
    return exp(-vec3(0.08, 0.13, 0.28) * min(airmass, 40.0) * (1.0 + 3.0 * skyRain()));
}

vec3 drawSky(vec3 rd, vec2 uv) {
    #if defined DIM_OVERWORLD
        vec3 col = skyPanorama(rd) * SKY_BRIGHTNESS;
        float pixelAngle = 1.6 / viewHeight;
        vec3 tv = skyExtinction(rd);
        if (rd.y > -0.02) {
            col += sunDisk(rd, sunDir, sunT, pixelAngle) * (1.0 - skyRain() * 0.9);
            col += moonDisk(rd, sunDir, moonT, pixelAngle) * (1.0 - skyRain() * 0.9);
            col += celestialGlow(rd, sunDir, sunT, moonT);
            col += nightSky(rd, sunDir, tv);
            col += shootingStars(rd, sunDir, pixelAngle) * tv;
            col += texture(colortex5, uv).rgb * (rd.y > 0.0 ? 1.0 : 0.0) * mix(tv, vec3(1.0), 0.5);
        }
        return col;
    #elif defined DIM_NETHER
        vec3 fc = srgbToLinear(fogColor) * 0.35;
        #if NETHER_ROOF_SKY == 1
            // Above the bedrock roof the sky opens up; below it, it stays haze.
            float roof = smoothstep(122.0, 130.0, cameraPosition.y);
            if (roof > 0.0) fc = mix(fc, netherRoofSky(rd, frameDither(gl_FragCoord.xy)), roof);
        #endif
        return fc;
    #elif defined DIM_ARENA
        // The Orbit Arena's own sky, as the mod draws it (kept by gbuffers_skytextured).
        return texture(colortex5, uv).rgb;
    #else
        return endSky(rd);
    #endif
}

// Screen-space ambient occlusion: how much of the nearby half-space above the surface
// is filled by other geometry (corners, the gaps under stairs and slabs, between
// blocks and plants). Darkens sky light and lamp light only, never the sun.
float screenAO(vec3 viewPos, vec3 Nv, float dither) {
    #if SSAO == 1
        float dist = -viewPos.z;
        float radius = 0.55 + dist * 0.006;
        // Build a frame around the normal and spread 8 samples over the hemisphere.
        vec3 t = normalize(abs(Nv.y) < 0.9 ? cross(Nv, vec3(0.0, 1.0, 0.0)) : cross(Nv, vec3(1.0, 0.0, 0.0)));
        vec3 b = cross(Nv, t);
        float occ = 0.0;
        for (int i = 0; i < 8; i++) {
            float fi = float(i) + dither;
            float a = fi * 2.39996;
            float r = sqrt((float(i) + 0.5) / 8.0) * radius;
            float h = 0.15 + 0.85 * fract(fi * 0.618034 + 0.31);
            vec3 sp = viewPos + Nv * 0.04 + (t * cos(a) + b * sin(a)) * r + Nv * (h * radius * 0.7);
            vec4 cp = gbufferProjection * vec4(sp, 1.0);
            vec2 suv = cp.xy / cp.w * 0.5 + 0.5;
            if (any(lessThan(suv, vec2(0.0))) || any(greaterThan(suv, vec2(1.0)))) continue;
            float d = texture(depthtex0, suv).r;
            if (d >= 1.0) continue;
            float sceneZ = screenToView(suv, d, gbufferProjectionInverse).z;
            float dz = sceneZ - sp.z;          // > 0: the sample point is inside geometry
            occ += smoothstep(0.02, 0.12, dz) * smoothstep(radius * 2.0, radius * 0.6, dz);
        }
        return 1.0 - saturate(occ / 8.0 * 1.25 * SSAO_STRENGTH) * 0.85;
    #else
        return 1.0;
    #endif
}

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    vec2 uv = texcoord;
    float depth = texelFetch(depthtex0, px, 0).r;
    int src = SRC_SKY;
    vec3 viewPos = vec3(0.0);
    if (depth < 1.0) {
        src = SRC_VANILLA;
        viewPos = screenToView(uv, depth, gbufferProjectionInverse);
    }
    #ifdef VOXY
        if (src == SRC_SKY) {
            float vd = texelFetch(vxDepthTexOpaque, px, 0).r;
            if (vd < 1.0) { src = SRC_VOXY; viewPos = screenToView(uv, vd, vxProjInv); }
        }
    #endif
    #ifdef DISTANT_HORIZONS
        if (src == SRC_SKY) {
            float dd = texelFetch(dhDepthTex0, px, 0).r;
            if (dd < 1.0) { src = SRC_DH; viewPos = screenToView(uv, dd, dhProjectionInverse); }
        }
    #endif

    vec3 rd = normalize(mat3(gbufferModelViewInverse) * screenToView(uv, 1.0, gbufferProjectionInverse));
    if (src == SRC_SKY) {
        outColor = vec4(drawSky(rd, uv), 1.0);
        #if DEBUG_VIEW == 6
            outColor = vec4(texture(colortex6, uv).rgb * 2.0, 1.0);
        #endif
        return;
    }

    vec4 g1 = texelFetch(colortex1, px, 0);
    vec4 g2 = texelFetch(colortex2, px, 0);
    vec4 g3 = texelFetch(colortex3, px, 0);
    Material m;
    m.albedo = srgbToLinear(g1.rgb);
    m.ao = g2.a;
    m.cat = int(g3.r * 255.0 + 0.5);
    m.smoothness = g3.g;
    m.f0 = g3.b;
    m.emission = g3.a;
    vec3 N = decodeNormal(g2.rg);
    vec2 lm = unpack2x8(g2.b);

    if (m.cat == CAT_UNLIT) { outColor = vec4(m.albedo, 1.0); return; }
    // Vanilla sand reads very yellow under warm sunlight: pull it towards a paler, natural beige.
    if (m.cat == CAT_SAND) m.albedo = mix(vec3(luminance(m.albedo)), m.albedo, SAND_SATURATION);

    vec3 playerPos = viewToPlayer(viewPos);
    bool hand = m.cat == CAT_HAND;
    if (hand) playerPos = normalize(playerPos) * 0.6;
    vec3 worldPos = playerPos + cameraPosition;
    vec3 V = -normalize(playerPos);
    float dither = frameDither(gl_FragCoord.xy);
    #if SSAO == 1
        if (src == SRC_VANILLA && !hand) {
            // Mostly the face's own normal (from the depth buffer), so normal-mapped
            // bumps don't shade themselves.
            vec3 Nv = mat3(gbufferModelView) * N;
            vec3 Ng = cross(dFdx(viewPos), dFdy(viewPos));
            if (dot(Ng, Ng) > 1e-12) {
                Ng = normalize(Ng);
                if (dot(Ng, viewPos) > 0.0) Ng = -Ng;
                if (dot(Ng, Nv) > 0.5) Nv = normalize(mix(Nv, Ng, 0.7));
            }
            m.ao *= screenAO(viewPos, Nv, dither);
        }
    #endif

    #ifdef DIM_OVERWORLD
        float puddle = 0.0;
        if (!hand && m.cat < CAT_ENTITY) applyWetness(m, N, worldPos, lm.y, puddle);
        if (!hand && m.cat < CAT_ENTITY) applySnowCover(m, N, worldPos, lm.y);
        float NdotL = dot(N, lightDir);
        ShadowSample sh;
        if (src == SRC_VANILLA && !hand) {
            sh = sampleShadow(playerPos, N, NdotL, lm.y, dither);
        } else {
            sh.light = vec3(skyLightShadow(lm.y)); sh.waterDepth = 0.0; sh.waterFrac = 0.0;
        }
        float cs = cloudShadow(worldPos, lightDir);
    #else
        ShadowSample sh;
        sh.light = vec3(0.0); sh.waterDepth = 0.0; sh.waterFrac = 0.0;
        #ifdef END_WORLD
            sh.light = vec3(1.0);
            #ifdef END_HOLE_SHADOWS
                // Shadows from the black hole: the pillars, the dragon, you.
                if (src == SRC_VANILLA && !hand) sh = sampleShadow(playerPos, N, dot(N, lightDir), 1.0, dither);
            #endif
            // The End Storm's clouds shade the island as they drift across the light.
            if (END_STORM > 0.0 && !hand) sh.light *= endStormShadow(worldPos, 6);
        #endif
        float cs = 1.0;
        lm.y = 1.0;
    #endif

    LampLight lamps = noLamps();
    #if USE_FAR_LIGHT == 1
        if (!hand && lm.x > 0.01) lamps.far = sampleFarLight(playerPos, N);
    #endif
    #if USE_FLOODFILL == 1
        if (src == SRC_VANILLA && !hand) {
            lamps.spread = sampleSpreadLight(playerPos, N);
            if (lamps.spread.a > 0.02) {
                lamps.src1 = spreadSource(worldPos, N);
                lamps.src2 = spreadSource2(worldPos, N);
                if (lamps.src1.w > 0.0) lamps.col1 = sourceColor(lamps.src1.xyz);
                if (lamps.src2.w > 0.0) lamps.col2 = sourceColor(lamps.src2.xyz);
                // Flames flicker, and their light sways inside the block so shadows dance.
                if (lamps.src1.w > 0.0) {
                    vec2 k = flickerKind(sourceCat(lamps.src1.xyz));
                    float seed = flameSeed(lamps.src1.xyz, k);
                    lamps.flick.x = flameBrightness(seed, k);
                    lamps.src1.xyz += flameSway(seed, k);
                }
                if (lamps.src2.w > 0.0) {
                    vec2 k = flickerKind(sourceCat(lamps.src2.xyz));
                    float seed = flameSeed(lamps.src2.xyz, k);
                    lamps.flick.y = flameBrightness(seed, k);
                    lamps.src2.xyz += flameSway(seed, k);
                }
                // Nether portals light as one big glowing panel: from its nearest point, with
                // soft shadows aimed at points spread across the whole portal.
                bool panel1 = false, panel2 = false;
                vec3 pk1a = vec3(0.0), pk1b = vec3(0.0), pk2 = vec3(0.0);
                #if PORTAL_LIST == 1
                {
                    vec2 u0 = vec2(frameDither(gl_FragCoord.xy), ignAnimated(gl_FragCoord.xy + vec2(37.0, 11.0), frameCounter));
                    vec3 nr;
                    if (lamps.src1.w > 0.0 && sourceCat(lamps.src1.xyz) == CAT_PORTAL) {
                        panel1 = portalPanel(lamps.src1.xyz, worldPos, u0, nr, pk1a);
                        if (panel1) { portalPanel(lamps.src1.xyz, worldPos, fract(u0 + vec2(0.5, 0.5)), nr, pk1b); lamps.src1.xyz = nr; }
                    }
                    if (lamps.src2.w > 0.0 && sourceCat(lamps.src2.xyz) == CAT_PORTAL) {
                        panel2 = portalPanel(lamps.src2.xyz, worldPos, fract(u0 + vec2(0.25, 0.75)), nr, pk2);
                        if (panel2) lamps.src2.xyz = nr;
                    }
                }
                #endif
                #if LIGHT_SHADOWS == 1
                    if (m.cat < CAT_ENTITY) {   // mobs would shadow themselves
                        // Aim at random points inside each source block: soft shadow edges
                        // once TAA averages them (two for the main lamp so moving around
                        // shows soft edges, not speckle).
                        float n = frameDither(gl_FragCoord.xy);
                        vec3 j1 = (fract(n + vec3(0.0, 0.618034, 0.381966)) - 0.5) * 0.7;
                        vec3 j2 = (fract(n + vec3(0.5, 0.118034, 0.881966)) - 0.5) * 0.7;
                        // (Kept inside the source's own block, where the flame sways about.)
                        vec3 b1 = floor(lamps.src1.xyz), b2 = floor(lamps.src2.xyz);
                        if (panel1)
                            lamps.vis1 = 0.5 * (lampVisibility(worldPos, N, pk1a) + lampVisibility(worldPos, N, pk1b));
                        else if (lamps.src1.w > 0.0)
                            lamps.vis1 = 0.5 * (lampVisibility(worldPos, N, clamp(lamps.src1.xyz + j1, b1 + 0.02, b1 + 0.98)) +
                                                lampVisibility(worldPos, N, clamp(lamps.src1.xyz + j2, b1 + 0.02, b1 + 0.98)));
                        if (panel2)
                            lamps.vis2 = lampVisibility(worldPos, N, pk2);
                        else if (lamps.src2.w > 0.0)
                            lamps.vis2 = lampVisibility(worldPos, N, clamp(lamps.src2.xyz + j2.zxy, b2 + 0.02, b2 + 0.98));
                    }
                #endif
            }
        }
    #endif

    #if HELD_LIGHT_SHADOWS == 1 && HANDHELD_LIGHT == 1 && USE_FLOODFILL == 1 && LIGHT_SHADOWS == 1
        // The light in your hand casts shadows too: from blocks, mobs and yourself.
        if (src == SRC_VANILLA && !hand && m.cat < CAT_ENTITY && max(heldBlockLightValue, heldBlockLightValue2) > 0) {
            vec3 hp = heldLightPos();
            if (length(playerPos - hp) < float(max(heldBlockLightValue, heldBlockLightValue2))) {
                float n = frameDither(gl_FragCoord.xy);
                vec3 j = (fract(n + vec3(0.0, 0.618034, 0.381966)) - 0.5) * 0.3;
                lamps.hand = vec4(hp + cameraPosition, heldLightVisibility(worldPos, N, hp + cameraPosition + j, hp + j));
            }
        }
    #endif

    SceneLights L;
    L.lightDir = lightDir; L.lightE = lightE; L.skyAmbient = skyAmb; L.sunDir = sunDir;
    vec3 col = shadeSurface(m, N, V, playerPos, worldPos, lm, sh, cs, lamps, L);
    #ifdef DIM_NETHER
        // Undersides of ledges and ceilings catch the glow from the lava below.
        if (src == SRC_VANILLA && !hand) col += m.albedo * m.ao * netherGlow(worldPos.y) * (0.35 + 0.65 * saturate(0.5 - 0.5 * N.y));
    #endif
    #if END_PORTAL_STYLE == 1
        // An End portal is a window into the End (lib/endportal.glsl).
        if (m.cat == CAT_END_PORTAL && src == SRC_VANILLA) col = endPortalView(normalize(playerPos), worldPos) * EMISSIVE_STRENGTH;
    #endif

    #if DEBUG_VIEW == 1
        col = m.albedo;
    #elif DEBUG_VIEW == 2
        col = N * 0.5 + 0.5;
    #elif DEBUG_VIEW == 3
        col = vec3(lm, 0.0);
    #elif DEBUG_VIEW == 4
        col = sh.light * cs;
    #elif DEBUG_VIEW == 5
        col = lamps.spread.rgb * lamps.spread.a * (lamps.src1.w > 0.0 ? mix(vec3(0.25), vec3(1.0), lamps.vis1) : vec3(1.0));
    #elif DEBUG_VIEW == 7
        // What the shadow pass wrote into the light grid for the block in front of
        // this surface and the one behind it: light sources in their colour, solid
        // blocks white, plants green, mobs and the player red. Black = nothing written.
        col = m.albedo * 0.08;
        #if USE_FLOODFILL == 1
            if (src == SRC_VANILLA) {
                for (int k = 0; k < 2; k++) {
                    ivec3 v = ffVoxelFromWorld(worldPos + N * (k == 0 ? 0.5 : -0.5));
                    if (!ffInside(v)) { col = vec3(0.05, 0.0, 0.08); break; }
                    uint w = texelFetch(lfVoxelSampler, v, 0).r;
                    if (ffLevel(w) > 0) col = emitterLight(ffCat(w)).rgb * (0.4 + 0.04 * float(ffLevel(w)));
                    else if (ffSolid(w)) col = vec3(0.55);
                    else if (ffPartial(w)) col = vec3(0.1, 0.6, 0.15);
                    else if (ffEntity(w)) col = vec3(0.8, 0.1, 0.1);
                    else continue;
                    break;
                }
            }
        #else
            col = vec3(0.4, 0.0, 0.4);   // coloured light is not compiled in (missing Iris features)
        #endif
    #endif
    if (any(isnan(col)) || any(isinf(col))) col = vec3(0.0);
    outColor = vec4(max(col, 0.0), 1.0);
}
#endif
