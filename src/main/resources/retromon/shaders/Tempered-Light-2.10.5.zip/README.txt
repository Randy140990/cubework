Tempered Light 2.10.5
by Insid3 Th3 Cub3
====================

Tempered Light is a shader pack for Minecraft Java Edition. It is built around
light: every torch, lantern and glowing block lights the world in its own
colour and casts its own shadows, under a sky that changes through the day,
with clouds, weather, water and night skies to match. Pick a Look and a
quality profile and it is ready to play; every part can be fine-tuned in the
settings.


Install
-------
1. Minecraft Java 1.21.11, 26.1, 26.2 or 26.3, with Iris and Sodium made for
   that version (Fabric or NeoForge). This one pack works on all four.
   - 1.21.11: Iris 1.10, Sodium 0.8
   - 26.1, 26.2 and 26.3: Iris 1.11, Sodium 0.9
2. Optional far distance: Voxy or Distant Horizons, the build made for your
   version. On 26.3, Voxy needs Iris 1.11 (it does not load with Iris 1.12).
3. Put this zip, unopened, in .minecraft/shaderpacks.
4. Options > Video Settings > Shader Packs > Tempered Light.


Getting started
---------------
Open Shader Pack Settings. At the top:
- Look: Tempered, Realistic, Blocky, Storybook, Vivid or Custom.
  The Look picks the sun, moon, clouds, water and colour together. Every one
  of those can still be changed on its own page.
- Profile: Potato, Low, Medium, High or Ultra. This sets quality only; your
  Look stays the same. Ultra is made for an RTX 4070 class card or better;
  Medium suits most graphics cards.

The pages are named after what they change: Sun & Moon, Sky & Stars, Clouds,
Water, Lighting, Materials, Shadows, Weather & Particles, Wind, Fog & Distance,
Nether & End and Camera (with Tone & Colour and World Blur inside it). Hover
over any setting to see what it does.


Good to know
------------
- Coloured Light (Lighting page) needs Iris with custom images and compute
  shaders. It does not work on macOS; set Coloured Light to Off there.
- Distant Light Colour keeps far-off lamps in their own colour out to your
  shadow distance. Far away it only knows the lamps in or near your view, so a
  lamp just off screen can leave a warm glow at the edge until it comes into view.
- Smoke drifting with the wind uses the light grid too, so it needs Coloured
  Light; with it off, smoke rises straight up as in Minecraft. The glow of lava
  and lights in the Nether and End mists needs it as well.
- The black hole's shadows in the End need Shadows on and the Black Hole sky.
- The End opens in a storm (End Storm 1). For the clear, open End of earlier
  versions, set End Storm to 0 on the Nether & End page. The god rays through
  it need Light Shafts, like the Overworld's.
- Firelight flicker and dancing shadows need Coloured Light (dancing shadows
  also need Light Source Shadows). Cloud God Rays need Light Shafts.
- Drips from trees and eaves need Coloured Light too; Rain on Screen tells a
  roof over your head from open sky with it (without it, from how much sky
  you can see).
- Realistic smoke (Smoke Style, Weather & Particles page) needs Coloured Light.
  It follows your clouds unless you pick a style, like Lightning Bolts, and
  draws plumes over the 16 nearest fires; beyond those you see Minecraft's puffs.
- Portals (Portals page, inside Nether & End): a Nether portal's vortex is
  centred on the whole portal for portals within reach of Coloured Light;
  further away, or with Coloured Light off, the energy flows across it without
  the core. The mist round Nether portals, and the mist, sparks and coloured
  light of End portals, need Coloured Light.
- Held Light Shadows (Lighting page) needs Held Light, Coloured Light and Light
  Source Shadows.
- Lightning Bolts follows your clouds unless you pick a style: Minecraft's
  blocky bolt with Blocky or Vanilla clouds, the realistic bolt otherwise.
- Snow cover and snowstorms follow the biome you are standing in: walk out of a
  snowy biome and the snow over everything in view thins out over a minute or so.
- Rain, wet ground and puddles follow the biome: deserts, badlands and
  savannas never get rain in Minecraft, so they stay dry.
- Lights in your hand glow in their own colour, so put a torch away when
  comparing the colours of other lights.
- Haze, Low Mist and Ground Fog are off by default for a clear view. Turn any
  of them on, and set how strong it is, on the Fog & Distance page. Border Fog
  and Light Shafts (god rays) are on; Light Shafts are off on the Potato and
  Low profiles.
- Depth of Field, Motion Blur and Lens Flare (sun only) are on by default. Turn
  them off, or change their strength, on the Camera page.
- Sun Brightness changes only the sun and the glow around it; daylight is set
  by Exposure. Night Brightness lifts or darkens every night.
- The first time you enter the Nether or the End in a session, the game pauses
  for a few seconds while Iris builds that dimension's shaders; later trips are
  instant.
- Iris resets its animation clock after each hour of play, so clouds, waves and
  drifting particles jump once an hour.
- All sky, cloud and water art is generated by the shaders; the only image in
  the pack is a small noise texture.


If something looks wrong
------------------------
If lights all look the same orange, open Advanced > Debug View > Light grid
blocks. Lights should show in colour, solid blocks grey, plants green and you
red. If it is all black or purple, contact us on the Insid3 Th3 Cub3 Patreon
(patreon.com/insidethecube) with your Iris version and the lines in
logs/latest.log that mention "shadowcomp" or "Failed to process".


Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
Tempered Light is licensed, not sold. See LICENSE.txt.
Not an official Minecraft product. Not approved by or associated with Mojang
or Microsoft.
