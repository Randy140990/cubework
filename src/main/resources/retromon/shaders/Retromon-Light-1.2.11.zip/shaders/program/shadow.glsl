// Retromon Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
// The sun's (or moon's) view of the world, for the shadows. Only outside: buildings' insides have none.

#define SHADOW_PASS
#include "/lib/settings.glsl"
#include "/lib/shadow.glsl"
#include "/lib/wave.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;

#ifdef VSH
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
in vec4 mc_Entity;
in vec4 at_midBlock;
out vec2 uv;
out float alpha;
void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    // (1.2.8) Lily pads cast no shadow: under clear water it read as a second pad beside each.
    alpha = int(mc_Entity.x + 0.5) == 10007 ? 0.0 : gl_Color.a;
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    vec3 pp = (shadowModelViewInverse * vp).xyz;
    pp += wave(pp, mc_Entity.x, at_midBlock);
    vec4 p = gl_ProjectionMatrix * (shadowModelView * vec4(pp, 1.0));
    p.xy = distortShadow(p.xy);
    gl_Position = p;
}
#endif

#ifdef FSH
in vec2 uv;
in float alpha;
/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;
void main() {
    vec4 c = texture(gtexture, uv);
    if (c.a * alpha < 0.1) discard;
    outColor = c;
}
#endif
