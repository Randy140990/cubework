#version 330 compatibility
// Retromon Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define VSH
#define INSIDE
#define ENTITY
#include "/program/lit.glsl"
