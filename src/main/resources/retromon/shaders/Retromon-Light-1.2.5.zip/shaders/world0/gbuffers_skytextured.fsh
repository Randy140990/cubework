#version 330 compatibility
// Retromon Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define FSH
#define SKY_TEXTURED
#include "/program/sky.glsl"
