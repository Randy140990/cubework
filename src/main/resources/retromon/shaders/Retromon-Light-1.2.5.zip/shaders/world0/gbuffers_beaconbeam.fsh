#version 330 compatibility
// Retromon Light. Copyright (c) 2026 Insid3 Th3 Cub3. All rights reserved.
#define FSH
#define GLOW
#include "/program/unlit.glsl"
